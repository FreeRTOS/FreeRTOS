/*************************************************************************
 *
 *    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2005
 *
 *    File name   : mmc.c
 *    Description : MMC
 *
 *    History :
 *    1. Data        : July 1, 2005
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *    $Revision: 1.4 $
 *
 * (C) Joel Winarske, 2006,2007                                        
**************************************************************************/
#include <stdio.h> // ###
#include "disk.h"
#include "diskio.h"
#include "mmc.h"
#include "spi.h"

#define MMC_RET_ERROR(Res)          do { mmcLastError = Res; return (MmcCardError); } while (0)
#define MMC_RET_DATA_ERR(Res)       do { mmcLastError = Res; return (MmcDataError); } while (0)

#define CSD_GET_TRAN_SPEED_EXP()      (mmcSdCsd [ 3] & 0x07)
#define CSD_GET_TRAN_SPEED_MANT()    ((mmcSdCsd [ 3] & 0xF8) >> 3)
#define CSD_GET_NSAC()                (mmcSdCsd [ 2])
#define CSD_GET_TAAC_EXP()            (mmcSdCsd [ 1] & 0x7)
#define CSD_GET_TAAC_MANT()          ((mmcSdCsd [ 1] & 0xF8) >> 3)
#define CSD_GET_R2W_FACTOR()         ((mmcSdCsd [12] & 0x1C) >> 2)
#define CSD_GET_READ_BL_LEN()         (mmcSdCsd [ 5] & 0x0F)
#define CSD_GET_C_SIZE()            (((mmcSdCsd [ 6] & 0x03) << 10) + (mmcSdCsd [7] << 2) + ((mmcSdCsd [8] & 0xc0) >> 6))
#define CSD_GET_C_SIZE_MULT()       (((mmcSdCsd [ 9] & 0x03) << 1) + ((mmcSdCsd [10] & 0x80) >> 7))
#define CSD_GET_PERM_WRITE_PROTECT() ((mmcSdCsd [14] & 0x20) >> 5)
#define CSD_GET_TMP_WRITE_PROTECT()  ((mmcSdCsd [14] & 0x10) >> 4)

static const U32 mmcTransfExp [] =
{
     10000UL,
    100000UL,
   1000000UL,
  10000000UL,
         0UL,
         0UL,
         0UL,
         0UL,
};

static const U32 mmmcAccessTime [] =
{
 10000000UL,
  1000000UL,
   100000UL,
    10000UL,
     1000UL,
      100UL,
       10UL,
        1UL,
};

static const U32 mmcCsdMant [] =
{
  0UL,10UL,12UL,13UL,15UL,
  20UL,25UL,
  30UL,35UL,
  40UL,45UL,
  50UL,55UL,
  60UL,
  70UL,
  80UL,
};

static const U32 mmcAccessTimeMant [] =
{
  0UL,100UL,83UL,77UL,67UL,
  50UL,40UL,
  33UL,29UL,
  25UL,22UL,
  20UL,18UL,
  17UL,
  14UL,
  13UL,
};

static const mmcCommads_t mmcCmd [CMD_END] =
{
  { 0x40, MmcNoArg,     MmcR1 }, // CMD0
  { 0x41, MmcNoArg,     MmcR1 }, // CMD1
  { 0x49, MmcNoArg,     MmcR1 }, // CMD9
  { 0x4A, MmcNoArg,     MmcR1 }, // CMD10
  { 0x4C, MmcNoArg,     MmcR1 }, // CMD12
  { 0x4D, MmcNoArg,     MmcR2 }, // CMD13
  { 0x50, MmcBlockLen,  MmcR1 }, // CMD16
  { 0x51, MmcDataAdd,   MmcR1 }, // CMD17
  { 0x52, MmcDataAdd,   MmcR1 }, // CMD18
  { 0x58, MmcDataAdd,   MmcR1 }, // CMD24
  { 0x59, MmcDataAdd,   MmcR1 }, // CMD25
  { 0x5B, MmcNoArg,     MmcR1 }, // CMD27
  { 0x5C, MmcDataAdd,   MmcR1b}, // CMD28
  { 0x5D, MmcDataAdd,   MmcR1b}, // CMD29
  { 0x5E, MmcDataAdd,   MmcR1 }, // CMD30
  { 0x60, MmcDataAdd,   MmcR1 }, // CMD32
  { 0x61, MmcDataAdd,   MmcR1 }, // CMD33
  { 0x62, MmcDataAdd,   MmcR1 }, // CMD34
  { 0x63, MmcDataAdd,   MmcR1 }, // CMD35
  { 0x64, MmcDataAdd,   MmcR1 }, // CMD36
  { 0x65, MmcDataAdd,   MmcR1 }, // CMD37
  { 0x66, MmcDummyWord, MmcR1b}, // CMD38
  { 0x6A, MmcDummyWord, MmcR1b}, // CMD42
  { 0x77, MmcNoArg,     MmcR1 }, // CMD55
  { 0x78, MmcNoArg,     MmcR1 }, // CMD56
  { 0x7A, MmcNoArg,     MmcR3 }, // CMD58
  { 0x7B, MmcDummyWord, MmcR1 }, // CMD59
  { 0x69, MmcNoArg,     MmcR1 } // ACMD41
};

static volatile DSTATUS Stat = STA_NOINIT;  /* Disk status */
static DiskStatus_t mmcDskStatus;
static U32 mmcLastError; 
static U32 Tnac;
static U32 Twr;
static U8 mmcSdCsd [16];

//
//
//
static U32 mmcSendCmd (mmcSpiCmdInd_t ComdInd, U32 Arg);
static U32 mmcSetBlockLen (U32 length);
static void mmcCSDImplement (void);
static mmcState_t mmcInitMedia (void);
static mmcState_t mmcReadCardInfo (U8 *pData, mmcSpiCmdInd_t Command);
static inline mmcState_t mmcRead (U8 *pData, U32 Add, U32 Length);
static inline mmcState_t mmcWrite (U8 *pData, U32 Add, U32 Length);
static inline mmcState_t mmcVerify (U8 *pData, U32 Add, U32 Length);

/*************************************************************************
 * Function Name: mmcSendCmd
 * Parameters: MmcSpiCmdInd_t ComdInd,U32 Arg
 *
 * Return: U32
 *
 * Description: MMC commands implemet
 *
 *************************************************************************/
static U32 mmcSendCmd (mmcSpiCmdInd_t ComdInd, U32 Arg)
{
  U32 ch = 0xff;
  U32 i;

  //
  //  Chip Select
  //
  spiChipSelect (1);

  //
  //  Send command code
  //
  spiTransferByte (mmcCmd [ComdInd].TxData);

  //
  //  Send command's arguments
  //
  if (mmcCmd [ComdInd].Arg == MmcNoArg)
  {
    spiTransferByte (0x00);
    spiTransferByte (0x00);
    spiTransferByte (0x00);
    spiTransferByte (0x00);
  }
  else
  {
    spiTransferByte (Arg >> 24);
    spiTransferByte (Arg >> 16);
    spiTransferByte (Arg >> 8);
    spiTransferByte (Arg);
  }

  //
  //  Send CRC
  //
  if (ComdInd == CMD0)
    spiTransferByte (0x95);
  else
    spiTransferByte (0xff);

  for (i = 9; i && (ch == 0xff); --i) 
    ch = spiTransferByte (0xff);

  if (i == 0)
  {
    spiChipSelect (0);
    return ((U32) -1);
  }

  switch (mmcCmd [ComdInd].Resp)
  {
    case MmcR1b :
      {
        U32 busy;

        for (busy = 0, i = Twr; i && (busy != 0xff); --i)
          busy = spiTransferByte (0xff);
      }
      return (ch);

    case MmcR1 :
      return (ch);

    case MmcR2 :
      Arg  = ((U32) ch << 8) & 0x0000FF00;
      Arg |= spiTransferByte (0xff) & 0xff;
      return (Arg);

    case MmcR3 :
    default:
      Arg  = ((U32) ch << 24) & 0xff000000;
      Arg |= ((U32) spiTransferByte (0xff) << 16) & 0x00FF0000;
      Arg |= ((U32) spiTransferByte (0xff) << 8 ) & 0x0000FF00;
      Arg |= spiTransferByte (0xff) & 0xff;
      return (Arg);
  }
}

/*************************************************************************
 * Function Name: mmcSetBlockLen
 * Parameters: U32 Length
 *
 * Return: U32
 *
 * Description: Set Block length Return command's result
 *
 *************************************************************************/
static U32 mmcSetBlockLen (U32 length)
{
  U32 res = mmcSendCmd (CMD16, length);
  spiChipSelect (0);
  return (res);
}

/*************************************************************************
 * Function Name: mmcCSDImplement
 * Parameters:  none
 *
 * Return: none
 *
 * Description: Implemet data from CSD
 *
 *************************************************************************/
static void mmcCSDImplement (void)
{
  U32 frequency;

  //
  // Calculate SPI max clock
  //
  frequency = mmcTransfExp [CSD_GET_TRAN_SPEED_EXP ()] * mmcCsdMant [CSD_GET_TRAN_SPEED_MANT ()];

  if (frequency > 20000000)
    frequency = 20000000;

  frequency = spiSetClockFreq (frequency);

  if (mmcDskStatus.DiskType == DiskMMC)
  {
    Tnac = mmmcAccessTime [CSD_GET_TAAC_EXP ()] * mmcAccessTimeMant [CSD_GET_TAAC_MANT ()];
    Tnac = frequency / Tnac;
    Tnac += 1 << (CSD_GET_NSAC () + 4);
    Tnac *= 10;
    Twr   = Tnac * CSD_GET_R2W_FACTOR ();
  }
  else
  {
    Tnac = frequency / SD_READ_TIME_OUT;
    Twr  = frequency / SD_WRITE_TIME_OUT;
  }

  mmcDskStatus.BlockSize = 1 << CSD_GET_READ_BL_LEN ();
  mmcDskStatus.BlockNumb = (CSD_GET_C_SIZE () + 1) * (4 << CSD_GET_C_SIZE_MULT ());
  mmcDskStatus.WriteProtect = spiWriteProtect () | CSD_GET_PERM_WRITE_PROTECT () | CSD_GET_TMP_WRITE_PROTECT ();
}

/*************************************************************************
 * Function Name: mmcInitMedia
 * Parameters: none
 *
 * Return: mmcState_t
 *
 * Description: MMC detect and initialize
 *
 *************************************************************************/
static mmcState_t mmcInitMedia (void)
{
  U32 i;
  U32 res;

  Tnac = 1;

  if (!spiPresent ())
    return (MmcNoPresent);

  //
  //  Clock Freq. Identification Mode < 400kHz
  //
  spiSetClockFreq (IdentificationModeClock);

  //
  //  Set maximum time out
  //
  Tnac = IdentificationModeClock / SD_READ_TIME_OUT;

  //
  //  Power up cycles.  After power up at least 74 clock cycles are required 
  //  prior to starting bus communication
  //
  for (i = 0; i < 2; i++)
  {
    spiChipSelect (0);

    for (res = 10; res; --res)
      spiTransferByte (0xff);

    //
    //  CMD0 (Go to IDLE) to put MMC in SPI mode
    //
    res = mmcSendCmd (CMD0, 0);
    spiChipSelect (0);

    if (res == MMC_IDLE_STATE)
      break;
  }

  if (res != MMC_IDLE_STATE)
    return (MmcNoResponse);

  //
  //  Determinate Card type SD or MMC
  //
  mmcDskStatus.DiskType = DiskMMC;

  for (i = 100; i; --i)
  {
    spiChipSelect (0);
    spiTransferByte (0xff);
    res = mmcSendCmd (CMD55, 0);
    spiChipSelect (0);
    spiChipSelect (0);
    spiTransferByte (0xff);
    res = mmcSendCmd (ACMD41, 0);
    spiChipSelect (0);

    if (res & MMC_ILLEGAL_CMD)
    {
      //
      //  MMC card may be CMD1 for MMC Init sequence will be complete within 500ms
      //
      for (i = 100; i; --i)
      {
        spiChipSelect (0);
        spiTransferByte (0xff);
        res = mmcSendCmd (CMD1, 0);
        spiChipSelect (0);

        if (res == MMC_OK)
          break;

        spiDelay1ms (50);
      }
      break;
    }

    if (res == MMC_OK)
    {
      mmcDskStatus.DiskType = DiskSD;
      break;
    }

    spiDelay1ms (50);
  }

  if (i == 0)
    return (MmcNoResponse);

  //
  //  Read CSD.  CSD must always be valid
  //
  if ((res = mmcReadCardInfo (mmcSdCsd, CMD9)) != MmcOk)
    return (MmcNoResponse);

  //
  //  Implement CSD data, and set block size
  //
  mmcCSDImplement ();
  mmcSetBlockLen (mmcDskStatus.BlockSize);

  // mmcDecode (mmcSdCsd); // ###

  return (MmcOk);
}

/*************************************************************************
 * Function Name: mmcReadCardInfo
 * Parameters: U8 *pData,
 *             mmcSpiCmdInd_t Command - CMD9, CMD10 are only allowed
 *
 * Return: mmcState_t
 *
 * Description: Read CSD or CID  registers depend of commoand
 *
 *************************************************************************/
static mmcState_t mmcReadCardInfo (U8 *pData, mmcSpiCmdInd_t Command)
{
  U32 i;
  U32 res;

  switch (Command)
  {
    case CMD9 :
    case CMD10 :
      break;

    default:
      return (MmmcParameterError);
  }

  spiChipSelect (0);
  spiTransferByte (0xff);

  if ((res = mmcSendCmd (Command, 0)) == MMC_OK)
  {
    for (i = 8; i ; --i)
    {
      if (((res = spiTransferByte (0xff)) | MMC_DATA_ERR_TOKEN) == MMC_DATA_ERR_TOKEN)
      {
        // printf ("line %d: spiTransferByte returned 0x%x\n", __LINE__, res); // ###
        MMC_RET_DATA_ERR (res);
      }
      else if (res == MMC_DATA_TOKEN)
      {
        for (i = 0; i <16 ; ++i)
          *pData++ = spiTransferByte (0xff);

        //
        // CRC receive
        //
        spiTransferByte (0xff);
        spiTransferByte (0xff);
        spiChipSelect (0);
        return (MmcOk);
      }
    }
  }
  // else
  //   printf ("line %d: mmcSendCmd returned %d\n", __LINE__, res); // ###

  spiChipSelect (0);
  MMC_RET_ERROR (res);
}

/*************************************************************************
 * Function Name: mmcRead
 * Parameters: U8 *pData, U32 Add, U32 Length
 *
 * Return: mmcState_t
 *
 * Description: Read from a MMC
 *
 *************************************************************************/
static inline mmcState_t mmcRead (U8 *pData, U32 Add, U32 Length)
{
  U32 res;
  U32 i;

  //
  //  For synchronization
  //
  spiChipSelect (0);
  spiTransferByte (0xff);
  res = mmcSendCmd (CMD17, Add);

  if (res == MMC_OK)
  {
    for (i = Tnac; i; --i)
    {
      res = spiTransferByte (0xff);

      if ((res | MMC_DATA_ERR_TOKEN) == MMC_DATA_ERR_TOKEN)
        MMC_RET_DATA_ERR (res);
      else if (res == MMC_DATA_TOKEN)
      {
        spiReceiveBlock (pData, Length);

        //
        //  CRC receive
        //
        spiTransferByte (0xff);
        spiTransferByte (0xff);
        spiChipSelect (0);
        return (MmcOk);
      }
    }

    spiChipSelect (0);
    return (MmcNoResponse);
  }

  spiChipSelect (0);
  MMC_RET_ERROR (res);
}

/*************************************************************************
 * Function Name: mmcWrite
 * Parameters: U8 *pData, U32 Add, U32 Length
 *
 * Return: mmcState_t
 *
 * Description: Write to a MMC
 *
 *************************************************************************/
static inline mmcState_t mmcWrite (U8 *pData, U32 Add, U32 Length)
{
  U32 res;
  U32 i;

  //
  //  For synchronization
  //
  spiChipSelect (0);
  spiTransferByte (0xff);

  if ((res = mmcSendCmd (CMD24, Add)) == MMC_OK)
  {
    spiTransferByte (0xff);
    spiTransferByte (MMC_DATA_TOKEN);
    spiSendBlock (pData, Length);

    //
    //  CRC Send
    //
    spiTransferByte (0xff);
    spiTransferByte (0xff);

    if ((spiTransferByte (0xff) & 0x1F) != 0x05)
      MMC_RET_ERROR (res);

    for (i = Twr; i ;i--)
      if (spiTransferByte (0xff) == 0xff)
        break;
    
    spiChipSelect (0);

    if (i == 0)
      return (MmcNoResponse);

    return (MmcOk);
  }

  spiChipSelect (0);
  MMC_RET_ERROR (res);
}

/*************************************************************************
 * Function Name: mmcVerify
 * Parameters: U8 *pData, U32 Add, U32 Length
 *
 * Return: mmcState_t
 *
 * Description: Verify on a MMC
 *
 *************************************************************************/
static inline mmcState_t mmcVerify (U8 *pData, U32 Add, U32 Length)
{
  U32 res,i;

  //
  //  For synchronization
  //
  spiChipSelect (0);
  spiTransferByte (0xff);

  if ((res = mmcSendCmd (CMD17, Add)) == MMC_OK)
  {
    for (i = Tnac; i; --i)
    {
      res = spiTransferByte (0xff);

      if ((res | MMC_DATA_ERR_TOKEN) == MMC_DATA_ERR_TOKEN)
        MMC_RET_DATA_ERR (res);
      else if (res == MMC_DATA_TOKEN)
      {
        for (res = 0, i = 0; i < Length; ++i, ++pData)
        {
          *pData ^= spiTransferByte (0xff);

          if (*pData != 0)
            res = 1;
        }

        //
        //  CRC receive
        //
        spiTransferByte (0xff);
        spiTransferByte (0xff);
        spiChipSelect (0);
        spiTransferByte (0xff);
        spiTransferByte (0xff);

        if (res)
          return (MmcMiscompare);

        return (MmcOk);
      }
    }

    return (MmcNoResponse);
  }

  MMC_RET_ERROR (res);
}

//
//
//
DSTATUS diskInitialize (U8 drv __attribute__ ((unused)))
{
  mmcDskStatus.BlockNumb = mmcDskStatus.BlockSize = mmcLastError = 0;

  //
  //  Init SPI
  //
  spiInit ();

  //
  //  Media Init
  //
  switch (mmcInitMedia ())
  {
    case MmcOk :
      {
        mmcCSDImplement ();
        mmcDskStatus.DiskStatus = DiskCommandPass;
        mmcDskStatus.MediaChanged = TRUE;
        Stat = 0;
        if (mmcDskStatus.WriteProtect) 
          Stat |= STA_PROTECT;
      }
      break;

    case MmcCardError :
    case MmcDataError :
      {
        mmcDskStatus.DiskStatus = DiskNotReady;
        Stat = STA_NOINIT;
        if (mmcDskStatus.WriteProtect) 
          Stat |= STA_PROTECT;
      }
      break;

    default:
      {
        mmcDskStatus.DiskStatus = DiskNotPresent;
        Stat = STA_NODISK;
      }
      break;
  }

  return Stat;
}

//
//
//
DSTATUS diskShutdown (void)
{
  Stat |= STA_NOINIT;

  return Stat;
}

//
//
//
DSTATUS diskStatus (U8 drv __attribute__ ((unused)))
{
  return Stat;
}

//
//
//
DRESULT diskRead (U8 disk __attribute__ ((unused)), U8 *buff, U32 sector, U8 count)
{
  U32 res;

  if (Stat & STA_NOINIT) 
    return RES_NOTRDY;
  if (!count) 
    return RES_PARERR;

  res = mmcRead (buff, sector * mmcDskStatus.BlockSize, count * mmcDskStatus.BlockSize);

  if (res == MMC_OK)
    return RES_OK;
  else
    return RES_ERROR; 
}

//
//
//
#if _FS_READONLY == 0
DRESULT diskWrite (U8 disk __attribute__ ((unused)), const U8 *buff, U32 sector, U8 count)
{
  U32 res;

  if (Stat & STA_NOINIT) 
    return RES_NOTRDY;
  if (Stat & STA_PROTECT) 
    return RES_WRPRT;
  if (!count) 
    return RES_PARERR;

  res = mmcWrite ((U8 *) buff, sector * mmcDskStatus.BlockSize, count * mmcDskStatus.BlockSize);

  if (res == MMC_OK)
    return RES_OK;
  else
    return RES_ERROR; 
}
#endif

//
//
//
DRESULT diskIoctl (U8 drv, U8 ctrl, void *buff)
{
  DRESULT res;
  U8 n;
  U8 csd [16];
  U16 csize;

  if (drv) 
    return RES_PARERR;
  if (Stat & STA_NOINIT) 
    return RES_NOTRDY;

  res = RES_ERROR;

  switch (ctrl) 
  {
    case GET_SECTOR_COUNT :
      { 
        mmcState_t jcwres; // ###
        if ((jcwres = mmcReadCardInfo (csd, CMD9)) == MmcOk)                
        {
          //
          //  SDC ver 2.00
          //
          if ((csd [0] >> 6) == 1) 
          { 
            csize = csd [9] + ((U16)csd [8] << 8) + 1;
            *(U32 *) buff = (U32) csize << 10;
          } 
          //
          //  MMC or SDC ver 1.XX
          //
          else 
          {            
            n = (csd [5] & 15) + ((csd [10] & 128) >> 7) + ((csd [9] & 3) << 1) + 2;
            csize = (csd [8] >> 6) + ((U16) csd [7] << 2) + ((U16) (csd [6] & 3) << 10) + 1;
            *(U32 *) buff = (U32) csize << (n - 9);
          }

          res = RES_OK;
        }
        // else // ###
        // printf ("line %d: mmcReadCardInfo returned %d\n", __LINE__, jcwres); // ###
      }
      break;

    case GET_SECTOR_SIZE :
      {
        *(U16 *) buff = 512;
        res = RES_OK;
      }
      break;

    case CTRL_SYNC :
      {
        if (spiWaitReady () == 0xff)
          res = RES_OK;
      }
      break;

    case MMC_GET_CSD :
      {
        if (mmcReadCardInfo (buff, CMD9) == MmcOk)
          res = RES_OK;
      }
      break;

    case MMC_GET_CID :
      {
        if (mmcReadCardInfo (buff, CMD10) == MmcOk)
          res = RES_OK;
      }
      break;

# if 0
    case CTRL_POWER:
    case CTRL_LOCK:
    case CTRL_EJECT:
    case MMC_GET_OCR:     /* Receive OCR as an R3 resp (4 bytes) */
    case ATA_GET_REV:
    case ATA_GET_MODEL:
    case ATA_GET_SN:
#endif                        

    default:
      res = RES_PARERR;
  }

  return res;
}

#if 0
static void mmcDump (U8 *buff, U32 ofs, U8 cnt)
{
  U8 n;

  printf ("\n\r%08X ", ofs);

  for (n = 0; n < cnt; n++)
    printf (" %02X", buff [n]);

  putchar (' ');

  for (n = 0; n < cnt; n++) 
  {
    if ((buff [n] < 0x20) || (buff [n] >= 0x7F))
      putchar ('.');
    else
      putchar (buff [n]);
  }
}
#endif

#if 0
typedef struct csd_11_s
{
  unsigned int not_used_1          : 2;   // 0..1  [121:120]   0x44
  unsigned int mmc_prot            : 4;   // 2..5  [125:122]
  unsigned int csd_structure       : 2;   // 6..7  [127:126]
  unsigned int taac                : 8;   // 0..7  [119:112]   0x26
  unsigned int nsac                : 8;   // 0..7  [111:104]   0x00
  unsigned int tran_speed          : 8;   // 0..7  [103:96]    0x2a
  unsigned int ccc_hi              : 8;   // 0..7  [95:88]     0x1f
  unsigned int read_bl_len         : 4;   // 0..3  [83:80]     0xf9
  unsigned int ccc_lo              : 4;   // 4..7  [87:84]

  unsigned int c_size_hi           : 2;   // 0..1  [73:72]     0x83
  unsigned int not_used_2          : 2;   // 2..3  [75:74]
  unsigned int dsr_imp             : 1;   // 4..4  [76:76]
  unsigned int read_blk_misalign   : 1;   // 5..5  [77:77]
  unsigned int write_blk_misalign  : 1;   // 6..6  [78:78]
  unsigned int read_bl_partial     : 1;   // 7..7  [79:79]
  unsigned int c_size_mid          : 8;   // 0..7  [71:64]     0xd3
  unsigned int vdd_r_curr_max      : 3;   // 0..1  [58:56]     0xe3
  unsigned int vdd_r_curr_min      : 3;   // 2..5  [61:59]
  unsigned int c_size_lo           : 2;   // 6..7  [63:62]

  unsigned int c_size_mult_hi      : 2;   // 0..1  [49:48]     0x91
  unsigned int vdd_w_curr_max      : 3;   // 2..4  [52:50]
  unsigned int vdd_w_curr_min      : 3;   // 4..7  [55:53]
  unsigned int erase_grp_size_lo   : 2;   // 0..1  [41:40]     0x83
  unsigned int sector_size         : 5;   // 2..6  [46:42]
  unsigned int c_size_mult_lo      : 1;   // 7..7  [47:47]
  unsigned int wp_grp_size         : 5;   // 0..4  [36:32]     0xff
  unsigned int erase_grp_size_hi   : 3;   // 5..7  [39:37]

  unsigned int write_bl_len_hi     : 2;   // 0..1  [25:24]     0x92
  unsigned int r2w_factor          : 3;   // 2..4  [28:26]
  unsigned int default_ecc         : 2;   // 5..6  [30:29]
  unsigned int wp_grp_enable       : 1;   // 7..7  [31:31]     
  unsigned int not_used_3          : 5;   // 0..4  [20:16]     0x40
  unsigned int write_bl_partial    : 1;   // 5..5  [21:21]
  unsigned int write_bl_len_lo     : 2;   // 6..7  [23:22]

  unsigned int ecc                 : 2;   // 0..1  [9:8]       0x40
  unsigned int not_used_5          : 2;   // 2..3  [11:10]
  unsigned int tmp_write_protect   : 1;   // 4..4  [12:12]
  unsigned int perm_write_protect  : 1;   // 5..5  [13:13]
  unsigned int copy                : 1;   // 6..6  [14:14]
  unsigned int not_used_4          : 1;   // 7..7  [15:15]

  unsigned int notused_6           : 1;   // 0..0  [0:0]       0x67
  unsigned int crc                 : 7;   // 1..7  [7:1]
}
__attribute__ ((packed)) csd_11_t;

static void mmcDecode (U8 *buffer)
{
  csd_11_t *p = (csd_11_t *) buffer;

  printf ("\n");
  printf ("sizeof (csd_11_t)     : %lu\n",    sizeof (csd_11_t));
  printf ("CSD structure version : 1.%d\n",   p->csd_structure);
  printf ("MMC protocol version  : %d\n",     p->mmc_prot);
  printf ("TAAC                  : 0x%02x\n", p->taac);
  printf ("NSAC                  : 0x%02x\n", p->nsac);
  printf ("TRAN_SPEED            : 0x%02x\n", p->tran_speed);
  printf ("CCC                   : 0x%03x\n", (p->ccc_hi << 4) | p->ccc_lo);
  printf ("READ_BL_LEN           : %d\n",     p->read_bl_len);
  printf ("READ_BL_PARTIAL       : %d\n",     p->read_bl_partial);
  printf ("WRITE_BLK_MISALIGN    : %d\n",     p->write_blk_misalign);
  printf ("READ_BLK_MISALIGN     : %d\n",     p->read_blk_misalign);
  printf ("DSR_IMP               : %d\n",     p->read_blk_misalign);
  printf ("C_SIZE                : %d\n",     (p->c_size_hi << 10) | (p->c_size_mid << 2) | p->c_size_lo);
  printf ("VDD_R_CURR_MIN        : %d\n",     p->vdd_r_curr_min);
  printf ("VDD_R_CURR_MAX        : %d\n",     p->vdd_r_curr_max);
  printf ("VDD_W_CURR_MIN        : %d\n",     p->vdd_w_curr_min);
  printf ("VDD_W_CURR_MAX        : %d\n",     p->vdd_w_curr_max);
  printf ("VDD_W_CURR_MAX        : %d\n",     p->vdd_w_curr_max);
  printf ("C_SIZE_MULT           : %d\n",     (p->c_size_mult_hi << 1) | p->c_size_mult_lo);
  printf ("SECTOR_SIZE           : %d\n",     p->sector_size);
  printf ("ERASE_GRP_SIZE        : %d\n",     (p->erase_grp_size_hi << 2) | p->erase_grp_size_lo);
  printf ("WP_GRP_SIZE           : %d\n",     p->wp_grp_size);
  printf ("WP_GRP_ENABLE         : %d\n",     p->wp_grp_enable);
  printf ("DEFAULT_ECC           : %d\n",     p->default_ecc);
  printf ("R2W_FACTOR            : %d\n",     p->r2w_factor);
  printf ("WRITE_BL_LEN          : %d\n",     (p->write_bl_len_hi << 2) | p->write_bl_len_lo);
  printf ("WRITE_BL_PARTIAL      : %d\n",     p->write_bl_partial);
  printf ("COPY                  : %d\n",     p->copy);
  printf ("PERM_WRITE_PROTECT    : %d\n",     p->perm_write_protect);
  printf ("TMP_WRITE_PROTECT     : %d\n",     p->tmp_write_protect);
  printf ("ECC                   : %d\n",     p->ecc);
  printf ("MEDIA SIZE            : %u\n",     (U32) (((p->c_size_hi << 10) | (p->c_size_mid << 2) | p->c_size_lo) + 1) *
                                              (U32) (4 << ((p->c_size_mult_hi << 1) | p->c_size_mult_lo)) *
                                              (U32) (1 << (p->read_bl_len)));
}
#endif


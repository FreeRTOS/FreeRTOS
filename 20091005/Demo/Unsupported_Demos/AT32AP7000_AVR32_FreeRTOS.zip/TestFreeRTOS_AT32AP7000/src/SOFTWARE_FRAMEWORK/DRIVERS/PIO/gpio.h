/* This header file is part of the ATMEL AVR32-SoftwareFramework-AT32AP7000-1.0.0 Release */

#ifndef gpio_h
#define gpio_h

#include "pio.h"

#endif

void a()
{
   int i = 0;
   int h = 0h;
}

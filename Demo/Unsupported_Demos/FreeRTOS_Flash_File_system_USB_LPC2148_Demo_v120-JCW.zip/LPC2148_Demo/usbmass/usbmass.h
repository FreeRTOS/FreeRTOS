#ifndef _USBMASS_H_
#define _USBMASS_H_

void usbmassInit (void);

#endif

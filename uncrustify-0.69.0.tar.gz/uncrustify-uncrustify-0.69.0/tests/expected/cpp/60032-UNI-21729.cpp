extern "C" void __declspec(dllexport) GetAccountNameAndDomain(HWND /*hwndParent*/, int string_size, TCHAR * variables, stack_t** stacktop, extra_parameters* /*extra*/)
{
}

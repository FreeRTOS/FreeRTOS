//The space shouldn't be removed. This is a STRUCT
struct ALIGN_TYPE(16) StructName;

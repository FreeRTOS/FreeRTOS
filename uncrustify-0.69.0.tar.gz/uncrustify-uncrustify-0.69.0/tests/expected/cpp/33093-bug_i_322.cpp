STDMETHOD(GetValues)(BSTR bsName, REFDATA** pData);

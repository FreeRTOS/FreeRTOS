March 3, 2009

Demo board used:  Spectrum Digital OMAP-L137 Start Kit, TMDXOSKL137BET

This project was built using the TI Code Composer Studio V3.3.81.11, TMS470R2X compiler/assembler V4.4.12.

The installation directory for Code Composer was C:\CCStudio_v3.3_OMAP.

FreeRTOS was located in the MyProjects directory of Code Composer, C:\CCStudio_v3.3_OMAP\MyProjects.

It will be necessary to change the compiler build options for -i references if a different directory
is used.  The C_DIR environment variable did not seem to work so hard references had to be supplied 
for the FreeRTOS include directories.

When using JTAG be sure to do a Debug->CPU Reset, Debug->Restart, after loading new code.  The reset
is needed to disable interrupts and clear the timer prior to running.  This is needed if you have
been already running existing code and want to run new code.  The timer is set to continue running in 
the background and if you run a new load without the reset then you will immediately get a timer tick
interrupt and end up at the SWI vector of FreeRTOS.  Since you loaded new code and the vector is soft
it loops to itself until properly initialized.

Currently this is not a completely tested port of FreeRTOS but given the limited documentation
available for the OMAP, especially with regards to ARM9 interrupt handling (AINTC), it should be of 
help to others.  Testing of queues and mutexes is needed but do not see any reason it should not work
given this is a standard ARM9 core.  Threads, pre-emption, delays, and general interrupts seem to
be functional.

Note:  Only IRQ interrupts have been configured, not FIQ, they are currently disabled.









/*
	FreeRTOS.org V4.7.0 - Copyright (C) 2003-2007 Richard Barry.
	TriCore port - written by Adriaan Schmidt, Copyright (C) 2008 Siemens AG.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	The TriCore port is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license
	and contact details.  Please ensure to read the configuration and relevant
	port sections of the online documentation.

	Also see http://www.SafeRTOS.com a version that has been certified for use
	in safety critical systems, plus commercial licensing, development and
	support options.
	***************************************************************************
*/

#ifndef __INCLUDE_TRICORE_BOARD_SETUP_H__
#define __INCLUDE_TRICORE_BOARD_SETUP_H__

#define CONFIG_F_EXT (20000000U)
#define CONFIG_F_CPU (150000000U)
#define CONFIG_F_SYS (CONFIG_F_CPU / 2)

#define PLL_PDIV (1) /* don't change */
#define PLL_KDIV (4) /* don't change */
#define PLL_NDIV (CONFIG_F_CPU * PLL_KDIV / CONFIG_F_EXT)


#ifdef TRICORE_TARGET_HIGHTEC_EASYRUN

#define EBU_CON_VALUE		0x0000ff68
#define EBU_BFCON_VALUE		0x001001d0

/* CS0: external MRAM */
#define EBU_ADDRSEL0_VALUE	0xA1000873
#define EBU_BUSCON0_VALUE	0x00920000
#define EBU_BUSAP0_VALUE	0x81200010
/* CS1: external flash, not used */
#define EBU_ADDRSEL1_VALUE	0xA4000852
#define EBU_BUSCON1_VALUE	0x00920000
#define EBU_BUSAP1_VALUE	0xC7B30000
/* CS2: usb, disabled */
#define EBU_ADDRSEL2_VALUE	0xD90000C0
#define EBU_BUSCON2_VALUE	0x00420000
#define EBU_BUSAP2_VALUE	0x40D809F0
/* CS3: ethernet, works */
#define EBU_ADDRSEL3_VALUE	0xD80000C1
#define EBU_BUSCON3_VALUE	0x00820000
#define EBU_BUSAP3_VALUE	0x40D80000

#endif /* HIGHTEC_EASYRUN */

#ifdef TRICORE_TARGET_INFINEON_TRIBOARD

#define EBU_CON_VALUE		0x00F9FF68
#define EBU_BFCON_VALUE		0x001001D0

/* CS0: AMD AM29BL162CB flash */
#define EBU_ADDRSEL0_VALUE	0xA2000051
#define EBU_BUSCON0_VALUE	0x00820000
#define EBU_BUSAP0_VALUE	0x23FF0100
/* CS1: ALLIANCE SRAM */
#define EBU_ADDRSEL1_VALUE	0xA1000071
#define EBU_BUSCON1_VALUE	0x00820000
#define EBU_BUSAP1_VALUE	0x00D80000
/* CS2: unused */
#define EBU_ADDRSEL2_VALUE	0x00000000
#define EBU_BUSCON2_VALUE	0x80928000
#define EBU_BUSAP2_VALUE	0xCFFFFFFF
/* CS3: unused */
#define EBU_ADDRSEL3_VALUE	0x00000000
#define EBU_BUSCON3_VALUE	0x80928000
#define EBU_BUSAP3_VALUE	0xCFFFFFFF

#endif /* INFINEON_TRIBOARD */

#define PLL_CLC_VALUE		(((PLL_NDIV-1)	<< PLL_CLC_NDIV_SHIFT) \
							|((PLL_KDIV-1)	<< PLL_CLC_KDIV_SHIFT) \
							|((PLL_PDIV-1)	<< PLL_CLC_PDIV_SHIFT) \
							|(2				<< PLL_CLC_VCOSEL_SHIFT))

#define PMI_CON0_VALUE		0x00000000

#endif /* __INCLUDE_TRICORE_BOARD_SETUP_H__ */

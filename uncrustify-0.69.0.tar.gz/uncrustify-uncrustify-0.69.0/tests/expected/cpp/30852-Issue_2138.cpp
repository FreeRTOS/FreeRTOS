void funcName() const;
void ncName() override;

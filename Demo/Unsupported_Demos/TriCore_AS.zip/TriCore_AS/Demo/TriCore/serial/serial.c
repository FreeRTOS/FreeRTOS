/*
	FreeRTOS.org V4.7.0 - Copyright (C) 2003-2007 Richard Barry.
	TriCore port - written by Adriaan Schmidt, Copyright (C) 2008 Siemens AG.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	The TriCore port is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license
	and contact details.  Please ensure to read the configuration and relevant
	port sections of the online documentation.

	Also see http://www.SafeRTOS.com a version that has been certified for use
	in safety critical systems, plus commercial licensing, development and
	support options.
	***************************************************************************
*/

/* BASIC INTERRUPT DRIVEN SERIAL PORT DRIVER. */

/* FreeRTOS includes */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "port_irq.h"

#include "serial.h"

/* TriCore includes */
#include <machine/wdtcon.h>
#include <tc1796b/p5.h>
#include <tc1796b/asc0.h>
#include <tc1796b/asc1.h>

static xQueueHandle xRxedChars[2];
static xQueueHandle xCharsForTx[2];

#define pdASC0RxIrqPrio 4
#define pdASC0TxIrqPrio 3
#define pdASC1RxIrqPrio 6
#define pdASC1TxIrqPrio 5

#define serialInChar(port) ((unsigned char) port##_RBUF.bits.RD_VALUE)
#define serialOutChar(port, x) port##_TBUF.bits.TD_VALUE = x;

portIRQ_FUNCTION_PROTO(vSerialTxHandler);
portIRQ_FUNCTION_PROTO(vSerialRxHandler);


static unsigned portBASE_TYPE prvSerialGlobalInitialised = 0;
static unsigned portBASE_TYPE prvSerialPortInitialised[2] = {0, 0};
static unsigned portBASE_TYPE prvSerialWorking[2] = {0, 0};

/*-----------------------------------------------------------*/
#define SerialRxHandler(asc, number) \
	portIRQ_FUNCTION( v##asc##RxHandler ) \
	{ \
	signed portCHAR cChar; \
		cChar = serialInChar(asc); \
			if( xQueueSendFromISR( xRxedChars[number], &cChar, pdFALSE ) ) { \
				taskYIELD(); \
			} \
	}

SerialRxHandler(ASC0, 0)
SerialRxHandler(ASC1, 1)
/*-----------------------------------------------------------*/

#define SerialTxHandler(asc, number) \
	portIRQ_FUNCTION( v##asc##TxHandler ) \
	{ \
	signed portCHAR cChar; \
	portBASE_TYPE cTaskWoken; \
	\
		if( xQueueReceiveFromISR( xCharsForTx[number], &cChar, &cTaskWoken ) == pdTRUE ) { \
			prvSerialWorking[number] = 1; \
			serialOutChar(asc, cChar); \
		} else { \
			prvSerialWorking[number] = 0; \
		} \
	}

SerialTxHandler(ASC0, 0)
SerialTxHandler(ASC1, 1)
/*-----------------------------------------------------------*/

xComPortHandle xSerialPortInit( eCOMPort ePort, eBaud eWantedBaud, eParity eWantedParity, eDataBits eWantedDataBits, eStopBits eWantedStopBits, unsigned portBASE_TYPE uxBufferLength )
{
	/* eWantedParity, eWantedDataBits and eWantedStopBits are ignored */
unsigned portLONG reload_value, fdv, dfreq;
unsigned portBASE_TYPE uxPort;
unsigned portLONG ulWantedBaud;

	if ( ePort == serCOM1 ) {
		uxPort = 0;
	} else if ( ePort == serCOM2 ) {
		uxPort = 1;
	} else {
		return (xComPortHandle) -1;
	}

	switch (eWantedBaud) {
		case ser50: ulWantedBaud = 50; break;
		case ser75: ulWantedBaud = 75; break;
		case ser110: ulWantedBaud = 110; break;
		case ser134: ulWantedBaud = 134; break;
		case ser150: ulWantedBaud = 150; break;
		case ser200: ulWantedBaud = 200; break;
		case ser300: ulWantedBaud = 300; break;
		case ser600: ulWantedBaud = 600; break;
		case ser1200: ulWantedBaud = 1200; break;
		case ser1800: ulWantedBaud = 1800; break;
		case ser2400: ulWantedBaud = 2400; break;
		case ser4800: ulWantedBaud = 4800; break;
		case ser9600: ulWantedBaud = 9600; break;
		case ser19200: ulWantedBaud = 19200; break;
		case ser38400: ulWantedBaud = 38400; break;
		case ser57600: ulWantedBaud = 57600; break;
		case ser115200: ulWantedBaud = 115200; break;
		default: return (xComPortHandle) -1;
	}

	if (!prvSerialGlobalInitialised) {
		/* do general serial port setup */
		unlock_wdtcon();
		ASC0_CLC.bits.RMC = 1;
		ASC0_CLC.bits.DISR = 0;
		lock_wdtcon();

		// configure port pins
		P5_IOCR0.bits.PC1 = 9; // alternate function 1
		P5_OMR.bits.PS1 = 1;
		P5_IOCR0.bits.PC3 = 9; // alternate function 1
		P5_OMR.bits.PS3 = 1;

		prvSerialGlobalInitialised = 1;
	}

	portENTER_CRITICAL();
	{
		/* Create the queues used by the com test task. */
		xRxedChars[uxPort] = xQueueCreate( uxBufferLength, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );
		xCharsForTx[uxPort] = xQueueCreate( uxBufferLength, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );

		// calculate frequency settings
		reload_value = (configCPU_CLOCK_HZ / (ulWantedBaud * 16)) - 1;
		dfreq = configCPU_CLOCK_HZ / (16*512);
		fdv = (reload_value + 1) * ulWantedBaud / dfreq;

#define INIT_ASC_PORT(asc) \
			asc##_CON.reg = 0; \
			asc##_BG.reg  = reload_value; \
			asc##_FDV.reg = fdv; \
			\
			asc##_CON.bits.M = 1; \
			asc##_CON.bits.R = 1; \
			asc##_CON.bits.REN = 1; \
			asc##_CON.bits.FDE = 1; \
			\
			asc##_TBSRC.bits.SRPN = pd##asc##TxIrqPrio; \
			asc##_TBSRC.bits.SRE = 1; \
			asc##_RSRC.bits.SRPN = pd##asc##RxIrqPrio; \
			asc##_RSRC.bits.SRE = 1; \
			\
			vIrqSetVector(pd##asc##TxIrqPrio, v##asc##TxHandler, pd##asc##TxIrqPrio); \
			vIrqSetVector(pd##asc##RxIrqPrio, v##asc##RxHandler, pd##asc##RxIrqPrio);

		if ( uxPort == 0 ) {
			// program ASC0
			INIT_ASC_PORT(ASC0);
		} else if ( uxPort == 1) {
			// program ASC1
			INIT_ASC_PORT(ASC1);
		}
		prvSerialPortInitialised[uxPort] = 1;
	}
	portEXIT_CRITICAL();

	return (xComPortHandle) uxPort;
}
/*-----------------------------------------------------------*/

signed portBASE_TYPE xSerialGetChar( xComPortHandle pxPort, signed portCHAR *pcRxedChar, portTickType xBlockTime )
{
	unsigned portBASE_TYPE uxPort = (unsigned portBASE_TYPE) pxPort;

	if ( !prvSerialPortInitialised[uxPort] ) {
		return pdFALSE;
	}

	/* Get the next character from the buffer.	Return false if no characters
	are available, or arrive before xBlockTime expires. */
	if( xQueueReceive( xRxedChars[uxPort], pcRxedChar, xBlockTime ) )
	{
		return pdTRUE;
	}
	else
	{
		return pdFALSE;
	}
}
/*-----------------------------------------------------------*/

signed portBASE_TYPE xSerialPutChar( xComPortHandle pxPort, signed portCHAR cOutChar, portTickType xBlockTime )
{
	unsigned portBASE_TYPE uxPort = (unsigned portBASE_TYPE) pxPort;

	if ( !prvSerialPortInitialised[uxPort] ) {
		return pdFAIL;
	}

	/* Return false if after the block time there is no room on the Tx queue. */
	if( xQueueSend( xCharsForTx[uxPort], &cOutChar, xBlockTime ) != pdPASS )
	{
		return pdFAIL;
	}

	/* in case we are not transmitting, trigger the transmit */
	if ( prvSerialWorking[uxPort] == 0 ) {
		if (uxPort == 0) {
			ASC0_TBSRC.bits.SETR = 1;
		} else if (uxPort == 1) {
			ASC1_TBSRC.bits.SETR = 1;
		}
	}
	return pdPASS;
}
/*-----------------------------------------------------------*/

void vSerialPutString( xComPortHandle pxPort, const signed portCHAR * const pcString, unsigned portSHORT usStringLength )
{
	const signed portCHAR *i = pcString;
	while (*i != 0) {
		if (xSerialPutChar(pxPort, *i, 10) == pdFAIL) {
			return;
		}
		i++;
	}
}

void vSerialClose( xComPortHandle xPort )
{
	unsigned portBASE_TYPE uxPort = (unsigned portBASE_TYPE) xPort;

	if ( !prvSerialPortInitialised[uxPort] ) {
		return;
	}

#define CLOSE_ASC_PORT(asc) \
		asc##_CON.bits.REN = 0; \
		\
		asc##_TBSRC.bits.SRE = 0; \
		asc##_RSRC.bits.SRE = 0;

	if ( uxPort == 0 ) {
		// program ASC0
		CLOSE_ASC_PORT(ASC0);
	} else if ( uxPort == 1) {
		// program ASC1
		CLOSE_ASC_PORT(ASC1);
	}
}
/*-----------------------------------------------------------*/


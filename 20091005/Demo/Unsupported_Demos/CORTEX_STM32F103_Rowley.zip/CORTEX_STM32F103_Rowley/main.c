/*
	FreeRTOS.org V5.1.2 - Copyright (C) 2003-2009 Richard Barry.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license
	and contact details.  Please ensure to read the configuration and relevant
	port sections of the online documentation.
	***************************************************************************
*/

/*
 * This file contains a demo created to execute on the STM3210B-EVAL board
 * from Rowley Associates Crossworks for ARM.
 *
 * main() creates all the demo application tasks, then starts the scheduler.
 * The WEB documentation provides more details of the standard demo application
 * tasks.
 *
 * Main.c also creates a task called "Check".  This only executes every few
 * seconds but has a high priority so is guaranteed to get processor time.
 * Its function is to check that all the other tasks are still operational.
 * Each standard demo task maintains a unique count that is incremented each
 * time the task successfully completes its function.  Should any error occur
 * within such a task the count is permanently halted.  The check task inspects
 * the count of each task to ensure it has changed since the last time the
 * check task executed.  If all the count variables have changed all the tasks
 * are still executing error free, and the check task writes "PASS" to the
 * CrossStudio terminal IO window.  Should any task contain an error at any time
 * the error is latched and "FAIL" written to the terminal IO window.
 *
 * Finally, main() sets up an interrupt service routine and task to handle
 * pushes of the button that is built into the CrossFire board.  When the button
 * is pushed the ISR wakes the button task - which generates a table of task
 * status information which is also displayed on the terminal IO window.
 *
 * A print task is defined to ensure exclusive and consistent access to the
 * terminal IO.  This is the only task that is allowed to access the terminal.
 * The check and button task therefore do not access the terminal directly but
 * instead pass a pointer to the message they wish to display to the print task.
 */

/*
 * Some demo application tasks have been commented out to shift the focus to
 * more board specific functions. If there is still enough memory available
 * then it should be possible to re-insert it again.
 */

/* Standard includes. */
#include <__cross_studio_io.h>

/* some definitions, what to use in STM32 */
#include "stm32f10x_lib.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

/* use private font */
#include "fonts.h"
#include "lcd.h"

/* Demo app includes. */
/*
#include "BlockQ.h"
#include "death.h"
#include "dynamic.h"
#include "integer.h"
#include "PollQ.h"
#include "blocktim.h"
*/

#define DEBUG_PRINTF(...)  debug_printf(__VA_ARGS__)
#define NODEBUG_PRINTF(...)

#define DBG_USE_BUTTON_HANDLER	1
#define DBG_USE_JTAG_PRINT		0


/* Hardware configuration definitions. */

/* Demo application definitions. */
#define mainQUEUE_SIZE					( 3 )
#define mainLED_DELAY					(( portTickType )( 2000) / portTICK_RATE_MS )
#define mainCHECK_DELAY					(( portTickType )( 5000) / portTICK_RATE_MS )
#define mainLIST_BUFFER_SIZE			1024

/* Task priorities. */
#define mainLED_TASK_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define mainQUEUE_POLL_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define mainCHECK_TASK_PRIORITY			( tskIDLE_PRIORITY + 1 )
#define mainBUTTON_TASK_PRIORITY		( tskIDLE_PRIORITY + 4 )
#define mainSEM_TEST_PRIORITY			( tskIDLE_PRIORITY + 1 )
#define mainBLOCK_Q_PRIORITY			( tskIDLE_PRIORITY + 2 )
#define mainPRINT_TASK_PRIORITY			( tskIDLE_PRIORITY + 0 )
#define mainLCD_TASK_PRIORITY			( tskIDLE_PRIORITY + 1 )
#define mainADC_TASK_PRIORITY			( tskIDLE_PRIORITY + 3 )

/*-----------------------------------------------------------*/

/* The semaphore used to wake the button task from within the external interrupt
handler. */
#if (DBG_USE_BUTTON_HANDLER != 0)
xSemaphoreHandle xButtonSemaphore;
#endif /* DBG_USE_BUTTON_HANDLER */

/* The queue that is used to send message to vPrintTask for display in the
terminal output window. */
#if (DBG_USE_JTAG_PRINT != 0)
xQueueHandle xPrintQueue;
#endif /* DBG_USE_JTAG_PRINT */

/* The queue that is used to send messages to vLCDTask */
xQueueHandle lcdQueue;

/*-----------------------------------------------------------*/

/*
 * Simply flashes the on board LED every mainLED_DELAY milliseconds.
 */
static void vLEDTask( void *pvParameters );

#ifdef	__LCD_H
/*
 * Initializes and displays character lines on the eval board display.
 */
static void vLCDTask( void *pvParameters );
#endif	/* __LCD_H */

#ifdef	__STM32F10x_ADC_H
extern void vADCTask( void *pvParameters );
#endif	/* __STM32F10x_ADC_H */

/*
 * Checks the status of all the demo tasks then prints a message to the
 * CrossStudio terminal IO windows.  The message will be either PASS or FAIL
 * depending on the status of the demo applications tasks.  A FAIL status will
 * be latched.
 *
 * Messages are not written directly to the terminal, but passed to vPrintTask
 * via a queue.
 */
static void vCheckTask( void *pvParameters );

/*
 * Controls all terminal output.  If a task wants to send a message to the
 * terminal IO it posts a pointer to the text to vPrintTask via a queue.  This
 * ensures serial access to the terminal IO.
 */
static void vPrintTask( void *pvParameter );

/*
 * Simply waits for an interrupt to be generated from the built in button, then
 * generates a table of tasks states that is then written by vPrintTask to the
 * terminal output window within CrossStudio.
 */
#if (DBG_USE_BUTTON_HANDLER != 0)
static void vButtonHandlerTask( void *pvParameters );
#endif /* DBG_USE_BUTTON_HANDLER */


/*
 * function prototypes related to STM32
 */
void RCC_Configuration(void);
void GPIO_LED_Configuration(void);
void GPIO_BTN_Configuration(void);
void NVIC_Configuration(void);


/*****************************************************************************/
	int	main( void )
/*****************************************************************************/
{
#ifdef DEBUG
  debug();
#endif /* DEBUG */

  /* Configure the system clocks */
  RCC_Configuration();

#if (DBG_USE_JTAG_PRINT != 0)
  /* Create the queue used to pass message to vPrintTask. */
  xPrintQueue = xQueueCreate( mainQUEUE_SIZE, sizeof( portCHAR * ) );
#endif /* DBG_USE_JTAG_PRINT */

#ifdef	__LCD_H
  /* Create the queue used to pass message to LCDTask. */
  lcdQueue = xQueueCreate( 10, sizeof(LCD_QUEUE_ELEMENT) );
#endif	/* __LCD_H */

#if (DBG_USE_BUTTON_HANDLER != 0)
  /* Create the semaphore used to wake vButtonHandlerTask(). */
  vSemaphoreCreateBinary( xButtonSemaphore );
  xSemaphoreTake( xButtonSemaphore, 0 );
#endif /* DBG_USE_BUTTON_HANDLER */

  /* Start the standard demo tasks. */
/*
  vStartIntegerMathTasks( tskIDLE_PRIORITY );
  vStartPolledQueueTasks( mainQUEUE_POLL_PRIORITY );
  vStartSemaphoreTasks( mainSEM_TEST_PRIORITY );
  vStartDynamicPriorityTasks();
  vStartBlockingQueueTasks( mainBLOCK_Q_PRIORITY );
  CreateBlockTimeTasks();
*/

  /* Start the tasks defined within this file. */
  xTaskCreate( vLEDTask, "LED", configMINIMAL_STACK_SIZE, NULL, mainLED_TASK_PRIORITY, NULL );
  xTaskCreate( vCheckTask, "Check", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );

#ifdef	__LCD_H
  xTaskCreate( vLCDTask, "Display", configMINIMAL_STACK_SIZE, NULL, mainLCD_TASK_PRIORITY, NULL );
#endif	/* __LCD_H */

#if (DBG_USE_JTAG_PRINT != 0)
  xTaskCreate( vPrintTask, "Print", configMINIMAL_STACK_SIZE, NULL, mainPRINT_TASK_PRIORITY, NULL );
#endif /* DBG_USE_JTAG_PRINT */

#if (DBG_USE_BUTTON_HANDLER != 0)
  xTaskCreate( vButtonHandlerTask, "Button", configMINIMAL_STACK_SIZE, NULL, mainBUTTON_TASK_PRIORITY, NULL );
#endif /* DBG_USE_BUTTON_HANDLER */

#ifdef	__STM32F10x_ADC_H
  xTaskCreate( vADCTask, "ADC", configMINIMAL_STACK_SIZE, NULL, mainADC_TASK_PRIORITY, NULL );
#endif //* __STM32F10x_ADC_H */

  /* Start the scheduler. */
  vTaskStartScheduler();

  /* The scheduler should now running, so we will only ever reach here if we
     ran out of heap space. */

  return( 0 );
}


/*****************************************************************************/
	static void	vLEDTask( void *pvParameters )
/*****************************************************************************/
{
static int ledCtr = 0;
const u32 ledSetValue[4] = {GPIO_Pin_6,GPIO_Pin_7,GPIO_Pin_8,GPIO_Pin_7};
const u32 ledClrValue[4] = {GPIO_Pin_7,GPIO_Pin_6,GPIO_Pin_7,GPIO_Pin_8};

  /* Configure GPIOs */
  GPIO_LED_Configuration();

  for( ;; )	{
	/* Not very exiting - just delay... */
	vTaskDelay( mainLED_DELAY );
	/* ... and toggle LEDs */
	GPIO_SetBits(GPIOC, ledSetValue[(ledCtr & 0x03)]);
	GPIO_ResetBits(GPIOC, ledClrValue[(ledCtr++ & 0x03)]);
	}
}


/*****************************************************************************/
	static void	vCheckTask( void *pvParameters )
/*****************************************************************************/
{
portBASE_TYPE xErrorOccurred;
portTickType xLastExecutionTime;
static portCHAR cResult[32];
const portCHAR *pcCheckResult = &(cResult[0]);
LCD_QUEUE_ELEMENT	lcdCmd;

  /* Initialise xLastExecutionTime so the first call to vTaskDelayUntil()
     works correctly. */
  xLastExecutionTime = xTaskGetTickCount();

#ifdef	__LCD_H
  lcdCmd.command = 0x11;
  lcdCmd.par1 = Line9 + 8*FONT_HEIGHT;
  lcdCmd.par2 = (0x14) | (0x0 << 6) | (0x0 << 11); // Dark Blue;
  lcdCmd.paraPtr = cResult;
  xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );

  lcdCmd.command = 2;
#endif	/* __LCD_H */

  for( ;; )	{
	xErrorOccurred = 0;

	/* Perform this check every mainCHECK_DELAY milliseconds. */
	vTaskDelayUntil( &xLastExecutionTime, mainCHECK_DELAY );

	/* Has an error been found in any task? */
/*	if( xAreIntegerMathsTaskStillRunning() != pdTRUE )	{
		xErrorOccurred |= 0x01;
		}
	if( xArePollingQueuesStillRunning() != pdTRUE )	{
		xErrorOccurred |= 0x02 ;
		}
	if( xAreSemaphoreTasksStillRunning() != pdTRUE )	{
		xErrorOccurred |= 0x04;
		}
	if( xAreDynamicPriorityTasksStillRunning() != pdTRUE )	{
		xErrorOccurred |= 0x08;
		}
	if( xAreBlockingQueuesStillRunning() != pdTRUE )	{
		xErrorOccurred |= 0x10;
		}
	if( xAreBlockTimeTestTasksStillRunning() != pdTRUE )	{
		xErrorOccurred |= 0x20;
		}
	if(xErrorOccurred)  {
		sprintf( cResult, "CheckErr= 0x%X \n", xErrorOccurred);
		}
*/

	sprintf( cResult, "CurrTime=%ld, Heap=%u  \n", xTaskGetTickCount(), vPortGetHeapSize());
#ifdef	__LCD_H
	xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );
#endif	/* __LCD_H */
#if (DBG_USE_JTAG_PRINT != 0)
	xQueueSend( xPrintQueue, &pcCheckResult, portMAX_DELAY );
#endif /* DBG_USE_JTAG_PRINT */
	}
}


#ifdef	 __LCD_H
/*****************************************************************************/
	static void	vLCDTask( void *pvParameters )
/*****************************************************************************/
{
LCD_QUEUE_ELEMENT	lcdMessage;

  /* Initialize the LCD */
  STM3210B_LCD_Init();

  /* Clear the LCD */
  LCD_Clear(Black);
  /* Set the Back Color */
  LCD_SetBackColor(Black);
  /* Display FreeRTOS-Logo */
  LCD_DisplayLogo();
  /* Set the Text Color (R G B) */
  LCD_SetTextColor( White );
  /* wait two seconds */
  vTaskDelay( 3500 / portTICK_RATE_MS );
  /* Clear the LCD again */
  LCD_Clear(Black);

  for( ;; )	{
	/* Wait for a message to arrive. */
	while( xQueueReceive( lcdQueue, &lcdMessage, portMAX_DELAY ) != pdPASS );

	/* check message type and handle parameters accordingly */
	if(lcdMessage.command == 1)	{
		// display message from button task to console
		LCD_SetBackColor(lcdMessage.par2);
		LCD_DisplayStringLine(lcdMessage.par1, (u8 *)lcdMessage.paraPtr);
		}
	else if(lcdMessage.command == 2)	{
		// display message from check task to console
		LCD_SetBackColor(lcdMessage.par2);
		LCD_DisplayStringLine(lcdMessage.par1, (u8 *)lcdMessage.paraPtr);
		}
	else if(lcdMessage.command == 0x10)	{
		// clear button task messages
		if(lcdMessage.par1 == 0)
			LCD_FillRect(0, 320-1, Line9 + FONT_HEIGHT*6, 320, lcdMessage.par2);
		else
			LCD_FillRect(0, 320-1, Line9 + FONT_HEIGHT, 320, lcdMessage.par2);
		}
	else if(lcdMessage.command == 0x11)	{
		// clear check task messages or
		// clear ADC task messages
		LCD_FillRect(lcdMessage.par1 - 3, 320-1, FONT_HEIGHT+4, 320, lcdMessage.par2);
		}
	}
}
#endif	/* __LCD_H */


#if (DBG_USE_JTAG_PRINT != 0)
/*****************************************************************************/
	static void	vPrintTask( void *pvParameters )
/*****************************************************************************/
{
portCHAR *pcMessage;

  for( ;; )	{
	/* Wait for a message to arrive. */
	while( xQueueReceive( xPrintQueue, &pcMessage, portMAX_DELAY ) != pdPASS );

	/* Write the message to the terminal IO. */
	DEBUG_PRINTF( "%s", pcMessage );
	}
}
#endif /* DBG_USE_JTAG_PRINT */


#if (DBG_USE_BUTTON_HANDLER != 0)
/*****************************************************************************/
	static void	vButtonHandlerTask( void *pvParameters )
/*****************************************************************************/
{
static portCHAR cListBuffer[ mainLIST_BUFFER_SIZE ];
const portCHAR *pcList = &( cListBuffer[ 0 ] );
const portCHAR * const pcHeader = "\nTask          State  Priority  Stack	#\n____________________________________________";
#ifdef __LCD_H
const portCHAR * const charSet = "Character Set\n(press \"Key\"-Button to clear):\n\n!\"#$\%&\'()*+,-./\n0123456789\n:;<=>?\nABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`\nabcdefghijklmnopqrstuvwxyz{|}~";
LCD_QUEUE_ELEMENT	lcdCmd;
#endif	/* __LCD_H */

/* Configure the interrupt.
   On the STM3210B Eval Board the "User Button", connected to PB9 is used
*/
  /* Initialize External Interrupt Controller */
  EXTI_DeInit();

  /* Initialize Alternative IO */
  GPIO_AFIODeInit();

  /* NVIC configuration */
  NVIC_Configuration();

  /* Configure PB9 as interrupt source */
  GPIO_BTN_Configuration();

#ifdef	__LCD_H
  /* Clear the LCD area */
  lcdCmd.command = 0x10;
  lcdCmd.par2 = (0x0) | (0x10 << 6) | (0x0 << 11); // Dark Green;
//	lcdCmd.par2 = (7) | (0x7 << 6) | (0x7 << 11);	/* Dark Grey */
  lcdCmd.par1 = 0;
  lcdCmd.paraPtr = NULL;
  xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );

  /* write font set for test purpose */
  lcdCmd.command = 1;
  lcdCmd.par1 = Line1;
  lcdCmd.paraPtr = (portCHAR *)charSet;
  xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );
#endif	/* __LCD_H */

  for( ;; )	{
	/* Wait for an interrupt. */
	while( xSemaphoreTake( xButtonSemaphore, portMAX_DELAY ) != pdPASS );

#ifdef	__LCD_H
	/* Clear the LCD area */
	lcdCmd.command = 0x10;
	lcdCmd.paraPtr = NULL;
	xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );
#endif	/* __LCD_H */

#if (configUSE_TRACE_FACILITY != 0)
	/* Send the column headers to LCD task and display it. */
	lcdCmd.command = 0x1;
	lcdCmd.par1 = Line0;
	lcdCmd.paraPtr = (portCHAR *)pcHeader;
	xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );

	/* Send the column headers to the print task */
#if (DBG_USE_JTAG_PRINT != 0)
	xQueueSend( xPrintQueue, &pcHeader, portMAX_DELAY );
#endif /* DBG_USE_JTAG_PRINT */

	/* Create the list of task states. */
	vTaskList( cListBuffer );

	/* Send the task status information to LCD task and display it. */
	lcdCmd.par1 = Line2;
	lcdCmd.paraPtr = cListBuffer;
	xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );
#endif /* (configUSE_TRACE_FACILITY != 0) */

	/* Send the task status information to the print task for display. */
#if (DBG_USE_JTAG_PRINT != 0)
	xQueueSend( xPrintQueue, &pcList, portMAX_DELAY );
#endif /* DBG_USE_JTAG_PRINT */
	}
}
#endif // (DBG_USE_BUTTON_HANDLER != 0)


/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
	void	RCC_Configuration(void)
/*****************************************************************************/
{
ErrorStatus		HSEStartUpStatus;

  /* RCC system reset(for debug purpose) */
  RCC_DeInit();

  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if(HSEStartUpStatus == SUCCESS)	{
	/* HCLK = SYSCLK */
	RCC_HCLKConfig(RCC_SYSCLK_Div1);

	/* PCLK2 = HCLK */
	RCC_PCLK2Config(RCC_HCLK_Div1);

	/* PCLK1 = HCLK/2 */
	RCC_PCLK1Config(RCC_HCLK_Div2);

	/* Flash 2 wait state */
	FLASH_SetLatency(FLASH_Latency_2);
	/* Enable Prefetch Buffer */
	FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

	/* PLLCLK = 8MHz * 9 = 72 MHz */
	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

	/* Enable PLL */
	RCC_PLLCmd(ENABLE);

	/* Wait till PLL is ready */
	while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{}

	/* Select PLL as system clock source */
	RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

	/* Wait till PLL is used as system clock source */
	while(RCC_GetSYSCLKSource() != 0x08)
		{}
	}

  /* Enable GPIOB, GPIOC and AFIO clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC
                         | RCC_APB2Periph_AFIO | RCC_APB2Periph_ADC1, ENABLE);
}

/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configures the used GPIO pins.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
	void	GPIO_LED_Configuration(void)
/*****************************************************************************/
{
GPIO_InitTypeDef	GPIO_InitStructure;

  /* Configure PC6, PC7, PC8 and PC9 as output push-pull */
  /* PC6 = LED1; PC7 = LED2; PC8 = LED3; PC9 = LED4 */
  GPIO_InitStructure.GPIO_Pin	=  GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8; // | GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
}


/*******************************************************************************
* Function Name  : GPIO_BTN_Configuration
* Description    : Configures PortB-Pin9 as interrupt input.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
	void	GPIO_BTN_Configuration(void)
/*****************************************************************************/
{
GPIO_InitTypeDef	GPIO_InitStructure;
EXTI_InitTypeDef	EXTI_InitStructure;

  /* Configure PB9 as input floating (EXTI Line9) */
  GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed		= GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode		= GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* Configure PB9 as interrupt source */
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource9);
  EXTI_InitStructure.EXTI_Line		= EXTI_Line9;
  EXTI_InitStructure.EXTI_Mode		= EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger	= EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd	= ENABLE;
  EXTI_Init(&EXTI_InitStructure);

}

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configure the nested vectored interrupt controller.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
	void 	NVIC_Configuration(void)
/*****************************************************************************/
{
NVIC_InitTypeDef	NVIC_InitStructure;

#ifdef  VECT_TAB_RAM
  /* Set the Vector Table base location at 0x20000000 */
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
#endif

  /* Configure one bit for preemption priority */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

  /* Enable the EXTI9_5 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel					= EXTI9_5_IRQChannel;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* Enable the ADC Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel					= ADC1_2_IRQChannel;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}


#ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert error line source number
* Output         : None
* Return         : None
*******************************************************************************/
	void	assert_failed(u8* file, u32 line)
/*****************************************************************************/
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif



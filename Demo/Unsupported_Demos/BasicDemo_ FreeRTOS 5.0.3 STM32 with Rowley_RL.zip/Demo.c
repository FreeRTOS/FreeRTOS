/*****************************************************************
** Module  : Demo.c                                             **
**                                                              **
** Version : 1.0.0 - Version initiale                           **
**                                                              **
**                                                              **
** Copyright � 2008 par Cit� Logique Drummond Inc.              **
*****************************************************************/

#include "FreeRTOS.h"
#include "task.h"

#include "stm32f10x_lib.h"

#define APP_TASK_PRIORITY			(tskIDLE_PRIORITY + 1)
#define APP_STACK_SIZE				(configMINIMAL_STACK_SIZE+64)

typedef struct
{
	u16	GPIO_Pin;
	u32	time;
}AppStruct;

const AppStruct AppParams0 = { GPIO_Pin_0, 500 };
const AppStruct AppParams1 = { GPIO_Pin_4, 250 };

void InitBsp (void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Set NVIC to reset values */
	NVIC_DeInit ();

	/* Set the Vector Table base address at 0x08000000 */
	NVIC_SetVectorTable (NVIC_VectTab_FLASH, 0x0);

	NVIC_PriorityGroupConfig (NVIC_PriorityGroup_4);

	/* Set RCC to reset values */
	RCC_DeInit ();

	/* Enable GPIOC clock */
	RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOC, ENABLE);

	/* Set GPIOC to reset values */
	GPIO_DeInit (GPIOC);

	/* Configure GPIOC */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_4 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init (GPIOC, &GPIO_InitStructure);

	GPIO_ResetBits (GPIOC, GPIO_Pin_10);
}

void vAppTask (void * p)
{
	for (;;)
	{
		GPIO_SetBits (GPIOC, ((const AppStruct *) p)->GPIO_Pin);
		vTaskDelay (((const AppStruct *) p)->time);
		GPIO_ResetBits (GPIOC, ((const AppStruct *) p)->GPIO_Pin);
		vTaskDelay (((const AppStruct *) p)->time);
	}
}

int main (void)
{
	InitBsp ();
	xTaskCreate (vAppTask, (s8 *) "App0", APP_STACK_SIZE, (void *) &AppParams0, APP_TASK_PRIORITY, NULL);
	xTaskCreate (vAppTask, (s8 *) "App1", APP_STACK_SIZE, (void *) &AppParams1, APP_TASK_PRIORITY, NULL);
	/* Start the scheduler running the tasks and co-routines just created. */
	vTaskStartScheduler ();

	/* Should not get here unless we did not have enough memory to start the
	scheduler. */
	while (1);
	return 0;
}

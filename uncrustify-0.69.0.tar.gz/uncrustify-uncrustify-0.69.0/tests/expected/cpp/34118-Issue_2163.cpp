/*
 * m
 */
void
m(){
	return 0;
}

/*
 * n
 */
void
n(){
	return 0;
}

/*
 * n
 */
int&
n( int& x ){
	return x;
}

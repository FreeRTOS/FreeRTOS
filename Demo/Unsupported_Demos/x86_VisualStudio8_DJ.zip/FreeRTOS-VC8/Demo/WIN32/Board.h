#ifndef BOARD_H
#define BOARD_H

typedef char	w32char_t;

#define USE_STDIO
#endif

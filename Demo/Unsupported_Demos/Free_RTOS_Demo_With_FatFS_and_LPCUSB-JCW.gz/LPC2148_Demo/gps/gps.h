#ifndef _GPS_H_
#define _GPS_H_

#include "semphr.h"

//
//
//
typedef struct gpsData_s
{
  unsigned char valid;
  double latitude;
  double longitude;
  double height;
  float groundSpeed;
  float trueCourse;
  unsigned char utcDay;
  unsigned char utcMonth;
  unsigned short utcYear;
  unsigned char utcHours;
  unsigned char utcMinutes;
  unsigned char utcSeconds;
  int restarts;
}
gpsData_t;

//
//
//
int gpsCopyData (gpsData_t *dst);
portTASK_FUNCTION_PROTO (vGPSTask, pvParameters __attribute__ ((unused)));

#endif

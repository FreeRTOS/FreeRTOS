class AlignFuncProtoTest {
public:
void  test1();
void  test2();
SomeLongType findSomeLongType();
void* test3();
void test4(){
	a=1;
}
double test5();
void   test6();
SomeLongNamespace::OtherLongNamespace::SomeLongType findSomeLongType();
void   test7();
void   test8();
void   test9();
SomeLongNamespace::SomeLongType long_var;
}

/******************************************************************************
 *
 * Example Program       for R32C/111     FreeRTOS
 *
 * author                f.daners@swissworld.com
 *                       Felix Daners Engineering
 *                       Speerstrasse 32
 *                       8200 Schaffhausen
 *                       Switzerland
 *
 *****************************************************************************
 *
 * !!! THIS FILE IS LICENSED SEPARATELY FROM FREERTOS !!!
 *
 * Copyright (c) 2009, Felix Daners Engineering, Switzerland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * - Neither the name of the Felix Daners Engineering nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/
/*! \file *********************************************************************
 *
 * \brief FreeRTOS port  for IAR R32C111
 *
 * \author               f.daners@swissworld.com
 *
 * Assume count source clock is 24MHz
 *****************************************************************************/

#include "FreeRTOS.h"
#include "task.h"
/* IO definitions for the chosen device. */
#include <ior32c111.h>
#include <intrinsics.h>


/*
 * Setup the stack of a new task so it is ready to be placed under the
 * scheduler control.  The registers have to be placed on the stack in
 * the order that the port expects to find them.
 */
portSTACK_TYPE *pxPortInitialiseStack( portSTACK_TYPE *pxTopOfStack, pdTASK_CODE pxCode, pdTASK_PARAM pvParameters )
{
  /* select user stack, enable interrupt, set interrupt level to kernel */
  portSTACK_TYPE flag = 0x0040 | 0x0080 | (configKERNEL_INTERRUPT_PRIORITY<<12);

  pxTopOfStack--;

  /* | FLG          | */
  *pxTopOfStack-- = flag;

  /* | PC           | */
  *pxTopOfStack-- = (portSTACK_TYPE)((unsigned portLONG)pxCode );

  /* | FB                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0xFBFBFBFB;

  /* | SB                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0x3B3B3B3B;

  /* | A3                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0xA3A3A3A3;

  /* | A2                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0xA2A2A2A2;

  /* | A1                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0xA1A1A1A1;

  /* | A0                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)((unsigned portLONG)pvParameters);

  /* | R7R5                              | */
  *pxTopOfStack-- = (portSTACK_TYPE)0x77775555;

  /* | R6R4                              | */
  *pxTopOfStack-- = (portSTACK_TYPE)0x66664444;

  /* | R3R1                              | */
  *pxTopOfStack-- = (portSTACK_TYPE)0x33331111;

  /* | R2R0                              | */
  *pxTopOfStack   = (portSTACK_TYPE)0x22220000;

   return pxTopOfStack;
}


extern void portStartScheduler_asm(void);
extern void portEndScheduler_asm(void);


/** set ms timer function */
/* This routine setups timer 1 and clears timer flag */
static void rtos_tick_timer_uninstall(void)
{
  tb0s = 0x00;      // stop timer B0 (count flag)
  tb0ic = 0;        // shut of interrupts from this timer
}

/** set ms timer function, assume count source clock is 24MHz */
/* This routine setups timer B0 and clears timer flag */
static void rtos_tick_timer_install(void)
{
  /* this function is called before interrupts are enabled */

  tb0mr = 0x40;     // XXXX XXXX
                    // |||| ||++- operation mode: 00: timer 01: event counter 10:one shot timer 11: PWM
                    // |||| |+--- pulse output at pin TA4out 0: OFF 1: ON
                    // |||| +---- gate function: 0: timer counts only when TA0in is "L", 1: .. is "H"
                    // |||+------ gate function  0: not available 1: available
                    // ||+------- must always be 0 in timer mode
                    // ++-------- count source select bits: 00:f1  01:f8  10:f32 11:fc32

  tb0 = (24000000ul/8u * 1 /*ms*/ /1000u )-1u;     // 1ms resolution @ 24MHz f8
  tb0s = 0x01;      // start timer B0 (count flag)
  tb0ic = configMAX_SYSCALL_INTERRUPT_PRIORITY;// interrupt priority level select bit 0...7
}



/*
 * Setup the hardware ready for the scheduler to take control.  This generally
 * sets up a tick interrupt and sets timers for the correct tick frequency.
 */
portBASE_TYPE xPortStartScheduler( void )
{
  rtos_tick_timer_install();

  /* this enables interrupts because the initialized stack frame contains
     the flag register status */
  portStartScheduler_asm();

  return pdFALSE;
}

/*
 * Undo any hardware/ISR setup that was performed by xPortStartScheduler() so
 * the hardware is left in its original condition after the scheduler stops
 * executing.
 */
void vPortEndScheduler( void )
{
  rtos_tick_timer_uninstall();
  portEndScheduler_asm();
}



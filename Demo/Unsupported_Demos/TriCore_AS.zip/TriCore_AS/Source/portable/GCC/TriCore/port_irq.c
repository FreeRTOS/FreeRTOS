/*
	FreeRTOS.org V4.7.0 - Copyright (C) 2003-2007 Richard Barry.
	TriCore port - written by Adriaan Schmidt, Copyright (C) 2008 Siemens AG.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	The TriCore port is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license
	and contact details.  Please ensure to read the configuration and relevant
	port sections of the online documentation.

	Also see http://www.SafeRTOS.com a version that has been certified for use
	in safety critical systems, plus commercial licensing, development and
	support options.
	***************************************************************************
*/

#include "port_irq.h"

/* TriCore includes */
#include <tc1796b/csfr.h>
#include <machine/wdtcon.h>
#include <machine/intrinsics.h>

/* Setup defines */
#define DATA_SCRATCHPAD_BASE 0xd0000000
#define CODE_SCRATCHPAD_BASE 0xd4000000

#define VEC_TABLE_BASE CODE_SCRATCHPAD_BASE
#define VEC_TABLE_LEN 256

/*
 * This is the code which is copied into the
 * vector table. irqjmp_code[] contains the
 * binary version of it.
 *
void irqjmp()
{
	__asm__( "bisr 0" );
	__asm__( "movh.a %a12, ( ( 0x00000000 + 0x8000 ) >> 16 ) & 0xffff" );
	__asm__( "lea %a12, [%a12]( 0x00000000 & 0xffff )" );
	__asm__( "ji %a12" );
}
*/

static unsigned long irqjmp_code[] = {
    0x009100e0,
    0xccd9c000,
    0x00009578,
    0x00000cdc
};

void vIrqInit()
{
	unsigned portBASE_TYPE uxCnt;

	/* setup (clear) the vector table */
	for ( uxCnt = 0; uxCnt < 8 * VEC_TABLE_LEN; uxCnt++ ) {
		if (uxCnt % 8 == 0) {
			( (unsigned long *) VEC_TABLE_BASE )[ uxCnt ] = 0x0000a000;
		} else {
			( (unsigned long *) VEC_TABLE_BASE )[ uxCnt ] = 0;
		}
	}

	/* now activate the interrupt system */
	unlock_wdtcon();
	_mtcr( $biv, VEC_TABLE_BASE );
	_enable();
	_isync();
	lock_wdtcon();
}

void vIrqSetVector( unsigned portCHAR ucNumber, void (*pxFunc)(),
        unsigned portCHAR ucRunPrio )
{
	unsigned portBASE_TYPE uxCnt;
	unsigned portLONG ulFunc = (unsigned portLONG) pxFunc;
	unsigned portLONG *ulpTargetVector =
            (unsigned portLONG *)( VEC_TABLE_BASE + ucNumber * 32 );

	/* remove old target address */
	irqjmp_code[0] &= 0x0fff00ff;
	irqjmp_code[1] &= 0xfffff000;
	irqjmp_code[2] &= 0xffff0000;

	/* insert target address */
	irqjmp_code[0] |= ( ( ucRunPrio & 0xff ) << 8 )
            | ( ( ( ulFunc+0x8000 ) & 0x000f0000 ) << 12 );
	irqjmp_code[1] |= ( ( ( ulFunc+0x8000 ) & 0xfff00000 ) >> 20 );
	irqjmp_code[2] |= ( ulFunc & 0x003f ) | ( ( ulFunc & 0xfc00 ) >> 4 )
            | ( ( ulFunc & 0x03c0 ) << 6 );

	/* copy code into vector table */
	for ( uxCnt = 0; uxCnt < 4; uxCnt++ ) {
		ulpTargetVector[ uxCnt ] = irqjmp_code[ uxCnt ];
	}
}

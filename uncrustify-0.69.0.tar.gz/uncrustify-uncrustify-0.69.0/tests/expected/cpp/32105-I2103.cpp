int i1 = EEnumType::a & EEnumType::b;
int i2 = a & b;

#ifndef _FIQ_H_
#define _FIQ_H_

void fiqInit (void);
int fiqEnable (void);
int fiqDisable (void);
unsigned int fiqGetCount (void);
void fiqClearCount (void);
void fiqISR (void);

#endif

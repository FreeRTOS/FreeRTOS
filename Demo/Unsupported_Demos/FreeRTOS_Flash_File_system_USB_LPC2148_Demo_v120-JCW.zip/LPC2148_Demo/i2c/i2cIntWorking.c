#include "FreeRTOS.h"

#include <stdio.h>
#include <string.h>
#include <sys/times.h>

#include "i2c.h"

//
//  Default timeout, in milliseconds for generic read/write
//
#define I2C_DEFAULT_TIMEOUT 100

//
//
//
static volatile int i2cBusInUse;
static U8 i2cAddress;
static U8 *i2cDataBuffer;
static int i2cDataLenWrite;
static int i2cDataLenRead;
static int i2cTimeout = I2C_DEFAULT_TIMEOUT;
static U8 *i2cDataPtr;
static U8 i2cTransactions [64];
static int i2cTransactionsIndex;

//
//
//
#define i2cDebug(x) do { if (i2cTransactionsIndex < (int) sizeof (i2cTransactions)) i2cTransactions [i2cTransactionsIndex++] = x; } while (0)

static void i2cISR (void) __attribute__ ((interrupt ("IRQ")));
static void i2cISR (void)
{
  i2cErrno = (I2C0_STAT & I2C_STAT_STATMASK);
  i2cDebug (i2cErrno);

  switch (i2cErrno)
  {
    //
    //  Transmit conditions
    //
    case I2CERR_BUSERRORx : // 0x00
      {
        I2C0_CONSET = I2C_CONSET_STO | I2C_CONSET_AA;
        i2cBusInUse = FALSE;
      }
      break;

    case I2CERR_STARTTX : // 0x08
      {
        i2cDebug (i2cAddress);
        I2C0_DAT = i2cAddress;
      }
      break;

    case I2CERR_REPEATEDSTARTTX : // 0x10
      {
        i2cDebug (i2cAddress);
        I2C0_DAT = i2cAddress;
      }
      break;

    case I2CERR_SLAWTX_ACKRX : // 0x18
      {
        i2cDebug (*i2cDataPtr);
        I2C0_DAT = *i2cDataPtr++;
        I2C0_CONCLR = I2C_CONCLR_STAC;
      }
      break;

    case I2CERR_SLAWTX_NACKRX : // 0x20
      {
        I2C0_CONSET = I2C_CONSET_STO;
        i2cBusInUse = FALSE;
      }
      break;

    case I2CERR_DATTX_ACKRX : // 0x28
      {
        if (--i2cDataLenWrite)
        {
          i2cDebug (*i2cDataPtr);
          I2C0_DAT = *i2cDataPtr++;
          I2C0_CONCLR = I2C_CONCLR_STAC;
        }
        else
        {
          if (!i2cDataLenRead)
          {
            i2cDebug (0xff);
            I2C0_CONCLR = I2C_CONCLR_STAC;
            I2C0_CONSET = I2C_CONSET_STO;
            i2cBusInUse = FALSE;
          }
          else
          {
            i2cDebug (0xfe);
            i2cAddress |= 0x01;
            i2cDataPtr = i2cDataBuffer;
            I2C0_CONSET = I2C_CONSET_STA;
          }
        }
      }
      break;

    case I2CERR_DATTX_NACKRX : // 0x30
      {
        I2C0_CONCLR = I2C_CONCLR_STAC;
        I2C0_CONSET = I2C_CONSET_STO;
        i2cBusInUse = FALSE;
      }
      break;

    case I2CERR_ARBLOST : // 0x38
      {
        I2C0_CONSET = I2C_CONSET_STA;
      }
      break;

    //
    //  Receive byte conditions
    //
    case I2CERR_SLARTX_ACKRX : // 0x40
      {
        I2C0_CONCLR = I2C_CONCLR_STAC;
        I2C0_CONSET = I2C_CONSET_AA;
      }
      break;

    case I2CERR_SLARTX_NACKRX : // 0x48
      {
        I2C0_CONCLR = I2C_CONCLR_STAC;
        I2C0_CONSET = I2C_CONSET_STO;
        i2cBusInUse = FALSE;
      }
      break;

    case I2CERR_DATRX_ACKTX : // 0x50
      {
        *i2cDataPtr++ = I2C0_DAT;
        i2cDebug (*(i2cDataPtr - 1));

        if (--i2cDataLenRead)
        {
          I2C0_CONCLR = I2C_CONCLR_STAC;
          I2C0_CONSET = I2C_CONSET_AA;
        }
        else
        {
          I2C0_CONCLR = I2C_CONCLR_STAC | I2C_CONCLR_AAC;
          i2cBusInUse = FALSE;
        }
      }
      break;

    case I2CERR_DATRX_NACKTX : // 0x58
      {
        // *i2cDataPtr = I2C0_DAT;
        // i2cDebug (*i2cDataPtr);
        I2C0_CONCLR = I2C_CONCLR_STAC;
        I2C0_CONSET = I2C_CONSET_STO;
        i2cBusInUse = FALSE;
      }
      break;

    case I2CERR_NOINFO :
      break;

    default:
      {
        I2C0_CONCLR = I2C_CONCLR_I2ENC;
        i2cBusInUse = FALSE;
      }
      break;
  }

  I2C0_CONCLR = I2C_CONSET_SI;
  VIC_VectAddr = 0;
}

//
// i2c1Init
//
void i2cInit (void)
{
  i2cBusInUse = FALSE;

  SCB_PCONP |= SCB_PCONP_PCI2C0;

  PCB_PINSEL0 = (PCB_PINSEL0 & ~(PCB_PINSEL0_P02_MASK | PCB_PINSEL0_P03_MASK)) | (PCB_PINSEL0_P02_SCL0 | PCB_PINSEL0_P03_SDA0);

  I2C0_CONCLR = I2C_CONCLR_MASK;
  I2C0_CONSET = I2C_CONSET_I2EN;
  I2C0_SCLL   = 240;
  I2C0_SCLH   = 240;

  //
  //  Initialize the interrupt vector
  //
  VIC_IntSelect &= ~VIC_IntSelect_I2C0;
  VIC_VectCntl7 = VIC_VectCntl_ENABLE | VIC_Channel_I2C0;
  VIC_VectAddr7 = (int) i2cISR;
  VIC_IntEnable = VIC_IntEnable_I2C0;
}

//
//
//
static int i2cTransferBytes (U8 address, U8 *buffer, int bufferLenWrite, int bufferLenRead)
{
  //
  //  Determine if our first operation will be a write or read.  If both, the
  //  write always occurs first.
  //
  if (bufferLenWrite)
    address &= ~0x01;
  else if (bufferLenRead)
    address |= 0x01;
  else
  {
    i2cErrno = I2CERR_OTHER;
    return -1;
  }

  //
  //  Wait until last I2C operation has finished.  
  //
  if (i2cBusInUse && i2cWaitComplete (i2cTimeout))
  {
    i2cErrno = I2CERR_TIMEOUT;
    return -1;
  }

  //
  //  Mark bus as in use, save the address, buffer and length
  //
  i2cBusInUse = TRUE;
  i2cAddress = address;
  i2cDataBuffer = buffer;
  i2cDataLenWrite = bufferLenWrite;
  i2cDataLenRead = bufferLenRead;
  i2cDataPtr = buffer;

  i2cTransactionsIndex = 0; // ###

  I2C0_CONCLR = I2C_CONCLR_MASK;
  I2C0_CONSET = I2C_CONSET_I2EN;
  I2C0_CONSET = I2C_CONSET_STA;

  return 0;
}

//
//
//
int i2cWaitComplete (int milliseconds)
{
  if (i2cBusInUse)
  {
    clock_t theFuture;

    if (milliseconds < 10)
      milliseconds = 10;

    for (theFuture = times (NULL) + (milliseconds / 10); i2cBusInUse; )
    {
      if (times (NULL) > theFuture)
      {
        I2C0_CONCLR = I2C_CONCLR_I2ENC;
        i2cErrno = I2CERR_TIMEOUTWC;
        return -1;
      }
    }
  }

  return 0;
}

//
//
//
static int i2cWriteBufferEx (U8 address, U8 *buffer, U32 bufferLength, int milliseconds)
{
  if (i2cTransferBytes (address, buffer, bufferLength, 0))
    return -1;

  return i2cWaitComplete (milliseconds);
}

static int i2cReadBufferEx (U8 address, U8 *buffer, U32 bufferLength, int milliseconds)
{
  if (i2cTransferBytes (address, buffer, 0, bufferLength))
    return -1;

  return i2cWaitComplete (milliseconds);
}

static int i2cWriteReadBufferEx (U8 address, U8 *buffer, U32 putLength, U32 getLength, int milliseconds)
{
  if (i2cTransferBytes (address, buffer, putLength, getLength))
    return -1;

  return i2cWaitComplete (milliseconds);
}

//
//  DANGER, WILL ROBINSON!  The callers buffer must persist until we're done
//
int i2cWriteBuffer (U8 address, U8 *buffer, U32 bufferLength)
{
  return i2cWriteBufferEx (address, buffer, bufferLength, i2cTimeout);
}

int i2cReadBuffer (U8 address, U8 *buffer, U32 bufferLength)
{
  return i2cReadBufferEx (address, buffer, bufferLength, i2cTimeout);
}

int i2cWriteReadBuffer (U8 address, U8 *buffer, U32 putLength, U32 getLength)
{
  return i2cWriteReadBufferEx (address, buffer, putLength, getLength, i2cTimeout);
}

void i2cSetTimeout (int timeoutInMilliseconds)
{
  if (timeoutInMilliseconds < 10)
    timeoutInMilliseconds = 10;

  i2cTimeout = timeoutInMilliseconds;
}

void i2cDump (void)
{
  int i;

  for (i = 0; i < i2cTransactionsIndex; i++)
    printf ("0x%02x ", i2cTransactions [i]);

  printf ("\n");
}


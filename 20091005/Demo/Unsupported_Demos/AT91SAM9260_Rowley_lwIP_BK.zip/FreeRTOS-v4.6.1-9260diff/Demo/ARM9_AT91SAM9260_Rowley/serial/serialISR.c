/*
FreeRTOS.org V4.1.2 - Copyright (C) 2003-2006 Richard Barry.

This file is part of the FreeRTOS.org distribution.

FreeRTOS.org is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FreeRTOS.org is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FreeRTOS.org; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

A special exception to the GPL can be applied should you wish to distribute
a combined work that includes FreeRTOS.org, without being obliged to provide
the source code for any proprietary components.  See the licensing section 
of http://www.FreeRTOS.org for full details of how and when the exception
can be applied.

***************************************************************************
See http://www.FreeRTOS.org for documentation, latest information, license 
and contact details.  Please ensure to read the configuration and relevant 
port sections of the online documentation.
***************************************************************************
*/


/* 
BASIC INTERRUPT DRIVEN SERIAL PORT DRIVER FOR UART0. 

This file contains all the serial port components that must be compiled
to ARM mode.  The components that can be compiled to either ARM or THUMB
mode are contained in serial.c.

*/

/* Standard includes. */
#include <stdlib.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

/* Demo application includes. */
#include "serial.h"
#include "serialISR.h"

#ifdef USART0
void vUSART0_ISR( void )
{
  /* Save the context of the interrupted task. */
  portSAVE_CONTEXT();

  /* Call the handler.  This must be a separate function to ensure the 
  stack frame is correctly set up. */
  USART_ISR(&xPortStatus[USART0]);

  /* Restore the context of whichever task will run next. */
  portRESTORE_CONTEXT();
}
#endif
#ifdef USART1
void vUSART1_ISR( void )
{
  /* Save the context of the interrupted task. */
  portSAVE_CONTEXT();

  /* Call the handler.  This must be a separate function to ensure the
  stack frame is correctly set up. */
  USART_ISR(&xPortStatus[USART1]);

  /* Restore the context of whichever task will run next. */
  portRESTORE_CONTEXT();
}
#endif
#ifdef USART2
void vUSART2_ISR( void )
{
  /* Save the context of the interrupted task. */
  portSAVE_CONTEXT();

  /* Call the handler.  This must be a separate function to ensure the 
  stack frame is correctly set up. */
  USART_ISR(&xPortStatus[USART2]);

  /* Restore the context of whichever task will run next. */
  portRESTORE_CONTEXT();
}
#endif
#ifdef USART3
void vUSART3_ISR( void )
{
  /* Save the context of the interrupted task. */
  portSAVE_CONTEXT();

  /* Call the handler.  This must be a separate function to ensure the 
  stack frame is correctly set up. */
  USART_ISR(&xPortStatus[USART3]);

  /* Restore the context of whichever task will run next. */
  portRESTORE_CONTEXT();
}
#endif
#ifdef USART4
void vUSART4_ISR( void )
{
  /* Save the context of the interrupted task. */
  portSAVE_CONTEXT();

  /* Call the handler.  This must be a separate function to ensure the 
  stack frame is correctly set up. */
  USART_ISR(&xPortStatus[USART4]);

  /* Restore the context of whichever task will run next. */
  portRESTORE_CONTEXT();
}
#endif
#ifdef USART5
void vUSART5_ISR( void )
{
  /* Save the context of the interrupted task. */
  portSAVE_CONTEXT();

  /* Call the handler.  This must be a separate function to ensure the 
  stack frame is correctly set up. */
  USART_ISR(&xPortStatus[USART5]);

  /* Restore the context of whichever task will run next. */
  portRESTORE_CONTEXT();
}
#endif

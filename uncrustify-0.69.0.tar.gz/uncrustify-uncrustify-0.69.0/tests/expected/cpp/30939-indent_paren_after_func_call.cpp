SomeClass::SomeClass()
{
	SomeFunction
	        (
	        aTest,
	        aResult
	        );
}
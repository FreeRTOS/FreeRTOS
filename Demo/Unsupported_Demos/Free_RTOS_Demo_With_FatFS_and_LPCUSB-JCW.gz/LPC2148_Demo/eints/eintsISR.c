//
//
//
#include "FreeRTOS.h"
#include "task.h"

#include "eintsISR.h"

//
//
//
void eintsISR_EINT0 (void) __attribute__ ((naked));
void eintsISR_EINT2 (void) __attribute__ ((naked));

//
//
//
void eintsISR_EINT0 (void)
{
	portENTER_SWITCHING_ISR ();

  SCB_EXTINT |= SCB_EXTINT_EINT0;

  GPIO0_IOSET = GPIO_IO_P11;

	VIC_VectAddr = (unsigned portLONG) 0;

	portEXIT_SWITCHING_ISR (0);
}

void eintsISR_EINT2 (void)
{
	portENTER_SWITCHING_ISR ();

  SCB_EXTINT |= SCB_EXTINT_EINT1;

  GPIO0_IOCLR = GPIO_IO_P11;

	VIC_VectAddr = (unsigned portLONG) 0;

	portEXIT_SWITCHING_ISR (0);
}

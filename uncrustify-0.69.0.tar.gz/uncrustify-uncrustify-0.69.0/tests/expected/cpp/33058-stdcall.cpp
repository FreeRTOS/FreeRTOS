// test for bug # 633
typedef void (*func)();
typedef void (__stdcall *func)();

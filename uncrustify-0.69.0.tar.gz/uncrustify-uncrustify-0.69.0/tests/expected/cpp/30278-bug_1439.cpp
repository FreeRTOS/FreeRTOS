struct A;
struct B;

#include <stdio.h>
#include <errno.h>

#include "tinysh.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

//extern void *tinysh_get_arg(void);

static void display_args(int argc, char **argv)
{
  int i;
  for(i=0;i<argc;i++)
    {
      printf("argv[%d]=\"%s\"\n",i,argv[i]);
    }
}

static void foo_fnt(int argc, char **argv)
{
  printf("foo command called\n");
  display_args(argc,argv);
}

static tinysh_cmd_t myfoocmd={0,"foo","foo command","[args]",
                              foo_fnt,0,0,0};

static void item_fnt(int argc, char **argv)
{
  printf("item%d command called\n",(int)tinysh_get_arg());
  display_args(argc,argv);
}

static tinysh_cmd_t ctxcmd={0,"ctx","contextual command","item1|item2",
                            0,0,0,0};
static tinysh_cmd_t item1={&ctxcmd,"item1","first item","[args]",item_fnt,
                           (void *)1,0,0};
static tinysh_cmd_t item2={&ctxcmd,"item2","second item","[args]",item_fnt,
                           (void *)2,0,0};

static void reset_to_0(int argc, char **argv)
{    
  int *val;
  val=(int *)tinysh_get_arg();
  *val=0;
}

static void atoxi_fnt(int argc, char **argv)
{
  int i;

  for(i=1;i<argc;i++)
    {
      printf("\"%s\"-->%u (0x%x)\n",
             argv[i],tinysh_atoxi(argv[i]),tinysh_atoxi(argv[i]));
    }
}

static tinysh_cmd_t atoxi_cmd={0,"atoxi","demonstrate atoxi support",
                               "[args-to-convert]",atoxi_fnt,0,0,0};
                               
xSemaphoreHandle bg_sem;

static void bg_cmd_fnt(int argc, char **argv)
{
  printf("bg_cmd command called\n");
  xSemaphoreGive( bg_sem );
}

static tinysh_cmd_t bgcmd={0,"bg_cmd","bg_cmd command","[args]",
                              bg_cmd_fnt,0,0,0};

portTASK_FUNCTION( bg_cmd_thread, pvParameters )
{
    vSemaphoreCreateBinary( bg_sem );
    xSemaphoreTake( bg_sem, 0 );
	for(;;) {	    
	    while( xSemaphoreTake( bg_sem, 10000 ) != pdPASS ); 
	    vTaskDelay( 5 );
		printf("**** this is a back ground task *****\n");
	}
}

//int shell(int argc, char **argv)
portTASK_FUNCTION(shell, pvParameters )
{
  int c;
  int again=1;
  xTaskHandle xHandle;

/* change the prompt */
  tinysh_set_prompt("$ ");

/* add the foo command 
*/
  tinysh_add_command(&myfoocmd);

/* add sub commands
 */
  tinysh_add_command(&ctxcmd);
  tinysh_add_command(&item1);
  tinysh_add_command(&item2);

/* use a command from the stack
 * !!! this is only possible because the shell will have exited
 * before the stack of function main !!!
 */
  {
    tinysh_cmd_t quitcmd={0,"quit","exit shell",0,reset_to_0,
                          (void *)&again,0,0};
    tinysh_add_command(&quitcmd);    
  }

/* add atoxi support test command */
  tinysh_add_command(&atoxi_cmd);
  
  
  
/* add a background command */
  tinysh_add_command(&bgcmd);
  xTaskCreate( bg_cmd_thread, "bg_cmd thread", 1000, NULL, 2, &xHandle);
  
/* main loop
 */
  while(again)
    {
      c=getchar();
      tinysh_char_in((unsigned char)c);
    }
  printf("\nBye\n");
  return;
}

namespace
{
void f(){
};
} // namespace
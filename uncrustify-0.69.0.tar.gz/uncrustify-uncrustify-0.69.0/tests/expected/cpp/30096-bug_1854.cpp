while (*p++ = ' ') ;

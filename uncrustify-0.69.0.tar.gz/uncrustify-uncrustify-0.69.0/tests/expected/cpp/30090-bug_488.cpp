void baz()
{
        foobar= bar[a + b + (c
            + d)];

        foobar = bar(a + b + (c +
            +d));

        foo = bar[a] + b + qux(c +
            +d);
}


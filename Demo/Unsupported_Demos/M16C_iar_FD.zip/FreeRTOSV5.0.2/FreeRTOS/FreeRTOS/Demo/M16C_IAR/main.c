/*! \file *********************************************************************
 *
 * \brief FreeRTOS port header for IAR M16C
 *
 * \author  (c) Copyright 2008, Felix Daners Engineering. f.daners@swissworld.com
 *
 * FreeRTOS.org is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FreeRTOS.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FreeRTOS.org; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * A special exception to the GPL can be applied should you wish to distribute
 * a combined work that includes FreeRTOS.org, without being obliged to provide
 * the source code for any proprietary components.  See the licensing section
 * of http://www.FreeRTOS.org for full details of how and when the exception
 * can be applied.
 */

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include <iom16c62p.h>

//-----------------------------------------------------------------------------
// Function   : InitializeProcessor()
// Description: initializes the processor and its peripherals
// Parameter:   none
// Return:      none
//-----------------------------------------------------------------------------
static void initialize_processor(void)
{
  //#define PUR01   (*(WORD * ) 0x3FC)  // Pull-up register 0 & 1 because of emulator restriction

  //Setting Processor mode register 0
  prc1 = 1;
  PM0 = 0x01;   // XXXX XXXX
                // |||| ||++- Processor mode bit
                // |||| ||    00: Single-chip mode
                // |||| ||    01: Memory expansion mode
                // |||| ||    10: Inhibited
                // |||| ||    11: Microprocessor mode
                // |||| |+--- R/W mode select bit   0: /RD, /BHE, /WR     1: /RD, /WRH, /WRL
                // |||| +---- Software reset bit  The device is reset when this bit is set to '1'. (fclk/8)
                // ||++------ Multiplexed bus space select bits
                // ||         00: Multiplexed bus is not used
                // ||         01: Allocated to CS2 space
                // ||         10: Allocated to CS1 space
                // ||         11: Allocated to entire space
                // |+-------- Port P40 to P43 function select bit
                // |          0: Address output
                // |          1: Port function (Address is no output)
                // +----------BCLK output disable bit 0: BCLK is output  1: BCLK is not output
    //Setting Processor mode register 1
    prc1 = 1;
    PM1 = 0x00; // X0XX XXX0
                // |||| |||+- Must always be set to '0'
                // |||| |++-- nothing assigned
                // |||| +---- internal reserved area expansion bit
                // ||||       0: the same as 16C60  16C61 group
                // ||||       1: expands the internal RAM and ROM area to 23k and 256k (16C624)
                // ||++------ memory area expansion bit 00: normal mode
                // |+-------- always set to zero
                // +--------- Wait bit    0: No wait state      1: Wait state inserted
    // chip select control register
    CSR = 0x00; // XXXX XXXX
                // |||| ++++- chip select 0..3 output.  0:disabled  1:enabled
                // ++++------ chip select 0..3 wait.    0: wait     1: no wait state

    prc0 = 1; // enable writing to system clock register
    //Setting System clock control register 0
    CM0 = 0x00; // XXXX XXXX
                // |||| ||++- Clock output function select bit
                // |||| ||    00: I/O port P57  01: fc output   10: f8 output  11: f32 output
                // |||| |+--- WAIT peripheral function clock stop bit
                // |||| |     0: Do not stop f1, f8, f32 in  wait mode  1: Stop f1, f8, f32 in wait mode
                // |||| +---- Xcin-Xcout drive capacity select bit 0: LOW    1: HIGH
                // |||+------ Port Xc select bit              0: I/O port 1: Xcin-Xcout generation
                // ||+------- Main clock (Xin-Xout) stop bit  0: On       1: Off
                // |+-------- Main clock division select bit 0  0: CM16 and cM17 valid 1: Division by 8 mode
                // +--------- System clock select bit         0: Xin-Xout 1: Xcin-Xcout
    // Setting System clock control register 1
    prc0 = 0x01;// enable writing to system clock register
    CM1 = 0x20; // XXX0 000X
                // |||| |||+- All clock stop control bit  0: Clock on   1: All Clock off (stop mode)
                // |||+ +++-- Always set to '0'
                // ||+------- Xin-Xout drive capacity select bit  0: LOW  1: HIGH
                // ++-------- Main clock division mode  00: No division 01: Div by 2  10: Div by 4  11: Div by 16
    prc0 = 0; // disable writing to system clock register

    PUR01 = 0x0000; //0xC00C; // P1-P3, P6.0-P6.3, P7.4-P7.7 pulled up
                  // PUR 0 (1)
                  // XXXX XXXX
                  // |||| |||+- P0.0 to P0.3 pull-up    0: Not pulled high 1: pulled high (2)
                  // |||| ||+-- P0.4 to P0.7 pull-up
                  // |||| |+--- P1.0 to P1.3 pull-up
                  // |||| +---- P1.4 to P1.7 pull-up
                  // |||+------ P2.0 to P2.3 pull-up
                  // ||+------- P2.4 to P2.7 pull-up
                  // |+-------- P3.0 to P3.3 pull-up
                  // +--------- P3.4 to P3.7 pull-up
                  // PUR 1
                  // XXXX XXXX
                  // |||| |||+- P4.0 to P4.3 pull-up    0: Not pulled high 1: pulled high (5)
                  // |||| ||+-- P4.4 to P4.7 pull-up
                  // |||| |+--- P5.0 to P5.3 pull-up
                  // |||| +---- P5.4 to P5.7 pull-up
                  // |||+------ P6.0 to P6.3 pull-up
                  // ||+------- P6.4 to P6.7 pull-up
                  // |+-------- P7.0 to P7.3 pull-up
                  // +--------- P7.4 to P7.7 pull-up

                  /*
                    NOTES:
                    1. During memory extension and microprocessor modes, the pins are not pulled high although their
                    corresponding register contents can be modified.
                    2. The pin for which this bit is �1� (pulled high) and the direction bit is �0� (input mode) is pulled high.
                    3. The P7_0 and P7_1 pins do not have pull-ups.
                    4. During memory extension and microprocessor modes, the pins are not pulled high although the contents
                    of these bits can be modified.
                    5. The pin for which this bit is �1� (pulled high) and the direction bit is �0� (input mode) is pulled high.
                    6. If the PM01 to PM00 bits in the PM0 register are set to �01b� (memory expansion mode) or �11b�
                    (microprocessor mode) in a program during single-chip mode, the PU11 bit becomes �1�.
                    7. The values after hardware reset 1 and voltage down detection reset (hardware reset 2) are as follows:
                    � 00000000b when input on CNVSS pin is �L�
                    � 00000010b when input on CNVSS pin is �H�
                    The values after software reset, watchdog timer reset and oscillation stop detection reset are as follows:
                    � 00000000b when PM01 to PM00 bits are �00b� (single-chip mode)
                    � 00000010b when PM01 to PM00 bits are �01b� (memory expansion mode) or
                    �11b� (microprocessor mode)
                  */
    // setting pull up control register
    PUR2 = 0x00;  //Setting Pull-up control register 2
                  // --XX XXXX
                  //   || |||+- P80 to P83 pull-up    0: Not pulled high 1: pulled high (1)
                  //   || ||+-- P84 to P87 pull-up
                  //   || |+--- P90 to P93 pull-up
                  //   || +---- P94 to P97 pull-up
                  //   |+------ P100 to P103 pull-up
                  //   +------- P104 to P107 pull-up
                  /*
                    NOTES:
                    1. The pin for which this bit is �1� (pulled high) and the direction bit is �0� (input mode) is pulled high.
                    2. The P8_5 pin does not have pull-up.
                  */

    //Setting port direction registers
    PD0  = 0x00;  // P0 all inputs as default
    P0   = 0x00;
    PD1  = 0x00;
    P1   = 0x00;

    INT3IC = 0;
    INT2IC = 0;
    INT1IC = 0;
    INT0IC = 0;
    TB5IC  = 0;
    TB4IC  = 0;
    TB3IC  = 0;
    TB2IC  = 0;
    TB1IC  = 0;
    TB0IC  = 0;
    INT5IC = 0;
    INT4IC = 0;
    DMA0IC = 0;
    DMA1IC = 0;
    KUPIC  = 0;
    ADIC   = 0;
    S2TIC  = 0;
    S2RIC  = 0;
    S1TIC  = 0;
    S1RIC  = 0;
    S0TIC  = 0;
    S0RIC  = 0;
    TA0IC  = 0;
    TA1IC  = 0;
    TA2IC  = 0;
    TA3IC  = 0;
    TA4IC  = 0;

    IFSR   = 0;
    __set_interrupt_level(0);  // allow all interrupt levels...
  return;
}


/* Demo app include files. */
#include "PollQ.h"
#include "integer.h"
#include "partest.h"
#include "serial.h"

/* The period between executions of the check task before and after an error
has been discovered.  If an error has been discovered the check task runs
more frequently - increasing the LED flash rate. */
#define mainNO_ERROR_CHECK_PERIOD    ( ( portTickType ) 1000 / portTICK_RATE_MS )
#define mainERROR_CHECK_PERIOD      ( ( portTickType ) 100 / portTICK_RATE_MS )

/* Priority definitions for some of the tasks.  Other tasks just use the idle
priority. */
#define mainQUEUE_POLL_PRIORITY      ( tskIDLE_PRIORITY + 2 )
#define mainCHECK_TASK_PRIORITY      ( tskIDLE_PRIORITY + 3 )

/* The LED that is flashed by the check task. */
#define mainCHECK_TASK_LED        ( 0 )

/* Constants required for the communications.  Only one character is ever
transmitted. */
#define mainCOMMS_QUEUE_LENGTH      ( 5 )
#define mainNO_BLOCK          ( ( portTickType ) 0 )
#define mainBAUD_RATE          ( ( unsigned portLONG ) 9600 )

/*
 * The task function for the "Check" task.
 */
static portTASK_FUNCTION_PROTO( vErrorChecks, pvParameters );

/*
 * Checks the unique counts of other tasks to ensure they are still operational.
 * Returns pdTRUE if an error is detected, otherwise pdFALSE.
 */
static portBASE_TYPE prvCheckOtherTasksAreStillRunning( void );




/** set ms timer function */
/* This routine setups timer 1 and clears timer flag */
static void timer_install(void)
{
  /* this function is called before interrupts are enabled */

  TB1MR = 0x80;     // XXXX XXXX
                    // |||| ||++- operation mode: 00: timer 01: event counter 10:one shot timer 11: PWM
                    // |||| |+--- pulse output at pin TA4out 0: OFF 1: ON
                    // |||| +---- gate function: 0: timer counts only when TA0in is "L", 1: .. is "H"
                    // |||+------ gate function  0: not available 1: available
                    // ||+------- must always be 0 in timer mode
                    // ++-------- count source select bits: 00:f1  01:f8  10:f32 11:fc32

  TB1 = 7500-1;     // 20ms resolution @ 12MHz f32
  TB1IC = configKERNEL_INTERRUPT_PRIORITY+1;     // interrupt priority level select bit 0...7
  portNOP();
  portNOP();
  tb1s = 0x01;      // start timer B0 (count flag)

}
/** set ms timer function */
/* This routine setups timer 1 and clears timer flag */
static void timer1_install(void)
{

  TB2MR = 0x80;     // XXXX XXXX
                    // |||| ||++- operation mode: 00: timer 01: event counter 10:one shot timer 11: PWM
                    // |||| |+--- pulse output at pin TA4out 0: OFF 1: ON
                    // |||| +---- gate function: 0: timer counts only when TA0in is "L", 1: .. is "H"
                    // |||+------ gate function  0: not available 1: available
                    // ||+------- must always be 0 in timer mode
                    // ++-------- count source select bits: 00:f1  01:f8  10:f32 11:fc32

  TB2 = 7500-1;     // 20ms resolution @ 12MHz f32
  TB2IC = configKERNEL_INTERRUPT_PRIORITY+2;     // interrupt priority level select bit 0...7
  portNOP();
  portNOP();
  tb2s = 0x01;      // start timer B0 (count flag)

}


/* setup two interrupts that can nest, giving a semafore from ISR
   to wake the a task sleeping on the semafore */
static xSemaphoreHandle xSemaphore = NULL;
static xSemaphoreHandle xSemaphore1 = NULL;

/* to use as watch variables the task and interrupts */
volatile static int count1 = 0;
volatile static int count2 = 0;
volatile static int count3 = 0;
volatile static int count4 = 0;

portINTERRUPT_HANDLER(timerB1_isr)
{
  static unsigned char time = 0;
  portBASE_TYPE xHigherPriorityTaskWoken;
  if (++time == 0)
  {
    xSemaphoreGiveFromISR(xSemaphore, &xHigherPriorityTaskWoken);
    count1++;
  }
  portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);
}


portINTERRUPT_HANDLER(timerB2_isr)
{
  static unsigned char time = 0;
  portBASE_TYPE xHigherPriorityTaskWoken;
  if (++time == 0)
  {
    xSemaphoreGiveFromISR(xSemaphore1, &xHigherPriorityTaskWoken);
    count2++;
  }
  portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);
}


static portTASK_FUNCTION(vWaitSemaphoreTask, pvParameters)
{
  xSemaphoreTake( xSemaphore, portMAX_DELAY);// semaphore set after create
  timer_install();
  while(1)
  {
    xSemaphoreTake( xSemaphore, portMAX_DELAY);
    count3++;
  }
}

static portTASK_FUNCTION(vWaitSemaphore1Task, pvParameters)
{
  xSemaphoreTake( xSemaphore1, portMAX_DELAY);// semaphore set after create
  timer1_install();
  while(1)
  {
    xSemaphoreTake( xSemaphore1, portMAX_DELAY);
    count4++;
  }
}

/* just stop on overflow */
void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed portCHAR *pcTaskName )
{
  asm("BRK");
}


volatile static unsigned char q=1;

int main( void )
{
  initialize_processor();


  /* Start the standard demo tasks found in the demo\common directory. */
  vStartIntegerMathTasks( tskIDLE_PRIORITY + 1);
  vStartPolledQueueTasks( mainQUEUE_POLL_PRIORITY );

  /* Start the check task defined in this file. */
  xTaskCreate( vErrorChecks, ( const portCHAR * ) "Check", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );

  xTaskCreate( vWaitSemaphoreTask, ( const portCHAR * ) "WSem", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY+4, NULL );
  xTaskCreate( vWaitSemaphore1Task, ( const portCHAR * ) "WSem1", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY+3, NULL );
  vSemaphoreCreateBinary( xSemaphore );
  vSemaphoreCreateBinary( xSemaphore1 );

  /* Start the scheduler.  Will never return here. */
  vTaskStartScheduler();

  return 0;
}


static portTASK_FUNCTION(vErrorChecks, pvParameters )
{
portTickType xDelayTime = mainNO_ERROR_CHECK_PERIOD;
portBASE_TYPE xErrorOccurred;

  /* Cycle for ever, delaying then checking all the other tasks are still
  operating without error. */
  for( ;; )
  {
    /* Wait until it is time to check the other tasks. */
    vTaskDelay( xDelayTime );

    /* Check all the other tasks are running, and running without ever
    having an error. */
    xErrorOccurred = prvCheckOtherTasksAreStillRunning();

    /* If an error was detected increase the frequency of the LED flash. */
    if( xErrorOccurred == pdTRUE )
    {
      xDelayTime = mainERROR_CHECK_PERIOD;
    }

    /* Flash the LED for visual feedback. */
    vParTestToggleLED( mainCHECK_TASK_LED );
  }
}
/*-----------------------------------------------------------*/

static portBASE_TYPE prvCheckOtherTasksAreStillRunning( void )
{
portBASE_TYPE xErrorHasOccurred = pdFALSE;

  if( xAreIntegerMathsTaskStillRunning() != pdTRUE )
  {
    xErrorHasOccurred = pdTRUE;
  }

  if( xArePollingQueuesStillRunning() != pdTRUE )
  {
    xErrorHasOccurred = pdTRUE;
  }

  return xErrorHasOccurred;
}


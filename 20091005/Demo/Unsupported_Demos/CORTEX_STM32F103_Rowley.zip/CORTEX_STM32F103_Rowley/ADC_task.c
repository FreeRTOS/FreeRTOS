
/******************** (C) COPYRIGHT 2009 HiConnect  ****************************
*
* THIS SOFTWARE HAS BEEN WRITTEN FOR DEMONSTRATION ONLY AND IS GIVEN BACK TO
* FreeRTOS TO SUPPORT IT.
* THERE IS NO WARRANTY OR LIABILITY APPLICABLE IF THIS SOFTWARE IS USED AND DOES
* NOT BEHAVE AS EXPECTED.
* G.S.
*/


/* some definitions, what to use in STM32 */
#include "stm32f10x_lib.h"

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

/* use private font */
#include "fonts.h"
#include "lcd.h"


#ifdef	__STM32F10x_ADC_H

/* define ADC conversion cycle */
#define mainADC_DELAY			(( portTickType )( 200 ) / portTICK_RATE_MS )

/* semaphore is used to wait for DMA-interrupt */
xSemaphoreHandle	xAdcSemaphore;

/* average value read from potentiometer */
u16					ADC_result;
/* buffer for raw data samples */
u16					ADC_buffer[8];

/* declaration of module-internal functions */
void	InitializeAdcDma( void );
void	InitializeAdcChannel( void );
void	InitializePwmLed( void );

/* queue to place display requests in */
extern xQueueHandle lcdQueue;


/*
 * The ADC-Task initializes an A/D-conversion algorithm that cyclically reads
 * eight samples from the potentiometer (connected to Pin33 = PC4/ADC_IN14)
 * and transfers it to RAM using DMA.
 * Then the DMA generates an interrupt that ADC-Task is waiting for.
 * If all samples are written then the ADC Task evaluates the average value,
 * converts it to a value between 0 and 100 and uses this value to set a
 * PWM-Duty cycle at LED4.
 *
 * Furthermore it sends a display message to LCD-Task if the value has changed.
 */
/*****************************************************************************/
	void	vADCTask( void *pvParameters )
/*****************************************************************************/
{
u16					lastAdValue;
#ifdef __LCD_H
static portCHAR		lcdPrintBuffer[24];
LCD_QUEUE_ELEMENT	lcdCmd;
#endif	/* __LCD_H */

  /* Create the semaphore used to wake ADC Task(). */
  vSemaphoreCreateBinary( xAdcSemaphore );

  /* DMA channel1 configuration */
  InitializeAdcDma();

  /* Initialize ADC1 */
  InitializeAdcChannel();

  /* Initialize LED4-Pin as PWM-Output (dim LED) */
  InitializePwmLed();

#ifdef	__LCD_H
	/* Clear the LCD area */
  lcdCmd.command = 0x11;
  lcdCmd.par1 = Line9 + 10*FONT_HEIGHT;
  lcdCmd.par2 = (0x0) | (0x0 << 6) | (0x12 << 11); // Dark Red;
  lcdCmd.paraPtr = lcdPrintBuffer;
  xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );

  /* prepare 'lcdCmd' for later usage */
  lcdCmd.command = 2;
#endif	/* __LCD_H */

  /* Enable EOC interupt */
  ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);

  /* Start ADC1 Software Conversion */
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);

  for(lastAdValue = 0x1000; 1; )	{
	/* Wait for an interrupt. */
	if( xSemaphoreTake( xAdcSemaphore, mainADC_DELAY ) == pdFALSE )	{
		/* Timeout --> Start next cycle */
		ADC_SoftwareStartConvCmd(ADC1, ENABLE);
		}
	else if(lastAdValue != (ADC_result & 0xFFF))	{
		/* Interrupt has come and new value is available */
		lastAdValue = (ADC_result & 0xFFF);
#ifdef	__LCD_H
		sprintf(lcdPrintBuffer, "A/D-Value = %d %%  ", ((100 * lastAdValue) / 0xFFF));
		xQueueSend( lcdQueue, &lcdCmd, portMAX_DELAY );
#endif	/* __LCD_H */

		TIM_SetCompare4(TIM3, (lastAdValue & 0xFFE) + 1);
		}
	}
}


/*******************************************************************************
* Function Name  : ADC_IRQHandler
* Description    : This function handles ADC global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
	void	ADC_IRQHandler(void)
/*****************************************************************************/
{
int				i;
unsigned int	averageValue;
portBASE_TYPE	xHigherPriorityTaskWoken;

  /* evaluate average Value of eight conversion results */
  for(averageValue = i = 0; i < 8; i++)	{
	averageValue += ADC_buffer[i];
//	ADC_buffer[i] = 0;	// Test
	}
  ADC_result = averageValue / 8;

  /* notify ADC Task*/
  xHigherPriorityTaskWoken = pdFALSE;
  xSemaphoreGiveFromISR( xAdcSemaphore, &xHigherPriorityTaskWoken );
}


/*******************************************************************************
* Function Name  : InitializePwmLed
* Description    : This function configures PC9 as PWM-Output.
* Input          : None
* Output         : None
* Return         : None
******************************************************************************/
	void	InitializePwmLed( void )
/*****************************************************************************/
/* TIM3_CH4 needs to be used if LED4 (connected to PC9) should be handled */
{
GPIO_InitTypeDef		GPIO_InitStructure;
TIM_TimeBaseInitTypeDef	TIM_TimerInitStructure;
TIM_OCInitTypeDef		TIM_OCInitStructure;

  /* Re-Map Timer3 to Port C */
  GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);

  /* Configure Port C-Pin9 as Alternate Function Output */
  GPIO_InitStructure.GPIO_Pin				=  GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode				= GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed				= GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  /* TIM3 clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

  /* Configure Timer3 Channel 4 as PWM-Timer  */
  TIM_TimerInitStructure.TIM_Period			= 0x1000;
  TIM_TimerInitStructure.TIM_Prescaler		= 0x0;
  TIM_TimerInitStructure.TIM_ClockDivision	= 0x0;
  TIM_TimerInitStructure.TIM_CounterMode	= TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM3, &TIM_TimerInitStructure);

  /* Master Configuration in PWM1 Mode */
  TIM_OCInitStructure.TIM_OCMode			= TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_Pulse				= 0x3F;
  TIM_OCInitStructure.TIM_OutputState		= TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState		= TIM_OutputNState_Disable;
  TIM_OCInitStructure.TIM_OCPolarity		= TIM_OCPolarity_High;
  TIM_OCInitStructure.TIM_OCNPolarity		= TIM_OCNPolarity_High;
  TIM_OCInitStructure.TIM_OCIdleState		= TIM_OCIdleState_Reset;
  TIM_OCInitStructure.TIM_OCNIdleState		= TIM_OCNIdleState_Reset;
  TIM_OC4Init(TIM3, &TIM_OCInitStructure);

  /* TIM3 enable counter */
  TIM_Cmd(TIM3, ENABLE);
}


/*******************************************************************************
* Function Name  : InitializeAdcDma
* Description    : This function configures DMA to transfer ADC-results to RAM.
* Input          : None
* Output         : None
* Return         : None
******************************************************************************/
	void	InitializeAdcDma( void )
/*****************************************************************************/
{
DMA_InitTypeDef	DMA_InitStructure;

  /* DMA channel1 configuration */
  /* Enable DMA clock */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

  DMA_DeInit(DMA1_Channel1);
  DMA_InitStructure.DMA_PeripheralBaseAddr	= (u32)&(ADC1->DR);
  DMA_InitStructure.DMA_MemoryBaseAddr		= (u32)&(ADC_buffer[0]);
  DMA_InitStructure.DMA_DIR					= DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize			= 8;
  DMA_InitStructure.DMA_PeripheralInc		= DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc			= DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize	= DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize		= DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode				= DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority			= DMA_Priority_High;
  DMA_InitStructure.DMA_M2M					= DMA_M2M_Disable;
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);

  /* Enable DMA channel1 */
  DMA_Cmd(DMA1_Channel1, ENABLE);
}


/*******************************************************************************
* Function Name  : InitializeAdcChannel
* Description    : Initializes and calibrates AD-Converter
* Input          : None
* Output         : None
* Return         : None
******************************************************************************/
	void	InitializeAdcChannel( void )
/*****************************************************************************/
{
ADC_InitTypeDef	ADC_InitStructure;

  /* Initialize ADC1 */
  ADC_InitStructure.ADC_Mode				= ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode		= ENABLE;
  ADC_InitStructure.ADC_ContinuousConvMode	= DISABLE;
  ADC_InitStructure.ADC_ExternalTrigConv	= ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign			= ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel		= 8;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* Initialize Conversion Sequence List */
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 2, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 3, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 4, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 5, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 6, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 7, ADC_SampleTime_55Cycles5);
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 8, ADC_SampleTime_55Cycles5);

  /* Enable ADC1 DMA */
  ADC_DMACmd(ADC1, ENABLE);

  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);

  /* Enable ADC1 reset calibaration register */
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* Start ADC1 calibration */
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));
}

#endif //* __STM32F10x_ADC_H */

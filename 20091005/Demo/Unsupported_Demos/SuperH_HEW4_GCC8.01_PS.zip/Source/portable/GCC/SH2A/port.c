/*
	FreeRTOS.org V4.7.2 - Copyright (C) 2003-2008 Richard Barry.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section 
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************

	Please ensure to read the configuration and relevant port sections of the 
	online documentation.

	+++ http://www.FreeRTOS.org +++
	Documentation, latest information, license and contact details.  

	+++ http://www.SafeRTOS.com +++
	A version that is certified for use in safety critical systems.

	+++ http://www.OpenRTOS.com +++
	Commercial support, development, porting, licensing and training services.

	***************************************************************************
*/

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"


/*-----------------------------------------------------------
 * Implementation of functions defined in portable.h for the H8S port.
 *----------------------------------------------------------*/


/*-----------------------------------------------------------*/

/* When the task starts interrupts should be enabled. */
#define portINITIAL_CCR			( ( portSTACK_TYPE ) 0x00 )

/* Hardware specific constants used to generate the RTOS tick from the TPU. */
#define portCLEAR_ON_TGRA_COMPARE_MATCH ( ( unsigned portCHAR ) 0x20 )
#define portCLOCK_DIV_64				( ( unsigned portCHAR ) 0x03 )
#define portCLOCK_DIV					( ( unsigned portLONG ) 64 )
#define portTGRA_INTERRUPT_ENABLE		( ( unsigned portCHAR ) 0x01 )
#define portTIMER_CHANNEL				( ( unsigned portCHAR ) 0x02 )
#define portMSTP13						( ( unsigned portSHORT ) 0x2000 )

/*
 * Setup TPU channel one for the RTOS tick at the requested frequency.
 */
static void prvSetupTimerInterrupt( void );

/*
 * The ISR used by portYIELD(). This is installed as a trap handler.
 */
void vPortYield( void ) __attribute__((interrupt_handler));

/*-----------------------------------------------------------*/

/* 
 * See header file for description. 
 */
portSTACK_TYPE *pxPortInitialiseStack( portSTACK_TYPE *pxTopOfStack, pdTASK_CODE pxCode, void *pvParameters )
{
unsigned portLONG ulValue;

	// Need a 4-byte alligned address
	pxTopOfStack = (portSTACK_TYPE*) ( (portLONG) pxTopOfStack & 0xFFFFFFFC);

	/* Just some random numbers to mark bottom of stack*/
	pxTopOfStack--;
	*pxTopOfStack = 0x11;
	pxTopOfStack--;
	*pxTopOfStack = 0x22;
	pxTopOfStack--;
	*pxTopOfStack = 0x33;
	pxTopOfStack--;
	*pxTopOfStack = 0x44;


	/* Return */
	ulValue = ( unsigned portLONG ) pxCode;

	pxTopOfStack--;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );
	pxTopOfStack--;
	ulValue >>= 8UL;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );
	pxTopOfStack--;
	ulValue >>= 8UL;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );
	pxTopOfStack--;
	ulValue >>= 8UL;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );


	
	/* r7 */
	pxTopOfStack--;
	*pxTopOfStack = 0x77;
	pxTopOfStack--;
	*pxTopOfStack = 0x77;
	pxTopOfStack--;
	*pxTopOfStack = 0x77;
	pxTopOfStack--;
	*pxTopOfStack = 0x77;

	/* r6 */
	pxTopOfStack--;
	*pxTopOfStack = 0x66;
	pxTopOfStack--;
	*pxTopOfStack = 0x66;
	pxTopOfStack--;
	*pxTopOfStack = 0x66;
	pxTopOfStack--;
	*pxTopOfStack = 0x66;

	/* r5 */
	pxTopOfStack--;
	*pxTopOfStack = 0x55;
	pxTopOfStack--;
	*pxTopOfStack = 0x55;
	pxTopOfStack--;
	*pxTopOfStack = 0x55;
	pxTopOfStack--;
	*pxTopOfStack = 0x55;

	/* r4 */
	pxTopOfStack--;
	*pxTopOfStack = 0x44;
	pxTopOfStack--;
	*pxTopOfStack = 0x44;
	pxTopOfStack--;
	*pxTopOfStack = 0x44;
	pxTopOfStack--;
	*pxTopOfStack = 0x44;

	/* r3 */
	pxTopOfStack--;
	*pxTopOfStack = 0x33;
	pxTopOfStack--;
	*pxTopOfStack = 0x33;
	pxTopOfStack--;
	*pxTopOfStack = 0x33;
	pxTopOfStack--;
	*pxTopOfStack = 0x33;

	/* r2 */
	pxTopOfStack--;
	*pxTopOfStack = 0x22;
	pxTopOfStack--;
	*pxTopOfStack = 0x22;
	pxTopOfStack--;
	*pxTopOfStack = 0x22;
	pxTopOfStack--;
	*pxTopOfStack = 0x22;

	/* R1 */
	pxTopOfStack--;
	*pxTopOfStack = 0x11;
	pxTopOfStack--;
	*pxTopOfStack = 0x11;
	pxTopOfStack--;
	*pxTopOfStack = 0x11;
	pxTopOfStack--;
	*pxTopOfStack = 0x11;

	/* R0 */
	pxTopOfStack--;
	*pxTopOfStack = 0x00;
	pxTopOfStack--;
	*pxTopOfStack = 0x00;
	pxTopOfStack--;
	*pxTopOfStack = 0x00;
	pxTopOfStack--;
	*pxTopOfStack = 0x00;


	/* r14 */
	pxTopOfStack--;
	*pxTopOfStack = 0xEE;
	pxTopOfStack--;
	*pxTopOfStack = 0xEE;
	pxTopOfStack--;
	*pxTopOfStack = 0xEE;
	pxTopOfStack--;
	*pxTopOfStack = 0xEE;

	/*FPSCR*/
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR00 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR1 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR2 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR3 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR4 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR5 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR06 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR07 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR08 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR09 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR10 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* FR11 */
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	
	/* MACH */
	*(--pxTopOfStack) = 0xFF;
	*(--pxTopOfStack) = 0xFF;
	*(--pxTopOfStack) = 0xFF;
	*(--pxTopOfStack) = 0xFF;

	/* MACL */
	*(--pxTopOfStack) = 0x11;
	*(--pxTopOfStack) = 0x11;
	*(--pxTopOfStack) = 0x11;
	*(--pxTopOfStack) = 0x11;

	/*FPUL*/
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;
	*(--pxTopOfStack) = 0x00;

	/* PR */
	ulValue = ( unsigned portLONG ) pxCode;

	pxTopOfStack--;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );
	pxTopOfStack--;
	ulValue >>= 8UL;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );
	pxTopOfStack--;
	ulValue >>= 8UL;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );
	pxTopOfStack--;
	ulValue >>= 8UL;
	*pxTopOfStack = ( portSTACK_TYPE ) ( ulValue & 0xff );
	
	return pxTopOfStack;
}
/*-----------------------------------------------------------*/

portBASE_TYPE xPortStartScheduler( void )
{
extern void * pxCurrentTCB;

	/* Setup the hardware to generate the tick. */
	prvSetupTimerInterrupt();
	
	/* Restore the context of the first task that is going to run. */
	portRESTORE_STACK_POINTER();

	portFIRST_RESTORE();

	/* Should not get here. */
	return pdTRUE;
}
/*-----------------------------------------------------------*/

void vPortEndScheduler( void )
{
	/* It is unlikely that the SH port will get stopped. */
}
/*-----------------------------------------------------------*/

/*
 * Manual context switch.  This is a trap handler.
 */
void vPortYield( void )
{
	portSAVE_STACK_POINTER();
		vTaskSwitchContext();
	portRESTORE_STACK_POINTER();
}
/*-----------------------------------------------------------*/

/* 
 * The interrupt handler installed for the RTOS tick depends on whether the 
 * preemptive or cooperative scheduler is being used. 
 */
#if( configUSE_PREEMPTION == 1 )

	/* 
	 * The preemptive scheduler is used so the ISR calls vTaskSwitchContext().
	 * The function prologue saves the context so all we have to do is save
	 * the stack pointer.
	 */
	void vTickISR( void ) __attribute__((interrupt_handler));
	void vTickISR( void )
	{
		portSAVE_STACK_POINTER();
		
		vTaskIncrementTick();
		vTaskSwitchContext();

		/* Clear the interrupt. */
		MTU2.TSR_1.BYTE &= ~portTGRA_INTERRUPT_ENABLE;

		portRESTORE_STACK_POINTER();
	}

#else

	/*
	 * The cooperative scheduler is being used so all we have to do is 
	 * periodically increment the tick.  This can just be a normal ISR and
	 * the "saveall" attribute is not required.
	 */
	void vTickISR( void ) __attribute__ ( ( interrupt_handler ) );
	void vTickISR( void )
	{
		vTaskIncrementTick();

		/* Clear the interrupt. */
		MTU2.TSR_1.BYTE &= ~portTGRA_INTERRUPT_ENABLE;
	}

#endif
/*-----------------------------------------------------------*/

/*
 * Setup timer 1 compare match to generate a tick interrupt.
 */
static void prvSetupTimerInterrupt( void )
{
const unsigned portLONG ulCompareMatch = ( configCPU_CLOCK_HZ / configTICK_RATE_HZ ) / portCLOCK_DIV;

	/* Turn the module on. */
	CPG.STBCR3.BIT.MSTP35 = 0;

	/* Set the interrupt priority level */
	INTC.IPR10.BIT._MTU10 = 0x0E; // TC

	/* Configure timer 1. */
	MTU2.TCR_1.BYTE = portCLEAR_ON_TGRA_COMPARE_MATCH | portCLOCK_DIV_64;

	/* Configure the compare match value for a tick of configTICK_RATE_HZ. */
	MTU2.TGRA_1.WORD = ulCompareMatch;

	/* Start the timer and enable the interrupt - we can do this here as 
	interrupts are globally disabled when this function is called. */
	MTU2.TIER_1.BYTE |= portTGRA_INTERRUPT_ENABLE;
	MTU2.TSTR.BYTE |= portTIMER_CHANNEL;
}
/*-----------------------------------------------------------*/




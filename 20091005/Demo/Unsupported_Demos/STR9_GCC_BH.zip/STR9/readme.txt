Here are 2 zip files.

STR9x.zip is the port specific stuff and need to be extracted to FreeRTOS/Source/portable/GCC/

str91x_gcc.zip has my code.  The target is custom made, running at 96Mhz from a 12Mhz oscillator. 
I have not used any of ST's 91x library functions, but have included the header files, as I have made use of the #defines

The Makefile as some path specfic defines at the top which need to be set

FreeRTOSConfig.h has a couple of bits you need to define - these are

configUSE_TIMER - set this to either TIM0, TIM1, TIM2, or TIM3 depending on the timer you wish to use for the system tick.
configSysTickIRQPriority is to set the priority of the interrupt.

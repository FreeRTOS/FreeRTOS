#include <utility>

std::pair<int, int> make_pair(int first, int second)
{
	return {first, second};
}

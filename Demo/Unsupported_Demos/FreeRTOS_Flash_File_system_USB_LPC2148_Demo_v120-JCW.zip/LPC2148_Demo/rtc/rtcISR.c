#include <stdlib.h>

//
// Scheduler includes
//
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "../uart/uart.h"
#include "../usbser/usbser.h"
#include "rtcISR.h"
#include "rtc.h"

//
//
//
static xQueueHandle consoleQueue = NULL;

//
//
//
void rtcISRInit (void)
{
#if defined CFG_CONSOLE_USB
  usbserGetRxQueue (&consoleQueue);
#elif defined CFG_CONSOLE_UART0
  uart0GetRxQueue (&consoleQueue);
#elif defined CFG_CONSOLE_UART1
  uart1GetRxQueue (&consoleQueue);
#else
#error "Eeek!  No console devices defined!"
#endif
}

//
//
//
void rtcISR (void) __attribute__ ((naked));
void rtcISR (void)
{
	portENTER_SWITCHING_ISR ();

  portBASE_TYPE taskWoken = pdFALSE;

  RTC_CCR = (RTC_CCR_CLKEN | RTC_CCR_CLKSRC);
  SCB_PCONP |= SCB_PCONP_PCRTC;

  if (RTC_ILR & RTC_ILR_RTCCIF)
  {
    U8 c = 0xff;

    if (consoleQueue && xQueueSendFromISR (consoleQueue, &c, (portBASE_TYPE) pdFALSE)) 
      taskWoken = pdTRUE;

	  RTC_ILR = RTC_ILR_RTCCIF;
  }

  if (RTC_ILR & RTC_ILR_RTCALF)
  {
    U8 c = 0xfe;

    if (consoleQueue && xQueueSendFromISR (consoleQueue, &c, (portBASE_TYPE) pdFALSE)) 
      taskWoken = pdTRUE;

	  RTC_ILR = RTC_ILR_RTCALF;
  }

  VIC_VectAddr = (unsigned portLONG) 0;

  RTC_CCR = (RTC_CCR_CLKEN | RTC_CCR_CLKSRC);
  SCB_PCONP &= ~SCB_PCONP_PCRTC;

	portEXIT_SWITCHING_ISR (taskWoken);
}

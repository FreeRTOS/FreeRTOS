#define CTOR(i, _)    : \
   T(X()),              \
/*
 * multi
 */    \
       \
   y() \
{ }
main()
{
}


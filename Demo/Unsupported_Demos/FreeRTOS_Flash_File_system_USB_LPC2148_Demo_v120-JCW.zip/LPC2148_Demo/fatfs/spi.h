#ifndef _MMCLLSPI1_H_
#define _MMCLLSPI1_H_

#include "sysdefs.h"

//
//
//
void spiChipSelect (BOOL select);
inline BOOL spiPresent (void);
inline BOOL spiWriteProtect (void);
U32 spiSetClockFreq (U32 frequency);
void spiInit (void);
U8 spiTransferByte (U8 c);
U8 spiWaitReady (void);
void spiSendBlock (U8 *pData, U32 size);
void spiReceiveBlock (U8 *pData, U32 size);
void spiDelay1ms (U32 delay);

#endif

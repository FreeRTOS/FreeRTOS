This is a simple demo application that makes use of the M16C IAR port
of FreeRTOS.

You may run the demo in the free M16C Simulator that comes with the
Renesas M16C C compiler toolchain and high performance embedded workshop.
See www.renesas.com "C Compiler Package for M16C Series and R8C Family"

When using the renesas simulator, the timers do not run. You need to
setup virtual timer interrupts for vector 26,27,28 with 1ms each.


IAR Build
4.7A  (4.7.1.0)
C:\Programme\IAR Systems\Embedded Workbench 4.0\common\bin\iarbuild.exe
07.11.2006 09:04:40, 16384 bytes

IAR Embedded Workbench IDE
4.7A  (4.7.1.0)
C:\Programme\IAR Systems\Embedded Workbench 4.0\common\bin\IarIdePm.exe
07.11.2006 08:54:06, 741376 bytes

IAR XLINK
4.60E (4.60.5.0)
C:\Programme\IAR Systems\Embedded Workbench 4.0\common\bin\xlink.exe
06.12.2006 18:02:32, 1384448 bytes

IAR Assembler for M16C
3.21A/W32 (3.21.1.4)
C:\Programme\IAR Systems\Embedded Workbench 4.0\m16c\bin\am16c.exe
08.12.2006 11:31:30, 602112 bytes

IAR C/C++ Compiler for M16C
3.21D/W32 (3.21.4.4)
C:\Programme\IAR Systems\Embedded Workbench 4.0\m16c\bin\iccm16c.exe
04.06.2007 12:30:21, 6258688 bytes


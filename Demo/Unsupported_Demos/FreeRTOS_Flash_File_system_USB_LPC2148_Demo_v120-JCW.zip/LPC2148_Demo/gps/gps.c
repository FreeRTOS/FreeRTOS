//
//
//
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

#include "gps.h"

//
//
//
#define GPS_MAX_NMEA_SENTENCE 128

//
//
//
static gpsData_t gpsData;
static xSemaphoreHandle semaphore;

//
//
//
static void gpsNormalizeNMEA (char *s);
static unsigned char gpsChecksumNMEA (char *sz);
static void gpsHandlerGGA (char *nmeaSentence);
static void gpsHandlerRMC (char *nmeaSentence);
static void gpsHandlerRestart (char *nmeaSentence);
static void gpsDispatchMessages (char *nmeaSentence);
static int gpsProcessByte (unsigned char c, char *nmeaSentence);

//
//
//
static void gpsNormalizeNMEA (char *s)
{
  int l = -1;

  while (*s && *s != '*')
  {
    if (*s == ',' && (*(s + 1) == ',' || *(s + 1) == '*'))
    {
      if (l == -1)
        l = strlen (s) + 1;

      memmove (s + 3, s + 1, l);
      *++s = '-';
      *++s = '1';
      l += 2;
    }

    s++;

    if (l != -1)
      l--;
  }
}

//
//
//
static unsigned char gpsChecksumNMEA (char *sz)
{
  short i;
  unsigned char cs;

  for (cs = 0, i = 1; sz [i] && sz [i] != '*'; i++)
    cs ^= ((unsigned char) sz [i]);

  return cs;
}

//
//
//
static void gpsHandlerGGA (char *nmeaSentence)
{
  char   valid = 0;
  double height = 0.0;
  double latitude = 0.0, longitude = 0.0;
  char   latitudeSign = 0, longitudeSign = 0;

  if (sscanf (nmeaSentence, "%*f,%lf,%c,%lf,%c,%c,%*d,%*f,%lf", &latitude, &latitudeSign, &longitude, &longitudeSign, &valid, &height) == 6)
  {
    if (xSemaphoreTake (semaphore, portMAX_DELAY) == pdTRUE)
    {
      gpsData.valid = (valid - '0');
      gpsData.height = height;
      gpsData.latitude  = latitude * (latitudeSign == 'N' ? 1.0 : -1.0);
      gpsData.longitude = longitude * (longitudeSign == 'E' ? 1.0 : -1.0);

      xSemaphoreGive (semaphore);
    }
  }
}

static void gpsHandlerRMC (char *nmeaSentence)
{
  float speed, course;
  int gpsdate, gpstime;

  if (sscanf (nmeaSentence, "%d.%*d,%*c,%*f,%*c,%*f,%*c,%f,%f,%d", &gpstime, &speed, &course, &gpsdate) == 4)
  {
    if (xSemaphoreTake (semaphore, portMAX_DELAY) == pdTRUE)
    {
      gpsData.utcDay      =  gpsdate / 10000;
      gpsData.utcMonth    = (gpsdate / 100) % 100;
      gpsData.utcYear     = (gpsdate % 100) + 2000;
      gpsData.utcHours    =  gpstime / 10000;
      gpsData.utcMinutes  = (gpstime / 100) % 100;
      gpsData.utcSeconds  =  gpstime % 100;
      gpsData.groundSpeed =  speed;
      gpsData.trueCourse  =  course;

      xSemaphoreGive (semaphore);
    }
  }
}

static void gpsHandlerRestart (char *nmeaSentencemea __attribute__ ((unused)))
{
  if (xSemaphoreTake (semaphore, portMAX_DELAY) == pdTRUE)
  {
    gpsData.restarts++;
    xSemaphoreGive (semaphore);
  }
}

//
//
//
typedef struct nmeaDispatch_s
{
  const char *sentence;
  short length;
  void (*handler) (char *sentence);
  short normalize;
}
nmeaDispatch_t;

static const nmeaDispatch_t nmeaDispatch [] =
{
  { "$GPGGA",    6, gpsHandlerGGA,      1 },
  { "$GPRMC",    6, gpsHandlerRMC,      1 },
  { "$HW Type",  8, gpsHandlerRestart,  0 },
  { NULL,        0, NULL,               0 }
};

static void gpsDispatchMessages (char *nmeaSentence)
{
  int i;

  for (i = 0; nmeaDispatch [i].handler; i++)
  {
    if (!strncmp (nmeaDispatch [i].sentence, nmeaSentence, nmeaDispatch [i].length))
    {
      if (nmeaDispatch [i].normalize)
      {
        gpsNormalizeNMEA (&nmeaSentence [7]);
        (*nmeaDispatch [i].handler) (&nmeaSentence [7]);
      }
      else
        (*nmeaDispatch [i].handler) (NULL);

      break;
    }
  }
}

//
//
//
static int gpsProcessByte (unsigned char c, char *nmeaSentence)
{
  short complete = 0;
  static short state = 0;
  static short pos = 0;

  switch (state)
  {
    case 0 :
      {
        if (c == '$')
        {
          pos = 0;
          nmeaSentence [pos++] = '$';
          nmeaSentence [pos] = '\0';
          state = 1;
        }
        else
          state = 0;
      }
      break;

    case 1 :
      {
        if (pos < GPS_MAX_NMEA_SENTENCE)
        {
          if (c == 0x0a)
          {
            char *s;

            state = 0;

            if ((s = strchr (nmeaSentence, '*')))
            {
              int cksum;

              if (sscanf (s + 1, "%x", &cksum) == 1)
              {
                if (gpsChecksumNMEA (nmeaSentence) == cksum)
                  complete = 1;
              }
              else
                fprintf (stderr, "NMEA checksum error: got 0x%02x, want %s", cksum, s);
            }
            else
              fprintf (stderr, "NMEA checksum not found: \"%s\"", nmeaSentence);
          }
          else if (c != 0x0d)
          {
            nmeaSentence [pos++] = c;
            nmeaSentence [pos] = '\0';
          }
        }
        else
          state = 0;
      }
      break;
  }

  return (complete);
}

//
//  Return 1 if got a copy, 0 if not.
//
int gpsCopyData (gpsData_t *dst)
{
#ifndef CFG_CONSOLE_UART1
  if (xSemaphoreTake (semaphore, 100 / portTICK_RATE_MS) == pdTRUE)
  {
    memcpy (dst, &gpsData, sizeof (gpsData_t));
    xSemaphoreGive (semaphore);
    return 1;
  }
#endif

  memset (dst, 0, sizeof (gpsData_t));
  return 0;
}

//
//
//
portTASK_FUNCTION (vGPSTask, pvParameters __attribute__ ((unused)))
{
  int fd;
  static char nmeaSentence [GPS_MAX_NMEA_SENTENCE];

  memset (&gpsData, 0, sizeof (gpsData));

  vSemaphoreCreateBinary (semaphore);

  fd = open ("/dev/uart1", O_RDONLY);

  if ((fd == -1) || (semaphore == NULL))
    for (;;)
      vTaskDelay (100);

  for (;;)
  {
    portCHAR c;

    if (read (fd, &c, sizeof (c)) == sizeof (c))
      if (gpsProcessByte (c, nmeaSentence))
        gpsDispatchMessages (nmeaSentence);
  }
}

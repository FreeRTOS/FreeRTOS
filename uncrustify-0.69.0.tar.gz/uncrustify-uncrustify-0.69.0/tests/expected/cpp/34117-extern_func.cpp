void foo();

// hello
extern "C"
BAR_EXPORT
void bar()
{
}

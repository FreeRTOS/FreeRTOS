{
	connect( timer , SIGNAL(timeout()) , this , SLOT(timeoutImage()) );
}

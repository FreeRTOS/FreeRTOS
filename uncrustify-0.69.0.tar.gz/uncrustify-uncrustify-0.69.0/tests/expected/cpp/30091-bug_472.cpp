// comment
void func( dbgTrace, (void) );

#ifndef _LEDS_H_
#define _LEDS_H_

//
//
//
extern xQueueHandle xLEDQueue;

//
//
//
portTASK_FUNCTION (vLEDFlashTask, pvParameters __attribute__ ((unused)));

#endif

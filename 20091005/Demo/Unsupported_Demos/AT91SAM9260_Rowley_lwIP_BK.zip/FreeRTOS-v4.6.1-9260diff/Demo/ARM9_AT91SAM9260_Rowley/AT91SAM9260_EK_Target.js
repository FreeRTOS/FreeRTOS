/******************************************************************************
  Target Script for Atmel AT91SAM9261 device.

  Copyright (c) 2006 Rowley Associates Limited.

  This file may be distributed under the terms of the License Agreement
  provided with this software.

  THIS FILE IS PROVIDED AS IS WITH NO WARRANTY OF ANY KIND, INCLUDING THE
  WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ******************************************************************************/

function OnConnect()
{
  TargetInterface.setMaximumJTAGFrequency(5000);
}

function OnAttach()
{   
  TargetInterface.setMaximumJTAGFrequency(15000000);
  TargetInterface.downloadDebugHandler();
}

function InitClocksAndSDRAM()
{
  var i;

  // Set up PLL A
  TargetInterface.pokeWord(0xFFFFFC28, 0x20603F09); // MULA=97, DIVA=9 - 18.432/9*97 = 198.656
  TargetInterface.delay(10);//while (!(TargetInterface.peekWord(0xFFFFFC68) & 2));
  // Use PLL A as processor clock and master clock divided by 2
  TargetInterface.pokeWord(0xFFFFFC30, 0x00000102);
  TargetInterface.delay(10);//while (!(TargetInterface.peekWord(0xFFFFFC68) & 8)); 

  // Select 32 bit data bus
  TargetInterface.pokeWord(0xFFFFF804, 0xFFFF0000); 
  TargetInterface.pokeWord(0xFFFFF870, 0xFFFF0000);

  // assign EBI CSA1 to SDRAM
  TargetInterface.pokeWord(0xFFFFEF1C, TargetInterface.peekWord(0xFFFFEF1C)| 2);
  
  // SDRAM timings and configuration
  TargetInterface.pokeWord(0xFFFFEA08, 0x85227259);
  TargetInterface.delay(10);
  
  // "All Banks Precharge"
  TargetInterface.pokeWord(0xFFFFEA00, 2);
  TargetInterface.pokeWord(0x20000000, 0);
  TargetInterface.delay(10);

  // 8 "Auto Refresh Commands"
  for (i=0;i<8;i++)
    {
      TargetInterface.pokeWord(0xFFFFEA00, 4);
      TargetInterface.pokeWord(0x20000000, 0);
    }
  // "Load Mode Register"
  TargetInterface.pokeWord(0xFFFFEA00, 3);
  TargetInterface.pokeWord(0x20000000, 0);  
  // Set Refresh Rate to 7.8 us
  TargetInterface.pokeWord(0xFFFFEA04, 780);  
  // Switch to normal mode
  TargetInterface.pokeWord(0xFFFFEA00, 0);
  TargetInterface.pokeWord(0x20000000, 0);  
}

function Reset()
{
  TargetInterface.resetAndStop(10);
  TargetInterface.setMaximumJTAGFrequency(5000);  
  TargetInterface.getICEBreakerRegister(5); /* Clear out Debug Comms Data */  
  // Make sure caches and mmu are turned off
  i = TargetInterface.executeMRC(0xEE010F00);
  TargetInterface.executeMCR(0xEE010F00, i & ~(1<<0|1<<2|1<<12));
  TargetInterface.getICEBreakerRegister(5); /* Clear out Debug Comms Data */  
  // Enable the main oscillator
  TargetInterface.pokeWord(0xFFFFFC20, 0x00000801); // CKGR_MOR = 801
  TargetInterface.delay(10);//while (!(TargetInterface.peekWord(0xFFFFFC68) & 1));
  TargetInterface.pokeWord(0xFFFFFC30, 1); // CKGR_MCKR = 1
  TargetInterface.setMaximumJTAGFrequency(500000);
  // Disable watchdog just in case the boot loader hasn't run?
  TargetInterface.pokeWord(0xFFFFFD44, 0x1 << 15);
  InitClocksAndSDRAM();
  TargetInterface.setMaximumJTAGFrequency(15000000);
  // Map Internal SRAM to address zero
  TargetInterface.pokeWord(0x00000000, 0x87654321);
  if (TargetInterface.peekWord(0x00000000) != 0x87654321)
    TargetInterface.pokeWord(0xFFFFEF00, 0x3);
  TargetInterface.downloadDebugHandler();
}

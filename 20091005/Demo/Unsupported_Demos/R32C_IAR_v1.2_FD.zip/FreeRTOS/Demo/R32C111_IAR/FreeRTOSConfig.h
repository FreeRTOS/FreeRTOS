/******************************************************************************
 *
 * Example Program       for R32C/111     FreeRTOS
 *
 * author                f.daners@swissworld.com
 *                       Felix Daners Engineering
 *                       Speerstrasse 32
 *                       8200 Schaffhausen
 *                       Switzerland
 *
 * platform              This program runs on
 *                       EVBR32C111-Carrier-USB
 *                       by Glyn GmbH & Co KG, Microcontroller Group
 *                       Distribution:
 *                       Elektor-Verlag GmbH
 *                       Systerfeldstrasse 25
 *                       52072 Aachen
 *                       Product: R32C/111-Starterkit (080928-91)
 *
 *****************************************************************************
 *
 * !!! THIS FILE IS LICENSED SEPARATELY FROM FREERTOS !!!
 *
 * Copyright (c) 2009, Felix Daners Engineering, Switzerland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * - Neither the name of the Felix Daners Engineering nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

/* IO definitions for the chosen device. */
#ifndef __IAR_SYSTEMS_ASM__
#include <intrinsics.h>
#endif

/*-----------------------------------------------------------
 * Application specific definitions.
 *
 * These definitions should be adjusted for your particular hardware and
 * application requirements.
 *
 * THESE PARAMETERS ARE DESCRIBED WITHIN THE 'CONFIGURATION' SECTION OF THE
 * FreeRTOS API DOCUMENTATION AVAILABLE ON THE FreeRTOS.org WEB SITE.
 *----------------------------------------------------------*/

#define configUSE_PREEMPTION            ( 1 )
#define configUSE_IDLE_HOOK             ( 0 )
#define configUSE_TICK_HOOK             ( 0 )
#define configTICK_RATE_HZ              ( ( portTickType ) 1000 )
#define configMAX_PRIORITIES            ( ( unsigned portBASE_TYPE ) 5 )
#define configMINIMAL_STACK_SIZE        ( ( unsigned portSHORT ) 40 )
#define configTOTAL_HEAP_SIZE	        ( ( size_t ) ( 1024 ) )
#define configMAX_TASK_NAME_LEN	        ( 32 )
#define configUSE_TRACE_FACILITY        ( 0 )
#define configUSE_16_BIT_TICKS          ( 1 )
#define configIDLE_SHOULD_YIELD	        ( 1 )

#define configCHECK_FOR_STACK_OVERFLOW  ( 0 )
#define configUSE_COUNTING_SEMAPHORES   ( 1 )
#define configUSE_MUTEXES               ( 1 )

#define configKERNEL_INTERRUPT_PRIORITY       0
#define configMAX_SYSCALL_INTERRUPT_PRIORITY  4

/* Co-routine definitions. */
#define configUSE_CO_ROUTINES           ( 0 )
#define configMAX_CO_ROUTINE_PRIORITIES ( 2 )

/* Set the following definitions to 1 to include the API function, or zero
to exclude the API function. */

#define INCLUDE_vTaskPrioritySet        ( 1 )
#define INCLUDE_uxTaskPriorityGet       ( 1 )
#define INCLUDE_vTaskDelete             ( 0 )
#define INCLUDE_vTaskCleanUpResources   ( 1 )
#define INCLUDE_vTaskSuspend            ( 1 )
#define INCLUDE_vTaskDelayUntil	        ( 1 )
#define INCLUDE_vTaskDelay              ( 1 )
#define INCLUDE_xTaskResumeFromISR      ( 1 )



#define USER_ISR_VECTOR_16 timer_B1_isr
#define USER_ISR_VECTOR_13 uart_1_tx_isr
#define USER_ISR_VECTOR_14 uart_1_rx_isr


#endif /* FREERTOS_CONFIG_H */

/*
    FreeRTOS.org V5.0.0 - Copyright (C) 2003-2008 Richard Barry.

    This file is part of the FreeRTOS.org distribution.

    FreeRTOS.org is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    FreeRTOS.org is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FreeRTOS.org; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    A special exception to the GPL can be applied should you wish to distribute
    a combined work that includes FreeRTOS.org, without being obliged to provide
    the source code for any proprietary components.  See the licensing section
    of http://www.FreeRTOS.org for full details of how and when the exception
    can be applied.

    ***************************************************************************
    ***************************************************************************
    *                                                                         *
    * SAVE TIME AND MONEY!  We can port FreeRTOS.org to your own hardware,    *
    * and even write all or part of your application on your behalf.          *
    * See http://www.OpenRTOS.com for details of the services we provide to   *
    * expedite your project.                                                  *
    *                                                                         *
    ***************************************************************************
    ***************************************************************************

    Please ensure to read the configuration and relevant port sections of the
    online documentation.

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

#include <ez80.h>
#include <stdlib.h>

#include "FreeRTOS.h"
#include "task.h"


/*-----------------------------------------------------------*/

/* We require the address of the pxCurrentTCB variable, but don't want to know
any details of its type. */
typedef void tskTCB;
extern volatile tskTCB * volatile pxCurrentTCB;

/*-----------------------------------------------------------*/

/*
 * Macro to save all the general purpose registers, the save the stack pointer
 * into the TCB.
 */

#define portSAVE_CONTEXT()                          \
    asm (   "xref   _pxCurrentTCB           \n\t"   \
            "di                             \n\t"   \
            "push   af                      \n\t"   \
            "in0    a,      (62h)           \n\t"   \
            "push   bc                      \n\t"   \
            "push   de                      \n\t"   \
            "push   hl                      \n\t"   \
            "push   iy                      \n\t"   \
            "ex     af,     af'             \n\t"   \
            "exx                            \n\t"   \
            "push   af                      \n\t"   \
            "push   bc                      \n\t"   \
            "push   de                      \n\t"   \
            "push   hl                      \n\t"   \
            "ld     ix,     0               \n\t"   \
            "add    ix,     sp              \n\t"   \
            "ld     hl,     (_pxCurrentTCB) \n\t"   \
            "ld     (hl),   ix              \n\t"   \
        );

/*
 * Opposite to portSAVE_CONTEXT().
 */

#define portRESTORE_CONTEXT()                       \
    asm (   "xref   _pxCurrentTCB           \n\t"   \
            "ld     hl,     (_pxCurrentTCB) \n\t"   \
            "ld     hl,     (hl)            \n\t"   \
            "ld     sp,     hl              \n\t"   \
            "pop    hl                      \n\t"   \
            "pop    de                      \n\t"   \
            "pop    bc                      \n\t"   \
            "pop    af                      \n\t"   \
            "exx                            \n\t"   \
            "ex     af,     af'             \n\t"   \
            "pop    iy                      \n\t"   \
            "pop    hl                      \n\t"   \
            "pop    de                      \n\t"   \
            "pop    bc                      \n\t"   \
            "pop    af                      \n\t"   \
            "pop    ix                      \n\t"   \
            "ei                             \n\t"   \
            "ret                            \n\t"   \
        );

/*-----------------------------------------------------------*/

static void prvSetupTimerInterrupt( void );
/*-----------------------------------------------------------*/

/*
 * See header file for description.
 */
portSTACK_TYPE *pxPortInitialiseStack( portSTACK_TYPE *pxTopOfStack, pdTASK_CODE pxCode, void *pvParameters )
{
    /* Place the parameter on the stack in the expected location. */
    *pxTopOfStack-- = ( portSTACK_TYPE ) pvParameters;

    /* Place the task return address on stack. Not used*/
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0x000000;

    /* The start of the task code will be popped off the stack last, so place
    it on first. */
    *pxTopOfStack-- = ( portSTACK_TYPE ) pxCode;

    /* ZDS II Stack Frame saved by the compiler (IX Register). */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0x111111;  /* IX  */

    /* Now the registers. */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0xAFAFAF;  /* AF  */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0xBCBCBC;  /* BC  */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0xDEDEDE;  /* DE  */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0xEFEFEF;  /* HL  */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0x222222;  /* IY  */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0xFAFAFA;  /* AF' */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0xCBCBCB;  /* BC' */
    *pxTopOfStack-- = ( portSTACK_TYPE ) 0xEDEDED;  /* DE' */
    *pxTopOfStack   = ( portSTACK_TYPE ) 0xFEFEFE;  /* HL' */

    return pxTopOfStack;
}
/*-----------------------------------------------------------*/

portBASE_TYPE xPortStartScheduler( void )
{
    /* Setup the hardware to generate the tick. */
    prvSetupTimerInterrupt();

    /* Restore the context of the first task that is going to run. */
    portRESTORE_CONTEXT();

    /* Should not get here. */
    return pdTRUE;
}
/*-----------------------------------------------------------*/

void vPortEndScheduler( void )
{
    /* It is unlikely that the eZ80 port will require this function as there
    is nothing to return to.  If this is required - stop the tick ISR then
    return back to main. */
}
/*-----------------------------------------------------------*/

/*
 * Manual context switch.  The first thing we do is save the registers so we
 * can use a naked attribute.
 */
void vPortYield( void )
{
    portSAVE_CONTEXT();
    vTaskSwitchContext();
    portRESTORE_CONTEXT();
}
/*-----------------------------------------------------------*/

/*
 * Context switch function used by the tick.  This must be identical to
 * vPortYield() from the call to vTaskSwitchContext() onwards.  The only
 * difference from vPortYield() is the tick count is incremented as the
 * call comes from the tick ISR.
 */
void vPortYieldFromTick( void )
{
    portSAVE_CONTEXT();
    vTaskIncrementTick();
    vTaskSwitchContext();
    portRESTORE_CONTEXT();
}
/*-----------------------------------------------------------*/

void timer_isr(void)
{
    /* Remove the ix register pushed by the compiler. */
    asm ("pop ix");

#if configUSE_PREEMPTION == 1
    /*
     * Tick ISR for preemptive scheduler.  We can use a naked attribute as
     * the context is saved at the start of vPortYieldFromTick().  The tick
     * count is incremented after the context is saved.
     */
    vPortYieldFromTick();
#else
    /*
     * Tick ISR for the cooperative scheduler.  All this does is increment the
     * tick count.  We don't need to switch context, this can only be done by
     * manual calls to taskYIELD();
     */
    vTaskIncrementTick();
#endif
    asm ("reti");
}

/*
 * Setup timer.
 */
static void prvSetupTimerInterrupt( void )
{
    void * set_vector(unsigned int vector,void (*hndlr)(void));
    unsigned char tmp;

    /* set Timer interrupt vector */
    set_vector(TIMER_VECTOR, timer_isr);

    TMR0_DR_H = (configCPU_CLOCK_HZ / 16UL / configTICK_RATE_HZ) >> 8;
    TMR0_DR_L = (configCPU_CLOCK_HZ / 16UL / configTICK_RATE_HZ) & 0xFF;

#ifdef _EZ80F91
    tmp = TMR0_IIR;
    TMR0_CTL = 0x0F;
    TMR0_IER = 0x01;
#else
    tmp = TMR0_CTL;
    #ifdef _EZ80190
        TMR0_CTL = 0x5F;
    #else
        TMR0_CTL = 0x57;
    #endif
#endif
}
/*-----------------------------------------------------------*/

namespace foo
{
long_type_name_t &foo1();
foo_t &foo2();
}

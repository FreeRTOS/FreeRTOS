#define NUM_LPM_TESTS ( sizeof(tests) / sizeof(tests[0]) )

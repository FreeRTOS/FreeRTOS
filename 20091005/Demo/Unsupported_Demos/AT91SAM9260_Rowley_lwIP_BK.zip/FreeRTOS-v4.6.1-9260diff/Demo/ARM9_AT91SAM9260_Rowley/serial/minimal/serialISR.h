#ifndef INC_SERIAL_ISR_H
#define INC_SERIAL_ISR_H

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "queue.h"

/*-----------------------------------------------------------*/

/* UART0 interrupt service routine.  This can cause a context switch so MUST
be declared "naked". */
void vUART_ISR( void ) __attribute__ ((naked));

/* 
 * The queues are created in serialISR.c as they are used from the ISR.
 * Obtain references to the queues. 
 */
void vSerialISRCreateQueues( unsigned portBASE_TYPE uxQueueLength,
                             xQueueHandle *pxRxedChars,
                             xQueueHandle *pxCharsForTx );

#endif

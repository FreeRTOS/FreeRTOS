

#ifndef __FONTS_H
#define __FONTS_H


#include "stm32f10x_lib.h"

#define FONT_WIDTH	6
#define FONT_HEIGHT	8

#endif /* __LCD_H */

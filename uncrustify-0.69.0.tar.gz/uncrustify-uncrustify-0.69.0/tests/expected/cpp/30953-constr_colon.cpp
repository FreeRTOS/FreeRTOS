class foo
{
   void bar_c(int t, int u)
      : t(222)
      , u(88)
   {
      // code
   }
};

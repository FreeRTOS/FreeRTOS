bool test()
{
	if ( true )
	{
		i = 10;
	}
	else
		if ( true )
		{
			i = 10;
		}
}

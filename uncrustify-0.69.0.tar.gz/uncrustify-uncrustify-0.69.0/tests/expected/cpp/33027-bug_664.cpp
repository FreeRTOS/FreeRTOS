bool dllInit =
    [ ]()
//34567890
    {
    } ();

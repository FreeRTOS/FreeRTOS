template< class B1 = void, class B2 = void >
struct conjunction : bool_constant<B1::value1&&B2::value2>
{
};
template< class B1 = void, class B2 = void >
struct conjunction : bool_constant<B1::value1&&B2::value2>
{
};

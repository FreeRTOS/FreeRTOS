extern int foo();
extern int foo(size_t);

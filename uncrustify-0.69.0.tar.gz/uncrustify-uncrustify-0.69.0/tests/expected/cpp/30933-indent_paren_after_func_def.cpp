class SomeClass ()
{
public:
void SomeFunction
        (
        int const aTest,
        int const aResult
        )
{
	DoSomeStuff();
}
}
/*
	FreeRTOS.org V4.7.0 - Copyright (C) 2003-2007 Richard Barry.
	TriCore port - written by Adriaan Schmidt, Copyright (C) 2008 Siemens AG.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	The TriCore port is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	version 2 as published by the Free Software Foundation.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license
	and contact details.  Please ensure to read the configuration and relevant
	port sections of the online documentation.

	Also see http://www.SafeRTOS.com a version that has been certified for use
	in safety critical systems, plus commercial licensing, development and
	support options.
	***************************************************************************
*/

/* TriCore includes */
#include <tc1796b/ebu_lmb4.h>
#include <tc1796b/scu.h>
#include <tc1796b/pmi.h>

/* FreeRTOS configuration */
#include "FreeRTOSConfig.h"
#include "board_setup.h"

const unsigned long __board_init_table [] = {
	PLL_CLC_ADDR,		  PLL_CLC_VALUE,

#ifdef INIT_EBU
	EBU_ADDRSEL0_ADDR,	  EBU_ADDRSEL0_VALUE,
	EBU_BUSCON0_ADDR,	  EBU_BUSCON0_VALUE,
	EBU_BUSAP0_ADDR,	  EBU_BUSAP0_VALUE,
	EBU_ADDRSEL1_ADDR,	  EBU_ADDRSEL1_VALUE,
	EBU_BUSCON1_ADDR,	  EBU_BUSCON1_VALUE,
	EBU_BUSAP1_ADDR,	  EBU_BUSAP1_VALUE,
	EBU_ADDRSEL2_ADDR,	  EBU_ADDRSEL2_VALUE,
	EBU_BUSCON2_ADDR,	  EBU_BUSCON2_VALUE,
	EBU_BUSAP2_ADDR,	  EBU_BUSAP2_VALUE,
	EBU_ADDRSEL3_ADDR,	  EBU_ADDRSEL3_VALUE,
	EBU_BUSCON3_ADDR,	  EBU_BUSCON3_VALUE,
	EBU_BUSAP3_ADDR,	  EBU_BUSAP3_VALUE,
	EBU_CON_ADDR,		  EBU_CON_VALUE,
	EBU_BFCON_ADDR,		  EBU_BFCON_VALUE,
#endif

	PMI_CON0_ADDR,		  PMI_CON0_VALUE,

/* end of table marker: */
	0,					  0
};


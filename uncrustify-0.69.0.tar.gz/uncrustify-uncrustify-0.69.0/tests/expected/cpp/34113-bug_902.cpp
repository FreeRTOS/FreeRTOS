// unc_add_option("sp_cond_colon", UO_sp_cond_colon, AT_IARF,
//                "Add or remove space around the ':' in 'b ? t : f'");
// unc_add_option("sp_cond_question", UO_sp_cond_question, AT_IARF,
//                "Add or remove space around the '?' in 'b ? t : f'");
void detect_options(void)
{
	detect_space_options();
}

int i = 0;
//a
void a(){
	return 0;
}

//0
/*b*/
void b(){
	return 0;
}

/*0*/
//c
void c(){
	return 0;
}
//d
//d
//d
void d(){
	return 0;
}

//0
//h
//h
void h(){
	return 0;
}

/*0*/
/*e*/
void e(){
	return 0;
}
void f(){
	return 0;
}

int i = 0;
void g(){
	return 0;
}
void i(){
	return 0;
}
void j(){
	return 0;
}
void k(){
	return 0;
}

//0
void l(){
	return 0;
}

/*
 * 0
 */
void m(){
	return 0;
}
/*
 * n
 * n
 * n
 */
void n(){
	return 0;
}

static void h()
{
   typedef int IntGroup;
}

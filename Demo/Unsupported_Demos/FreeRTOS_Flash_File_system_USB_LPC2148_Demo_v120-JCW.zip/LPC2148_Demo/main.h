#ifndef _MAIN_H_
#define _MAIN_H_

//
//
//
#define __VERSION "1.20"

//
//
//
typedef enum
{
  TASKHANDLE_GPS = 0,
  TASKHANDLE_SENSORS,
  TASKHANDLE_MONITOR,
  TASKHANDLE_LED,
  TASKHANDLE_LAST
}
taskHandle_e;

extern xTaskHandle taskHandles [TASKHANDLE_LAST];

#endif

/*
FreeRTOS.org V4.1.2 - Copyright (C) 2003-2006 Richard Barry.

This file is part of the FreeRTOS.org distribution.

FreeRTOS.org is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FreeRTOS.org is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FreeRTOS.org; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

A special exception to the GPL can be applied should you wish to distribute
a combined work that includes FreeRTOS.org, without being obliged to provide
the source code for any proprietary components.  See the licensing section 
of http://www.FreeRTOS.org for full details of how and when the exception
can be applied.

***************************************************************************
See http://www.FreeRTOS.org for documentation, latest information, license 
and contact details.  Please ensure to read the configuration and relevant 
port sections of the online documentation.
***************************************************************************
*/

/*
Changes from V2.4.0

+ Made serial ISR handling more complete and robust.

Changes from V2.4.1

+ Split serial.c into serial.c and serialISR.c.  serial.c can be 
compiled using ARM or THUMB modes.  serialISR.c must always be
compiled in ARM mode.
+ Another small change to cSerialPutChar().

Changed from V2.5.1

+ In cSerialPutChar() an extra check is made to ensure the post to
the queue was successful if then attempting to retrieve the posted
character.

*/

/* 
BASIC INTERRUPT DRIVEN SERIAL PORT DRIVER FOR UART0. 

This file contains all the serial port components that can be compiled to
either ARM or THUMB mode.  Components that must be compiled to ARM mode are
contained in serialISR.c.
*/

/* Standard includes. */
#include <stdlib.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

/* Demo application includes. */
#include "serial.h"
#include "serialISR.h"

/*-----------------------------------------------------------*/

/* Location of the COM0 registers. */
#define serCOM0                   ( ( AT91PS_USART ) AT91C_BASE_US0 )

/* Interrupt control macros. */
#define serINTERRUPT_LEVEL        ( 5 )

/* Misc constants. */
#define serINVALID_QUEUE          ( ( xQueueHandle ) 0 )
#define serHANDLE                 ( ( xComPortHandle ) 1 )
#define serNO_BLOCK               ( ( portTickType ) 0 )

/*-----------------------------------------------------------*/

/* Queues used to hold received characters, and characters waiting to be
transmitted. */
static xQueueHandle xRxedChars; 
static xQueueHandle xCharsForTx; 

/*-----------------------------------------------------------*/

xComPortHandle xSerialPortInitMinimal( unsigned portLONG ulWantedBaud,
                                       unsigned portBASE_TYPE uxQueueLength )
{
  unsigned portLONG ulSpeed;
  xComPortHandle xReturn = serHANDLE;

  /* The queues are used in the serial ISR routine, so are created from
  serialISR.c (which is always compiled to ARM mode. */
  vSerialISRCreateQueues( uxQueueLength, &xRxedChars, &xCharsForTx );

  if ( ( xRxedChars != serINVALID_QUEUE ) && 
       ( xCharsForTx != serINVALID_QUEUE ) && 
       ( ulWantedBaud != ( unsigned portLONG ) 0 ) )
    {
    portENTER_CRITICAL();
      {
      /* Enable the USART clock. */
      AT91C_BASE_PMC->PMC_PCER = 1 << AT91C_ID_US0;

      // Disable interrupts
      serCOM0->US_IDR = 0xFFFFFFFF;

      /* Reset various status bits (just in case)... */
      serCOM0->US_CR = AT91C_US_RSTSTA;

      // Enable RXD & TXD pins
      AT91C_BASE_PIOB->PIO_ASR = ( ( unsigned portLONG ) AT91C_PB5_RXD0 ) |
                                 ( ( unsigned portLONG ) AT91C_PB4_TXD0 );
      AT91C_BASE_PIOB->PIO_PDR = ( ( unsigned portLONG ) AT91C_PB5_RXD0 ) |
                                 ( ( unsigned portLONG ) AT91C_PB4_TXD0 );

      // Reset receiver and transmitter
      serCOM0->US_CR = AT91C_US_RSTRX | AT91C_US_RSTTX | AT91C_US_RXDIS | AT91C_US_TXDIS ;

      // Define the baud rate divisor register
      ulSpeed = ((configCPU_CLOCK_HZ * 10) / (ulWantedBaud * 16));

      if ((ulSpeed % 10) >= 5)
        ulSpeed = (ulSpeed / 10) + 1;
      else
        ulSpeed /= 10;

      serCOM0->US_BRGR = ulSpeed;

      /* Write the Timeguard Register */
      serCOM0->US_TTGR = 0;

      // Define the USART mode
      serCOM0->US_MR = (AT91C_US_CHRL_8_BITS | AT91C_US_PAR_NONE);

      /* Enable Rx and Tx. */
      serCOM0->US_CR = AT91C_US_RXEN | AT91C_US_TXEN;

      /* Enable the Rx interrupts.  The Tx interrupts are not enabled
       * until there are characters to be transmitted. */
      serCOM0->US_IER = AT91C_US_RXRDY;

      /* Enable the interrupts in the AIC. */
      // Disable the interrupt on the interrupt controller
      AT91C_BASE_AIC->AIC_IDCR = 0x1 << AT91C_ID_US0 ;
      
      // Save the interrupt handler routine pointer and the interrupt priority
      AT91C_BASE_AIC->AIC_SVR[AT91C_ID_US0] = (unsigned int) vUART_ISR ;
      
      // Store the Source Mode Register
      AT91C_BASE_AIC->AIC_SMR[AT91C_ID_US0] = AT91C_AIC_SRCTYPE_INT_LEVEL_SENSITIVE | serINTERRUPT_LEVEL  ;
      
      // Clear the interrupt on the interrupt controller
      AT91C_BASE_AIC->AIC_ICCR = 0x1 << AT91C_ID_US0 ;
      
      // Enable the interrupt on the interrupt controller
      AT91C_BASE_AIC->AIC_IECR = 0x1 << AT91C_ID_US0 ;
      }
    portEXIT_CRITICAL();
    }
  else
    {
    xReturn = ( xComPortHandle ) 0;
    }

  /* This demo file only supports a single port but we have to return 
  something to comply with the standard demo header file. */
  return xReturn;
}
/*-----------------------------------------------------------*/

signed portBASE_TYPE xSerialGetChar( xComPortHandle pxPort,
                                     signed portCHAR *pcRxedChar,
                                     portTickType xBlockTime )
{
  /* The port handle is not required as this driver only supports one port. */
  ( void ) pxPort;

  /* Get the next character from the buffer.  Return false if no characters
  are available, or arrive before xBlockTime expires. */
  if ( xQueueReceive( xRxedChars, pcRxedChar, xBlockTime ) )
    return pdTRUE;

  return pdFALSE;
}
/*-----------------------------------------------------------*/

void vSerialPutString( xComPortHandle pxPort,
                       const signed portCHAR * const pcString,
                       unsigned portSHORT usStringLength )
{
  signed portCHAR *pxNext;

  /* NOTE: This implementation does not handle the queue being full as no
  block time is used! */

  /* The port handle is not required as this driver only supports UART0. */
  ( void ) pxPort;
  ( void ) usStringLength;

  /* Send each character in the string, one at a time. */
  pxNext = ( signed portCHAR * ) pcString;

  while ( *pxNext )
    {
    xSerialPutChar( pxPort, *pxNext, serNO_BLOCK );
    pxNext++;
    }
}
/*-----------------------------------------------------------*/

signed portBASE_TYPE xSerialPutChar( xComPortHandle pxPort,
                                     signed portCHAR cOutChar,
                                     portTickType xBlockTime )
{
  ( void ) pxPort;

  /* Place the character in the queue of characters to be transmitted. */
  if( xQueueSend( xCharsForTx, &cOutChar, xBlockTime ) != pdPASS )
    {
    return pdFAIL;
    }

  /* Turn on the Tx interrupt so the ISR will remove the character from the
  queue and send it.   This does not need to be in a critical section as
  if the interrupt has already removed the character the next interrupt
  will simply turn off the Tx interrupt again. */
  serCOM0->US_IER = AT91C_US_TXRDY;

  return pdPASS;
}
/*-----------------------------------------------------------*/

void vSerialClose( xComPortHandle xPort )
{
  /* Not supported as not required by the demo application. */
  ( void ) xPort;
}
/*-----------------------------------------------------------*/







Foo^ foo = dynamic_cast<Bar^>(bar);
Foo* foo = dynamic_cast<Bar*>(bar);
x = a ^ b;

int main(Platform::Array<Platform::String^>^ /*args*/)
{
}

Platform::Array<unsigned char>^ a;

int a ()
{
  double a_very_long_variable = test (foobar1,
       foobar5);
//3456789=123456789=123456789=123456789=

  double a_other_very_long = asdfasdfasdfasdfasdf + asdfasfafasdfa +
       asdfasdfasdf - asdfasdf + 56598;
//3456789=123456789=123456789=123456789=

  a_other_very_long = asdfasdfasdfasdfasdf + asdfasfafasdfa +
       asdfasdfasdf - asdfasdf + 56598;
//3456789=123456789=123456789=123456789=

  testadsfa (dfasdf,
       aaafsdfa);
//3456789=123456789=123456789=123456789=

  return 0;
}

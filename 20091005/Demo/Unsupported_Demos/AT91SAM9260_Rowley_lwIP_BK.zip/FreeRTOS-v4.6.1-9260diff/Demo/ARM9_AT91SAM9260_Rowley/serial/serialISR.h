#ifndef INC_SERIAL_ISR_H
#define INC_SERIAL_ISR_H

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "queue.h"

#include "board.h"

// The AT91SAM9260 has a max of 6 USARTs
#define MAX_USARTS 6

typedef struct
{ 
  AT91PS_USART pUsart;

  /* Read/Write buffers. */
  xQueueHandle xRxedChars; 
  xQueueHandle xCharsForTx;
} xComPort;


extern xComPort xPortStatus[ MAX_USARTS ];
void USART_ISR( xComPort *pComPort );

#if (!defined(USART0) && !defined(USART1) && !defined(USART2) && !defined(USART3) && !defined(USART4) && !defined(USART5))
#error At least one USART must be enabled in Board.h
#endif

#ifdef USART0
void vUSART0_ISR( void ) __attribute__ ((naked));
#endif

#ifdef USART1
void vUSART1_ISR( void ) __attribute__ ((naked));
#endif

#ifdef USART2
void vUSART2_ISR( void ) __attribute__ ((naked));
#endif

#ifdef USART3
void vUSART3_ISR( void ) __attribute__ ((naked));
#endif

#ifdef USART4
void vUSART4_ISR( void ) __attribute__ ((naked));
#endif

#ifdef USART5
void vUSART5_ISR( void ) __attribute__ ((naked));
#endif

#endif

namespace
{

int f = 0;

}

void g(int a1234567890123456, int b1234567890123456,
       int c1234567890123456)
{
}

/*
	FreeRTOS.org V4.1.3 - Copyright (C) 2003-2006 Richard Barry.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section 
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license 
	and contact details.  Please ensure to read the configuration and relevant 
	port sections of the online documentation.
	***************************************************************************
*/

/*
 * Creates all the demo application tasks, then starts the scheduler.  The WEB
 * documentation provides more details of the demo application tasks.
 * 
 * This demo is configured to execute on the ES449 prototyping board from
 * SoftBaugh. The ES449 has a built in LCD display and a single built in user
 * LED.  Therefore, in place of flashing an LED, the 'flash' and 'check' tasks
 * toggle '*' characters on the LCD.  The left most '*' represents LED 0, the
 * next LED 1, etc.
 *
 * Main. c also creates a task called 'Check'.  This only executes every three 
 * seconds but has the highest priority so is guaranteed to get processor time.  
 * Its main function is to check that all the other tasks are still operational.  
 * Each task that does not flash an LED maintains a unique count that is 
 * incremented each time the task successfully completes its function.  Should 
 * any error occur within such a task the count is permanently halted.  The 
 * 'check' task inspects the count of each task to ensure it has changed since
 * the last time the check task executed.  If all the count variables have 
 * changed all the tasks are still executing error free, and the check task
 * toggles an LED with a three second period.  Should any task contain an error 
 * at any time the LED toggle rate will increase to 500ms.
 *
 * Please read the documentation for the Blackfin port available on
 * http://www.FreeRTOS.org.
 */

/* Standard includes. */
#include <stdlib.h>
#include <stdio.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"

#include <cdefBF537.h>
#include <sys/exception.h>

/*-----------------------------------------------------------*/

void prvSetupTimerInterrupt( void )
{
    int scale = 134;
    int counter = 300;
    
    *pTCNTL   = 1;                                   // Turn on timer, TMPWR
	*pTSCALE  = scale;                               // Load scale
	*pTCOUNT  = counter;                             // Load counter
	*pTPERIOD = counter;                             // Load counter into period as well
	register_handler_ex (ik_timer,                   // Register Timer ISR and enable
	               	(ex_handler_fn )vTickISR, EX_INT_ENABLE);  // IVG6 (Timer)
    /* Interrupts are disabled when this is called so the timer can be started
	here. */
	*pTCNTL   = 0x7;                                 // Start Timer and set Auto-reload
}




/*
***************************************************************************
*
*	  Main program function
*
***************************************************************************
*/
static portTASK_FUNCTION( vUserTask1, pvParameters )
{
    int i = 0;
	for(;;) {
		printf("in Task1\n");
		taskYIELD();
		i++;
		if (i > 10000) {
		    printf("\n");
			i = 0;
		}
	}
}

extern portTASK_FUNCTION( shell, pvParameters );

void main(void)
{
	printf("FreeRTOS shell demo on BF533\n");
	xTaskCreate( shell, "UsrTsk2", 1000, NULL, 1, ( xTaskHandle * ) NULL);
	vTaskStartScheduler();
}// end of main


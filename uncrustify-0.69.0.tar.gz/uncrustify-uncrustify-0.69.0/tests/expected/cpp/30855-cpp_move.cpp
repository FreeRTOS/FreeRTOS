
void Test(X&& val1, Y* val2);

/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief FreeRTOS port header for IAR M16C
 *
 * \author 2008, Felix Daners Engineering. f.daners@swissworld.com
 *
 * Interupts use ISTACK
 * Tasks use User Stack, Task stack needs no room for interrupt handler
 *****************************************************************************/


#ifndef PORTMACRO_H
#define PORTMACRO_H

#ifndef __IAR_SYSTEMS_ASM__
  /* IO definitions for the chosen device. */
  #include <iom16c62p.h>
  #if __VER__ > 300
    #include <intrinsics.h>
  #else
    #include <intrm16c.h>
  #endif
#endif

#ifdef __cplusplus
extern "C" {
#endif


/* Type definitions. */
#define portCHAR        char
#define portFLOAT       float
#define portDOUBLE      double
#define portLONG        long
#define portSHORT       short
#define portSTACK_TYPE  unsigned portSHORT
#define portBASE_TYPE   portSHORT
#define portFLAG_TYPE   unsigned portSHORT

#define TASK_DELAY_MS(x)   ( (x)        /portTICK_RATE_MS )
#define TASK_DELAY_S(x)    ( (x)*1000   /portTICK_RATE_MS )
#define TASK_DELAY_MIN(x)  ( (x)*60*1000/portTICK_RATE_MS )

#ifndef __IAR_SYSTEMS_ASM__
  #if ( configUSE_16_BIT_TICKS == 1 )
    typedef unsigned portSHORT portTickType;
	#define portMAX_DELAY ( portTickType ) 0xffff
  #else
    typedef unsigned portLONG portTickType;
	#define portMAX_DELAY ( portTickType ) 0xffffffff
  #endif
#endif
/*-----------------------------------------------------------*/

/* Architecture specifics. */
#define portSTACK_GROWTH      ( -1 )
#define portTICK_RATE_MS      ( ( portTickType ) 1000 / configTICK_RATE_HZ )
#define portBYTE_ALIGNMENT       1
#define portNOP()             {__no_operation();}
#define portYIELD_VECTOR      1
#ifndef __IAR_SYSTEMS_ASM__
#pragma inline=forced
  static portBASE_TYPE portSetInterruptMaskFromISR(void)
  {
    portBASE_TYPE r = __get_interrupt_level();
    __set_interrupt_level(configMAX_SYSCALL_INTERRUPT_PRIORITY);
    return r;
  }
#endif
#define portSET_INTERRUPT_MASK_FROM_ISR() portSetInterruptMaskFromISR()
#define portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedStatusRegister ) \
{ \
  __set_interrupt_level((unsigned char)uxSavedStatusRegister);\
}

/*-----------------------------------------------------------*/

/* Task utilities. */
/*-----------------------------------------------------------*/	



/* Critical section management. */
#define portDISABLE_INTERRUPTS()  {__set_interrupt_level(configMAX_SYSCALL_INTERRUPT_PRIORITY);}
#define portENABLE_INTERRUPTS()   {__set_interrupt_level(configKERNEL_INTERRUPT_PRIORITY);}

/* be careful, the current state is stored on the stack! */
/* when use, make sure to have matching ENTER/LEAVE pairs that */
/* do not mess up the stack. DO NOT: */
/* portENTER_CRITICAL(); */
/* { int test;  // allocated on the stack! */
/*   portEXIT_CRITICAL(); */
/*   return;  */
/* } */

#define portENTER_CRITICAL() \
{ \
  { \
    asm("PUSHC FLG");\
    __set_interrupt_level(configMAX_SYSCALL_INTERRUPT_PRIORITY);\
}
#define  portEXIT_CRITICAL() \
{ \
    asm("POPC FLG");\
  } \
}

/*-----------------------------------------------------------*/


/*=============================================================================================*/


/* this is non maskable! always yields even if I flag cleared */
#define portYIELD()                 {__software_interrupt(portYIELD_VECTOR);}


/* Defines the prototype to which task functions must conform. */
#ifndef __IAR_SYSTEMS_ASM__
  typedef void __data20 * pdTASK_PARAM;
  typedef void (__task __simple *pdTASK_CODE)( pdTASK_PARAM );
  typedef portBASE_TYPE __data16 * pdISR_PARAM;
#endif

/* Task function macros as described on the FreeRTOS.org WEB site. 
 * neither task nor user interrupts need to save context ant entry.
 * this is done by entry exit code in asm_func.s34 */
#define portTASK_FUNCTION_PROTO( vFunction, pvParameters ) __task __simple void  vFunction( pdTASK_PARAM pvParameters )
#define portTASK_FUNCTION( vFunction, pvParameters )  __task __simple void  vFunction( pdTASK_PARAM pvParameters )
#define portINTERRUPT_HANDLER_PROTO(isrFunction) __task __simple void isrFunction ( pdISR_PARAM pxSwitchRequired__ )
#define portINTERRUPT_HANDLER(isrFunction) __task __simple void isrFunction ( pdISR_PARAM pxSwitchRequired__ )

#define portEND_SWITCHING_ISR( xSwitchRequired ) if (1) {(*pxSwitchRequired__) |= xSwitchRequired;} else ((void)0)

#pragma diag_suppress=Pa082


#define memcpy intrinsic_memcpy
#define intrinsic_memcpy(d,s,l) __SMOVF_B((char __data16 *) (d), (const char __far*) (s), (l))

#define memset intrinsic_memset
#define intrinsic_memset(d,v,l) __SSTR_B((char __data16 *) (d), (signed char)(v), (l))

#define memmove intrinsic_memmove
#define intrinsic_memmove(d,s,l) \
   if ((d) > (s) ) { \
    __SMOVB_B((char __data16 *) (d) + (l), (const char __far*) (s) + l, (l)); \
   } else { \
    __SMOVF_B((char __data16 *) (d), (const char __far*) (s), (l)); \
   } 


#ifdef __cplusplus
}
#endif

#endif /* PORTMACRO_H */

0B8h
__asm
{
	mov al, 0B8h
	mov al, 2
	mov dx, 0xD007
	out dx, al
}

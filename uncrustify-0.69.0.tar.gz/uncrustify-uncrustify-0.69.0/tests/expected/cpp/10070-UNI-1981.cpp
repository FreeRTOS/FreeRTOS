#if DOXYGEN
class Class
#else
struct Struct
#endif
{
    UInt32  m_myAwesomeMember1          : kEnumValue
    UInt32  m_myAwesomeMember11         : kEnumValue
    UInt32  m_myAwesomeMember111        : 1;
    UInt32  m_myAwesomeMember1111       : 1;
    UInt32  m_myAwesomeMember11111      : 1;
    UInt32  m_myAwesomeMember111111     : 1;
    UInt32  m_myAwesomeMember1111111    : 1;
    UInt32  m_myAwesomeMember11111111   : kEnumValue
    UInt32  m_myAwesomeMember11111111   : kEnumValue
};

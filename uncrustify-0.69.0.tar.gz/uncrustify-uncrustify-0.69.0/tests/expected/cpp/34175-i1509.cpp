void f()
{
	int i  = A::B::C::bar();
	int ii = A::B::C::bar();
}
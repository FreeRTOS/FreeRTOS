int foo()
   {
   const std::map<std::string, int> bar =
      {
         { "abcXYZ", -13 },
      };
   return 5;
   }

/******************************************************************************
 *
 * Example Program       for R32C/111     FreeRTOS
 *
 * author                f.daners@swissworld.com
 *                       Felix Daners Engineering
 *                       Speerstrasse 32
 *                       8200 Schaffhausen
 *                       Switzerland
 *
 * platform              This program runs on
 *                       EVBR32C111-Carrier-USB
 *                       by Glyn GmbH & Co KG, Microcontroller Group
 *                       Distribution:
 *                       Elektor-Verlag GmbH
 *                       Systerfeldstrasse 25
 *                       52072 Aachen
 *                       Product: R32C/111-Starterkit (080928-91)
 *
 *                       Connect USB to PC, run terminal emulation
 *                       set to 9600,8N1 on that port.
 *
 *****************************************************************************
 *
 * !!! THIS FILE IS LICENSED SEPARATELY FROM FREERTOS !!!
 *
 * Copyright (c) 2009, Felix Daners Engineering, Switzerland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * - Neither the name of the Felix Daners Engineering nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************/
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <ior32c111.h>
#include <uart_rtos.h>

#define TIMER_B1_INTERVAL_ms 10ul
#define TIMER_B1_INT_LEVEL   2
portINTERRUPT_HANDLER_PROTO(timer_B1_isr);
static void timer_B1_install(void);
static void timer_B1_uninstall(void);
xQueueHandle aQueue;

/* create an instance of uart functions for UART 1 */
#define UART 1
#define fx_brg_24000000
#define uXbrg_val uXbrg_9600
#define tx_fifo_size_val 16
#define rx_fifo_size_val 32
#define s1ric_val 0x3
#define s1tic_val 0x2
#define uXc0_val   uXc0_clk_f1 \
                 | uXc0_crd_cts_disabled \
                 | uXc0_nch_push_pull \
                 | uXc0_uform_lsb_first
#include <uart_rtos.h>
#undef UART

#if defined(HEW_SIMULATOR)
#define outchar_uart_1(a)
#define putchar_uart_1(a,b)
#endif

/* blink the little LED on the board */
static portTASK_FUNCTION_PROTO(blink_task, null);

/* receive messages from a peripherial interrupt */
static portTASK_FUNCTION_PROTO(int_bh_task, null);

/* handle the serial interface, at 9600 Baud, 8N1 */
static portTASK_FUNCTION_PROTO(com_task, null);
/* function that gets called on BREAK condition for UART 1 */
/* this function is called from interrupt context ! */
/* use xQueueSendToBackFromISR to post a message to a task */
static void uart_1_break_handler(portBASE_TYPE *pxHigherPriorityTaskWoken);


/* create the tasks, start the scheduler */
void main( void )
{

restart:
    xTaskCreate(  blink_task,
                  "blink_task",
                  0x20,
                  0,
                  tskIDLE_PRIORITY+1,0 );

    xTaskCreate(  int_bh_task,
                  "other_task",
                  0x20,
                  0,
                  tskIDLE_PRIORITY+1,0 );

    xTaskCreate(  com_task,
                  "com_task",
                  0x20,
                  0,
                  tskIDLE_PRIORITY+1,0 );

    aQueue =  xQueueCreate( 8, sizeof(char));

    /* register the break condition handler with the init function */
    init_uart_1(uart_1_break_handler);

    timer_B1_install();

    pd3_0 = 1;
    pd3_1 = 1;
    pd3_2 = 1;

    vTaskStartScheduler();

    /* we come here if the scheduler is stopped */

    {
       char *s = "\r\nScheduler stopped, will restart if heap clean!\r\n";
       while (*s)
       {
           outchar_uart_1(*s);
           s++;
       }
       pd3_0 = 1;
       p3_0 = 0;
    }

    /* now do cleanup */

    timer_B1_uninstall();

    uninit_uart_1();

    vQueueDelete( aQueue );

    vTaskCleanUpResources();

    pd3_0 = 0;
    pd3_1 = 0;
    pd3_2 = 0;

    /* check if all memory got freed */
    extern int GetNumObjectsOnHeap( void );
    if (GetNumObjectsOnHeap()==0)
    {
      goto restart;
    }

    while(1); // wait for reset
}


static void stop(void)
{
    vTaskDelay(100);

    vTaskEndScheduler();

    /* never come here, but program returns form
       vTaskStartScheduler */
}


portTASK_FUNCTION(blink_task,null)
{
    portTickType xLastWakeTime;

    taskENTER_CRITICAL();


    taskEXIT_CRITICAL();

    while(1)
    {
        vTaskDelayUntil( &xLastWakeTime, 500 / portTICK_RATE_MS);
        p3_0 = ! p3_0;
    }
}


/* function that gets called on BREAK condition for UART 1 */
/* this function is called from interrupt context ! */
/* use xQueueSendToBackFromISR to post a message to a task */
static void uart_1_break_handler(portBASE_TYPE *pxHigherPriorityTaskWoken)
{
    char *s = "\r\nBREAK\r\n";
    while (*s)
    {
        outchar_uart_1(*s);
        s++;
    }
}




portTASK_FUNCTION(com_task,null)
{
    uart_rtos_rx_message_t rx;
    char *s = "\r\nHELLO, COM TASK RUNNING: Press !q to stop scheduler!\r\n";
    char state = 0;


    while (*s)
    {
        putchar_uart_1(*s, 2000 / portTICK_RATE_MS);
        s++;
    }

    while(1)
    {
        rx.R = getmessage_uart_1(2000 / portTICK_RATE_MS);
        if (!rx.B.err_sum)
        {
            putchar_uart_1(rx.B.data_bits_0_7, 10 / portTICK_RATE_MS);
            if ((state == '!') && (rx.B.data_bits_0_7 == 'q'))
            {
                stop();
            }
            else
            {
                state = rx.B.data_bits_0_7;
            }
        }
        else
        {
            state = 0;
            putchar_uart_1('.', 10 / portTICK_RATE_MS);
        }
    }
}


portTASK_FUNCTION(int_bh_task,null)
{
    while(1)
    {
        char m;
        if (xQueueReceive(aQueue, (void*)&m, 250 / portTICK_RATE_MS ))
        {
            p3_1 = ! p3_1;
            #if defined(HEW_SIMULATOR)
               stop();
            #endif
        }
    }
}


portINTERRUPT_HANDLER( timer_B1_isr )
{
    portBASE_TYPE xHigherPriorityTaskWoken = 0;
    if (xQueueSendFromISR(aQueue,0, &xHigherPriorityTaskWoken  ))
    {
      p3_2 = ! p3_2;
    }
    portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);
}



/* This routine setups timer B1 and clears timer flag */
static void timer_B1_install(void)
{
  /* this function is called before interrupts are enabled */
  tb1s=0;
  tb1mr = 0x40;     // XXXX XXXX
                    // |||| ||++- operation mode: 00: timer 01: event counter 10:one shot timer 11: PWM
                    // |||| |+--- pulse output at pin TA4out 0: OFF 1: ON
                    // |||| +---- gate function: 0: timer counts only when TA0in is "L", 1: .. is "H"
                    // |||+------ gate function  0: not available 1: available
                    // ||+------- must always be 0 in timer mode
                    // ++-------- count source select bits: 00:f1  01:f8  10:f2n 11:fc32

  tb1 = (TIMER_B1_INTERVAL_ms*24000ul/8ul-1ul);
  tb1ic = TIMER_B1_INT_LEVEL;// interrupt priority level select bit 0...7
  tb1s=1;
}


static void timer_B1_uninstall(void)
{
  tb1ic = 0;
  tb1s=0;
}




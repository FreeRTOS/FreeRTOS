/*
 FreeRTOS.org V5.1.0 - Copyright (C) 2003-2008 Richard Barry.

 This file is part of the FreeRTOS.org distribution.

 FreeRTOS.org is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 FreeRTOS.org is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with FreeRTOS.org; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 A special exception to the GPL can be applied should you wish to distribute
 a combined work that includes FreeRTOS.org, without being obliged to provide
 the source code for any proprietary components.  See the licensing section
 of http://www.FreeRTOS.org for full details of how and when the exception
 can be applied.

 ***************************************************************************
 ***************************************************************************
 *                                                                         *
 * SAVE TIME AND MONEY!  We can port FreeRTOS.org to your own hardware,    *
 * and even write all or part of your application on your behalf.          *
 * See http://www.OpenRTOS.com for details of the services we provide to   *
 * expedite your project.                                                  *
 *                                                                         *
 ***************************************************************************
 ***************************************************************************

 Please ensure to read the configuration and relevant port sections of the
 online documentation.

 http://www.FreeRTOS.org - Documentation, latest information, license and
 contact details.

 http://www.SafeRTOS.com - A version that is certified for use in safety
 critical systems.

 http://www.OpenRTOS.com - Commercial support, development, porting,
 licensing and training services.
 */

/*
 Changes from V1.2.5

 +  Clear overrun errors in the Rx ISR.  Overrun errors prevent any further
 characters being received.

 Changes from V2.0.0

 + Use portTickType in place of unsigned pdLONG for delay periods.
 + cQueueReieveFromISR() used in place of xQueueReceive() in ISR.


 Changes for this instance of serial.c only

 + Register reads and writes were changed to allow communication over USART2.

 + The baud rate calculation was changed to "SPBRG = ( (FOSC / Desired Baud Rate) / 4 )".

 + In the function called "xSerialGetChar", the call to "xQueueReceive" was replaced with
 a call to "xQueueReceiveFromISR".  This was necessary in order to prevent erratic behavior
 and time constraints presently rule against an effort to identify the specific underlying
 reasons and possible alternate solutions.

 + Removal of pragma directives before vSerialRxISR and vSerialTxISR, as these are handled in port.c .

 */

/* Description                                                                                          */
/*                                                                                                      */
/* This module provides serial communication to the VEX Micro Controller by way of the TX and RX ports, */
/* which are located in the "ANALOG / DIGITAL" group of ports.                                          */
/*                                                                                                      */
/* The RX and TX ports operate at 5 volt, traditional "TTL" logic levels.  Thus, any interfacing to an  */
/* RS-232 device MUST be done with appropriate serial interface hardware.                               */

/* Each of these ports, as well as all others on the top of the controller, have three contacts and are */
/* designed to work with the type of connectors used in hobby radio-control systems.                    */

/* Includes                                                                                             */

#include "FreeRTOS.h"
#include "task.h"
#include "serial.h"
#include "queue.h"

/*  Prototypes for ISR's.  These ISRs are called have to be called from port.c. 						*/

void vSerialTxISR( void );
void vSerialRxISR( void );

/*  Hardware pin definitions. 																			*/

#define serTX_PIN	TRISGbits.TRISG1
#define serRX_PIN	TRISGbits.TRISG2

/* 	Bit/register definitions. 																			*/

#define serINPUT				( 1 )
#define serOUTPUT				( 0 )
#define serTX_ENABLE			( ( unsigned portSHORT ) 1 )
#define serRX_ENABLE			( ( unsigned portSHORT ) 1 )
#define serHIGH_SPEED			( ( unsigned portSHORT ) 1 )
#define serCONTINUOUS_RX		( ( unsigned portSHORT ) 1 )
#define serCLEAR_OVERRUN		( ( unsigned portSHORT ) 0 )
#define serINTERRUPT_ENABLED 	( ( unsigned portSHORT ) 1 )
#define serINTERRUPT_DISABLED 	( ( unsigned portSHORT ) 0 )

/*  All ISR's use the PIC18 low priority interrupt. 												    */

#define							serLOW_PRIORITY ( 0 )

/*  Queues that provide interface between communications API and interrupt routines.                    */

static xQueueHandle xCharsForRxQueueHandle;

static xQueueHandle xCharsForTxQueueHandle;


xComPortHandle xSerialPortInitMinimal( unsigned portLONG ulWantedBaud, unsigned portBASE_TYPE uxQueueLength )
{
	unsigned portLONG ulBaud;

	/* Calculate the baud rate generator constant.                                                     */
	/* SPBRG = ( (FOSC / Desired Baud Rate) / 4 )                                                      */

	ulBaud = configCPU_CLOCK_HZ / ulWantedBaud;
	ulBaud /= ( unsigned portLONG ) 4;

	/* Create the queues used by the ISR's to interface to tasks. 										*/

	xCharsForRxQueueHandle = xQueueCreate( uxQueueLength, ( unsigned portBASE_TYPE ) sizeof( portCHAR ) );

 	xCharsForTxQueueHandle = xQueueCreate( uxQueueLength, ( unsigned portBASE_TYPE ) sizeof( portCHAR ) );

	portENTER_CRITICAL();
	{
		/* Start with config registers cleared, so we can just set the wanted bits. 					*/

		TXSTA2 = ( unsigned portSHORT ) 0;
		RCSTA2 = ( unsigned portSHORT ) 0;

		/* Set the baud rate generator using the above calculated constant. 							*/

		SPBRG2 = ( unsigned portCHAR ) ulBaud;

		/* Setup the IO pins to enable the USART IO. 													*/

		serTX_PIN = serOUTPUT;
		serRX_PIN = serINPUT;

		/* Set the serial interrupts to use the same priority as the tick. 								*/

		IPR3bits.TX2IP = serLOW_PRIORITY;
		IPR3bits.RC2IP = serLOW_PRIORITY;

		/* Setup Tx configuration. 																		*/

		TXSTA2bits.BRGH = serHIGH_SPEED;
		TXSTA2bits.TXEN = serTX_ENABLE;

		/* Setup Rx configuration. 																		*/

		RCSTA2bits.SPEN = serRX_ENABLE;
		RCSTA2bits.CREN = serCONTINUOUS_RX;

		/* Enable the Rx interrupt now, the Tx interrupt will get enabled when we have data to send. 	*/

		PIE3bits.RC2IE = serINTERRUPT_ENABLED;
	}
	portEXIT_CRITICAL();

	return NULL;
}

portBASE_TYPE xSerialGetChar( xComPortHandle pxPort, signed portCHAR *pcRxedChar, portTickType xBlockTime )
{
	/* Get the next character from the buffer.  Return false if no characters are available, or arrive  */
	/* before xBlockTime expires.                                                                       */

	if( xQueueReceiveFromISR( xCharsForRxQueueHandle, pcRxedChar, xBlockTime ) )
	{
		return pdTRUE;
	}
	else
	{
		return pdFALSE;
	}
}

portBASE_TYPE xSerialPutChar( xComPortHandle pxPort, signed portCHAR cOutChar, portTickType xBlockTime )
{
	/* Return false if after the block time there is no room on the Tx queue. 							*/

	if( xQueueSend( xCharsForTxQueueHandle, ( const void * ) &cOutChar, xBlockTime ) != pdPASS )
	{
		return pdFAIL;
	}

	/* This apparently makes the TX interrupt fire right away because TXREG was already changed. 		*/

	PIE3bits.TX2IE = serINTERRUPT_ENABLED;

	return pdPASS;
}


//#pragma interruptlow vSerialRxISR save=PRODH, PRODL, TABLAT, section(".tmpdata")

void vSerialRxISR( void )
{
	portCHAR cChar;

	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;;

	/* Get the character and post it on the queue of Rxed characters.	If the post causes a task to 	*/
	/* wake force a context switch as the woken task may have a higher priority than the task we have 	*/
	/* interrupted. 																					*/

	cChar = RCREG2;

	/* Clear any overrun errors. 																		*/

	if( RCSTA2bits.OERR )
	{
		RCSTA2bits.CREN = serCLEAR_OVERRUN;
		RCSTA2bits.CREN = serCONTINUOUS_RX;
	}

	xQueueSendFromISR( xCharsForTxQueueHandle, ( const void * ) &cChar, &xHigherPriorityTaskWoken);

	if( xHigherPriorityTaskWoken )
	{
		taskYIELD();
	}
}

//#pragma interruptlow vSerialTxISR save=PRODH, PRODL, TABLAT, section(".tmpdata")

void vSerialTxISR( void )
{
	portCHAR cChar, cTaskWoken = pdFALSE;

	if( xQueueReceiveFromISR( xCharsForTxQueueHandle, &cChar, &cTaskWoken ) == pdTRUE )
	{
		/* Send the next character queued for Tx. 														*/

		TXREG2 = cChar;
	}
	else
	{
		/* Queue empty, nothing to send. 																*/

		PIE3bits.TX2IE = serINTERRUPT_DISABLED;
	}
}




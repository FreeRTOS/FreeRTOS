#include "FreeRTOS.h"

#include "adc.h"

//
//
//
int adcRead0_3 (void)
{
  AD0_CR |= AD_CR_START_NOW;

  while (!(AD0_DR3 & AD_DR_DONE))
    ;

  return ((AD0_DR3 & AD_DR_RESULTMASK) >> AD_DR_RESULTSHIFT);
}

//
//  Assumes PCLK == 48Mhz
//
void adcInit (void)
{
  SCB_PCONP |= SCB_PCONP_PCAD0;

  PCB_PINSEL1 |= PCB_PINSEL1_P030_AD03;

  AD0_CR = AD_CR_CLKS10 | AD_CR_PDN | ((11 - 1) << AD_CR_CLKDIVSHIFT) | AD_CR_SEL3;
}

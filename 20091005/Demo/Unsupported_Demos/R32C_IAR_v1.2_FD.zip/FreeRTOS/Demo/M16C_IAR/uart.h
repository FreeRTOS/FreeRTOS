//==============================================================================
// Copyright (c) by ndd Medizintechnik Zuerich, Switzerland.All rights reserved.
// -----------------------------------------------------------------------------
// Project: EasyOne
// Module :
// File   : UART.H
// Content: header for the sensor UART module
// -----------------------------------------------------------------------------
// RCS Version Information:
// $Source: /home/cvs/cvsroot/kunden/NDD_Medizintechnik/PictBridge/PictBridgeCradle/USBware/target/FreeRTOS/Demo/M16C_IAR/uart.h,v $
// $Revision: 1.1 $
// $Name:  $
// $Author: fd $
// $Date: 2008/08/04 17:21:41 $
//==============================================================================
#ifndef _UART_H
#define _UART_H

#define STX  0x02     // Ctrl-B command character
#define DLE  0x10     // data link escape character

#define BAUD_19200        0x1B
#define BAUD_57600        0x1D
#define BAUD_125000       0x1E

#define TAR_DATA16 __data16
#define TAR_DATA13 __data13


// receive errors
#define OVERRUN_ERROR     '1'
#define BUFFER_OVERRUN    '2'
#define INVALID_CHAR      '3'
//return values
#define NO_ERROR          '0'



static void SendByte(uint8_t byUart, uint8_t byData);
void SendCmd(uint8_t byUart, uint8_t byData);
void SendAscii(uint8_t byUart, uint8_t byData);
void SendString(uint8_t byUart, const char TAR_DATA16 *szString);
void SendBuffer(uint8_t byUart, uint8_t * pbyBuf, uint16_t wLength);

void ResetUartStates(void);
void ServiceTxQueue(void);
uint8_t IsTxQueueEmpty(uint8_t byUart);

void SetBaudRate(uint8_t byUart, uint8_t byBaud);
uint8_t GetBaudRate(uint8_t byUart);
uint8_t Rs232_Rx(uint8_t byUart, uint8_t TAR_DATA13 *byTemp);
void FlushRxQueue(uint8_t byUart);
void FlushTxQueue(uint8_t byUart);

void SetModemState(uint8_t byUart, uint8_t bModemOn);
void SetFlowCtrlState(uint8_t byUart, uint8_t bFlowCtrlOn);
void SetBinaryMode(uint8_t byUart, uint8_t bBinaryOn);
uint8_t CheckModemActive(uint8_t byUart);

void InitRS232(uint8_t byUart);

#endif

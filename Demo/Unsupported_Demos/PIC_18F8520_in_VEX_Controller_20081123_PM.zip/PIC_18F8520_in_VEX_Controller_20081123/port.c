/*  Copyright (C) 2008 Paul Murphy.                                                                     */
/*                                                                                                      */
/*  The author hereby grants permission to use, copy, modify, distribute, and license this software and */
/*  its documentation for any purpose, provided that existing copyright notices are retained in all     */
/*  copies and that this notice and the following disclaimer are included verbatim in any               */
/*  distributions.  No written agreement, license, or royalty fee is required for any of the authorized */
/*  uses.                                                                                               */
/*                                                                                                      */
/*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR *AS IS* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,   */
/*  BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  */
/*  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,       */
/*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF         */
/*  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER       */
/*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE */
/*  POSSIBILITY OF SUCH DAMAGE.                                                                         */
/*                                                                                                      */
/*                                                                                                      */
/*                                                                                                      */
/*  port.c for FreeRTOS versions V4.4.0 and V5.1.0 for the PIC 18F8250 Microcontroller                  */
/*                                                                                                      */
/*  in the VEX Robotics Design System Prototyping Kits.                                                 */
/*                                                                                                      */


/*  Includes                                                                                            */

#include "FreeRTOSConfig.h"
#include "ifi_picdefs.h"
#include "ifi_default.h"
#include "ifi_aliases.h"
#include "portmacro.h"
#include "projdefs.h"
#include "FreeRTOS.h"
#include "task.h"
#include <timers.h>


/*  System Related Defines                                                                              */

#define portBIT_SET     ( ( unsigned portCHAR ) 1 )

#define portBIT_CLEAR   ( ( unsigned portCHAR ) 0 )


/*  User Related Defines                                                                                */

#define portCOMPILER_MANAGED_MEMORY_SIZE    ( ( unsigned portCHAR ) 50 )


/*  Function and Interrupt Prototypes*/

static void    prvSetupTimerAndInterrupts(void);

static void    LowPriorityInterruptHandler (void);

static void    prvTimerZeroOverflowISR(void);

static void    prvTickISR( void );

/*  Declarations                                                                                        */

extern volatile void    * volatile pxCurrentTCB;

static unsigned char     ucBlockFSR0L, ucBlockFSR0H;

static unsigned char     pxStackFSR0L, pxStackFSR0H, ucBlockFSR0L, ucBlockFSR0H;

static unsigned char     tempFSR0L, tempFSR0H;

static unsigned char     holdFSR0L, holdFSR0H, holdFSR1L, holdFSR1H, holdFSR2L, holdFSR2H;

static unsigned char     holdSTATUS, holdWREG, holdSTKPTR;

void *pvParam;

volatile unsigned int uxCriticalNesting;


/*  portSAVE_CONTEXT                                                                                    */
/*                                                                                                      */
/*  The portSAVE_CONTEXT macro supports the capturing and saving of the state of the task that is       */
/*  running when the RTOS tick interrupt occurs or when the vPortYield function is called.              */
/*                                                                                                      */
/*  When either of these events takes place, portSAVE_CONTEXT populates the px stack with a copy of the */
/*  values in those registers and memory locations that the task was or could have been using at the    */
/*  time.  More specifically, the macro saves only those registers and memory that could be changed by  */
/*  other code before the task is subsequently resumed.                                                 */
/*                                                                                                      */
/*  When the portSAVE_CONTEXT macro is invoked, the status register, STATUS, the working register,      */
/*  WREG, and the indirect addressing registers FSR0, FSR1, and FSR2 are captured immediately.  Later   */
/*  in the macro, they will be saved.  This early capture is performed especially because FSR0 will be  */
/*  used in this macro for data memory access.  As an aside, it should be mentioned that code produced  */
/*  by the compiler uses FSR0 as a data memory pointer and FSR1 as a software stack pointer (not        */
/*  relate to the px stack), while FSR2 is used as a frame pointer in conjunction with FSR1.            */
/*                                                                                                      */
/*  It should be noted that the interrupt configuration register, INTCON, is not saved, because it is   */
/*  handled automatically in the processing of the interrupts.  Its value is initialized in the         */
/*  prvSetupTimerAndInterrupts function.                                                                */


#define portSAVE_CONTEXT( )                                                                                  \
{                                                                                                            \
   _asm                                                                                                      \
                                                                                                             \
       MOVFF   STATUS,     holdSTATUS                                                                        \
       MOVFF   WREG,       holdWREG                                                                          \
                                                                                                             \
       MOVFF   FSR0L,      holdFSR0L                                                                         \
       MOVFF   FSR0H,      holdFSR0H                                                                         \
                                                                                                             \
       MOVFF   FSR1L,      holdFSR1L                                                                         \
       MOVFF   FSR1H,      holdFSR1H                                                                         \
                                                                                                             \
       MOVFF   FSR2L,      holdFSR2L                                                                         \
       MOVFF   FSR2H,      holdFSR2H                                                                         \
                                                                                                             \
                                                                                                             \
/*  Later in the macro, these captured values will be saved in the px stack as alluded to above.  At    */   \
/*  the end of the macro, they will also be returned to their respective registers.  In the meantime,   */   \
/*  these registers can be used without concern over their corruption.                                  */   \
/*                                                                                                      */   \
/*  The save operation requires the retrieval of the address of the bottom, or start (lowest address    */   \
/*  value), of the px stack.  When the TCB was set up for the task, the address of the first byte in    */   \
/*  the px stack was determined and stored in the member of the TCB defined as "(unsigned char)         */   \
/*  *pxTopOfStack".                                                                                     */   \
/*                                                                                                      */   \
/*  The first step needed to access pxTopOfStack is to load FSR0 with the address of the TCB.  More     */   \
/*  specifically, it is loaded with the address of the byte at the lowest, or starting, address in the  */   \
/*  TCB.                                                                                                */   \
                                                                                                             \
       MOVFF   pxCurrentTCB,       FSR0L                                                                     \
       MOVFF   pxCurrentTCB + 1,   FSR0H                                                                     \
                                                                                                             \
                                                                                                             \
/*  To avoid possible confusion, it should be noted that pxCurrentTCB is simply a two-byte pointer      */   \
/*  variable.  It is not in itself a representation of the TCB structure.  Rather, it refers to the TCB */   \
/*  structure that was set aside within the ucHeap[ configTOTAL_HEAP_SIZE ] array by the pvPortMalloc   */   \
/*  function.                                                                                           */   \
/*                                                                                                      */   \
/*  In a typical example, the TCB may start at location 0x0104 in the heap, while the compiler might    */   \
/*  have placed pxCurrentTCB at 0x0361 (as shown in the map file).  In that case, the byte at location  */   \
/*  0x0361 will have the value 0x04 and the byte at 0x0362 will have the value 0x01.  Given that, the   */   \
/*  instruction "MOVFF pxCurrentTCB, FSR0L" will put 0x04 into FSR0L, and the instruction "MOVFF        */   \
/*  pxCurrentTCB + 1, FSR0L" will put 0x01 into FSR0H, so that FSR0 now has a value of 0x0104.          */   \
/*                                                                                                      */   \
/*  The address of pxStack turns out to be 23 locations into the TCB, which means that its address is   */   \
/*  23 locations higher.  Thus, if the first byte of the TCB is at 0x0104, pxStack will be at 0x011B.   */   \
/*  To get there, FSR0 is incremented 23 times through a series of dummy writes to WREG.                */   \
                                                                                                             \
                                                                                                             \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   POSTINC0,   WREG                                                                              \
                                                                                                             \
                                                                                                             \
/*  FSR0 now points to the low byte of pxStack.  The value of this byte, and that of the one after it,  */   \
/*  constitute the address of the bottom of the px stack.  This address is loaded into FSR0 by first    */   \
/*  loading the low byte into FSR0L and then loading the high byte into FSR0H.                          */   \
                                                                                                             \
                                                                                                             \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   WREG,       tempFSR0L                                                                         \
                                                                                                             \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   WREG,       tempFSR0H                                                                         \
                                                                                                             \
       MOVFF   tempFSR0L,  FSR0L                                                                             \
       MOVFF   tempFSR0H,  FSR0H                                                                             \
                                                                                                             \
                                                                                                             \
       MOVFF   holdSTATUS, WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
       MOVFF   holdWREG,   WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
                                                                                                             \
/*  The px stack will now be populated, starting with the captured values of STATUS, WREG, and the      */   \
/*  three indirect addressing registers.                                                                */   \
                                                                                                             \
                                                                                                             \
       MOVFF   holdFSR0L,  WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
       MOVFF   holdFSR0H,  WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
       MOVFF   holdFSR1L,  WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
       MOVFF   holdFSR1H,  WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
       MOVFF   holdFSR2L,  WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
       MOVFF   holdFSR2H,  WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
                                                                                                             \
/*  The next group of instructions captures and saves the values in the bank select register, program   */   \
/*  memory table registers, multiplier product registers, and program counter holding registers.        */   \
                                                                                                             \
                                                                                                             \
       MOVFF   BSR,        POSTINC0                                                                          \
       MOVFF   TABLAT,     POSTINC0                                                                          \
       MOVFF   TBLPTRL,    POSTINC0                                                                          \
       MOVFF   TBLPTRH,    POSTINC0                                                                          \
       MOVFF   TBLPTRU,    POSTINC0                                                                          \
       MOVFF   PRODL,      POSTINC0                                                                          \
       MOVFF   PRODH,      POSTINC0                                                                          \
       MOVFF   PCLATH,     POSTINC0                                                                          \
       MOVFF   PCLATU,     POSTINC0                                                                          \
                                                                                                             \
                                                                                                             \
/*  A convenient means of exchanging data with a given task is provided by means of a pointer called    */   \
/*  "pvParam", which can be used to point to a data structure.  While pvParam is a global variable, the */   \
/*  particular value that it has at any given time is a function of the task that is presently running. */   \
/*  Here the present value of pvParam is saved to the px stack.                                         */   \
                                                                                                             \
                                                                                                             \
       MOVFF   pvParam,        WREG                                                                          \
       MOVFF   WREG,           POSTINC0                                                                      \
                                                                                                             \
       MOVFF   pvParam + 1,    WREG                                                                          \
       MOVFF   WREG,           POSTINC0                                                                      \
                                                                                                             \
                                                                                                             \
/*  The compiler generates code that uses a section in data memory for the so-called ".tmpdata" and     */   \
/*  "MATH_DATA" variables.  This section is referred to as the "uc block", and it begins at address     */   \
/*  0x000000.  The number of bytes to be set aside for this section is given by                         */   \
/*  "portCOMPILER_MANAGED_MEMORY_SIZE", a value which must be set by the user, that is defined at the   */   \
/*  beginning of this file.                                                                             */   \
/*                                                                                                      */   \
/*  For performing the copying of data from the uc block to the px stack, FSR0 is used.  A slightly     */   \
/*  elaborate scheme is necessary, in which FSR0 is used alternately as an indexer to the uc block and  */   \
/*  as an indexer to the px stack.  This approach was chosen because it was found that attempts to      */   \
/*  include either FSR1 or FSR2 resulted in crashes.  This is believed to be due to the fact that the   */   \
/*  compiler expects FSR1 to be available for use as the software stack pointer and FSR2 to be          */   \
/*  available for use as the software stack frame pointer.  This is for the stack that is defined in    */   \
/*  the linker script file, and should not be confused with the stacks that are discussed here.         */   \
/*                                                                                                      */   \
/*  The alternating indexing scheme is implemented with the help of two variables called "ucBlockFSR0"  */   \
/*  and "pxStackFSRO".  The procedure begins with the setting of the value of ucBlockFSR0 to the        */   \
/*  starting address of the uc block, in this case 0x000000.                                            */   \
                                                                                                             \
                                                                                                             \
       MOVLW   0x00                                                                                          \
       MOVFF   WREG,       ucBlockFSR0L                                                                      \
                                                                                                             \
       MOVLW   0x00                                                                                          \
       MOVFF   WREG,       ucBlockFSR0H                                                                      \
                                                                                                             \
   _endasm                                                                                                   \
                                                                                                             \
                                                                                                             \
/*  Next, a while loop is used to sequence through the uc block and copy data to it from the px stack.  */   \
/*  It should be noted that the sequencing will be done through both stacks in ascending order of       */   \
/*  addressing.                                                                                         */   \
                                                                                                             \
                                                                                                             \
    while(ucBlockFSR0L < portCOMPILER_MANAGED_MEMORY_SIZE)                                                   \
    {                                                                                                        \
        _asm                                                                                                 \
                                                                                                             \
/*  Save the value of the indexer that points to the px stack.                                          */   \
                                                                                                             \
           MOVFF   FSR0L,          pxStackFSR0L                                                              \
           MOVFF   FSR0H,          pxStackFSR0H                                                              \
                                                                                                             \
/*  Make FRS0 point to the uc block.                                                                    */   \
                                                                                                             \
           MOVFF   ucBlockFSR0L,   FSR0L                                                                     \
           MOVFF   ucBlockFSR0H,   FSR0H                                                                     \
                                                                                                             \
/*  Capture the value at that location in the uc block and increment the indexer.                       */   \
                                                                                                             \
           MOVFF   POSTINC0,       WREG                                                                      \
                                                                                                             \
/*  Set aside the value of the indexer that points to the uc block.                                     */   \
                                                                                                             \
           MOVFF   FSR0L,          ucBlockFSR0L                                                              \
           MOVFF   FSR0H,          ucBlockFSR0H                                                              \
                                                                                                             \
/*  and make FSR0 point to the px stack.                                                                */   \
                                                                                                             \
           MOVFF   pxStackFSR0L,   FSR0L                                                                     \
           MOVFF   pxStackFSR0H,   FSR0H                                                                     \
                                                                                                             \
/*  Now save the captured value to the px stack and increment the indexer so that it points to the next */   \
/*  location in the px stack.                                                                           */   \
                                                                                                             \
           MOVFF   WREG,           POSTINC0                                                                  \
                                                                                                             \
/*  The while loop now looks at ucBlockFSR0 and branches back if its value is less than the defined     */   \
/*  value of portCOMPILER_MANAGED_MEMORY_SIZE.  Because this value is only allowed to be less than 127, */   \
/*  for reasons discussed in portRESTORE_CONTEXT, only the low byte of cvStackFSR0, namely              */   \
/*  ucBlockFSR0L, is checked.                                                                           */   \
                                                                                                             \
        _endasm                                                                                              \
    }                                                                                                        \
                                                                                                             \
                                                                                                             \
/*  When the while loop concludes, the value of portCOMPILER_MANAGED_MEMORY_SIZE is saved as well.      */   \
                                                                                                             \
   _asm                                                                                                      \
                                                                                                             \
       MOVLW   portCOMPILER_MANAGED_MEMORY_SIZE                                                              \
                                                                                                             \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
                                                                                                             \
/*  The PIC 18F8520 uses a block of registers called the "Return Address Stack" to facilitate the       */   \
/*  management of interrupts and functions.  When an interrupt takes place or a function call is made,  */   \
/*  the value of the program counter is pushed (placed) on this stack.  Later, upon returning from that */   \
/*  interrupt or function, that value is popped (removed) and copied back to the program counter so     */   \
/*  that the interrupted function can resume.                                                           */   \
/*                                                                                                      */   \
/*  The pointer, or indexer, to the Return Address Stack is called "STKPTR".  When a new program        */   \
/*  counter value is pushed onto this stack, STKPTR is incremented and when one is popped, STKPTR is    */   \
/*  decremented.  When STKPTR is zero, the Return Address Stack is considered empty.  Thus, STKPTR      */   \
/*  indicates the number of entries that are on the Return Address Stack at any given time.             */   \
/*                                                                                                      */   \
/*  The current value in STKPTR and the contents of the Return Address Stack must be copied to the px   */   \
/*  stack.  Because STKPTR is decremented each time the Return Address Stack is read (that is, popped), */   \
/*  it is captured first and set aside for later saving.                                                */   \
                                                                                                             \
                                                                                                             \
       MOVFF   STKPTR,     holdSTKPTR                                                                        \
                                                                                                             \
   _endasm                                                                                                   \
                                                                                                             \
                                                                                                             \
/*  The capturing and saving of the contents of the Return Address Stack are performed through a series */   \
/*  of copy and pop operations in a while loop that continues until the value in STKPTR is zero.        */   \
/*                                                                                                      */   \
/*  Each entry in the Return Address Stack consists of three bytes, called "TOSU", "TOSH", and "TOSL",  */   \
/*  for the most significant, middle, and least significant bytes respectively.  In the px stack, they  */   \
/*  are ordered in ascending address with TOSL first.                                                   */   \
                                                                                                             \
                                                                                                             \
    while(STKPTR > 0)                                                                                        \
    {                                                                                                        \
        _asm                                                                                                 \
                                                                                                             \
           MOVF    TOSL,   0, 0                                                                              \
           MOVFF   WREG,   POSTINC0                                                                          \
           MOVF    TOSH,   0, 0                                                                              \
           MOVFF   WREG,   POSTINC0                                                                          \
           MOVF    TOSU,   0, 0                                                                              \
           MOVFF   WREG,   POSTINC0                                                                          \
                                                                                                             \
           POP                                                                                               \
                                                                                                             \
        _endasm                                                                                              \
    }                                                                                                        \
                                                                                                             \
                                                                                                             \
/*  At the conclusion of the while loop, the value in STKPTR will be zero and the Return Address Stack  */   \
/*  is (temporarily) empty.  Later, when portRESTORE_CONTEXT is called, the Return Address Stack will   */   \
/*  be re-populated, either with the values that were saved here or (more likely) with values           */   \
/*  associated with another task.                                                                       */   \
/*                                                                                                      */   \
/*  At this point, all of the registers whose values are to be saved have been captured, and some have  */   \
/*  been saved as well.  In the remainder of this macro, the rest of the captured values are saved.     */   \
/*                                                                                                      */   \
/*  Presently, the value that STKPTR had prior to the execution of the while loop must be saved.        */   \
                                                                                                             \
                                                                                                             \
   _asm                                                                                                      \
                                                                                                             \
       MOVFF   holdSTKPTR, WREG                                                                              \
       MOVFF   WREG,       INDF0                                                                             \
                                                                                                             \
                                                                                                             \
/*  In the last instruction above, INDF0 was used in place of POSTINC0 in order to leave FSR0 pointing  */   \
/*  to the last byte in the px stack that was populated, rather than incrementing it to the next        */   \
/*  location.  This is necessary because that un-incremented value must be saved back into the TCB in   */   \
/*  order to complete the context save.  This address represents the "top" of the px stack.             */   \
/*                                                                                                      */   \
/*  First, this address is set aside.                                                                   */   \
                                                                                                             \
                                                                                                             \
       MOVFF   FSR0L,      tempFSR0L                                                                         \
       MOVFF   FSR0H,      tempFSR0H                                                                         \
                                                                                                             \
                                                                                                             \
/*  Then, FSR0 is loaded with the address of the first byte in the TCB.                                 */   \
                                                                                                             \
                                                                                                             \
       MOVFF   pxCurrentTCB,       FSR0L                                                                     \
       MOVFF   pxCurrentTCB + 1,   FSR0H                                                                     \
                                                                                                             \
                                                                                                             \
/*  The TCB is set up so that its first two bytes must contain the address of the top of the px stack.  */   \
/*  From the previous instructions, FSR0 is now pointing to the first ( less significant ) of these two */   \
/*  bytes.  The next set of instructions populates those two bytes with the low and high bytes,         */   \
/*  respectively, of the address of the top of the px stack.                                            */   \
                                                                                                             \
                                                                                                             \
       MOVFF   tempFSR0L,  WREG                                                                              \
       MOVFF   WREG,       POSTINC0                                                                          \
                                                                                                             \
       MOVFF   tempFSR0H,  WREG                                                                              \
       MOVFF   WREG,       INDF0                                                                             \
                                                                                                             \
                                                                                                             \
/*  Finally, those register values that were captured earlier, and which subsequently were changed or   */   \
/*  could have been changed by the code in this macro, are now returned to their respective registers.  */   \
                                                                                                             \
                                                                                                             \
       MOVFF   holdFSR2H,  WREG                                                                              \
       MOVFF   WREG,       FSR2H                                                                             \
                                                                                                             \
       MOVFF   holdFSR2L,  WREG                                                                              \
       MOVFF   WREG,       FSR2L                                                                             \
                                                                                                             \
       MOVFF   holdFSR1H,  WREG                                                                              \
       MOVFF   WREG,       FSR1H                                                                             \
                                                                                                             \
       MOVFF   holdFSR1L,  WREG                                                                              \
       MOVFF   WREG,       FSR1L                                                                             \
                                                                                                             \
       MOVFF   holdFSR0H,  WREG                                                                              \
       MOVFF   WREG,       FSR0H                                                                             \
                                                                                                             \
       MOVFF   holdFSR0L,  WREG                                                                              \
       MOVFF   WREG,       FSR0L                                                                             \
                                                                                                             \
       MOVFF   holdWREG,   WREG                                                                              \
                                                                                                             \
       MOVFF   holdSTATUS, WREG                                                                              \
       MOVFF   WREG,       STATUS                                                                            \
                                                                                                             \
   _endasm                                                                                                   \
}


/*  portRESTORE_CONTEXT                                                                                 */


#define portRESTORE_CONTEXT()                                                                                \
{                                                                                                            \
                                                                                                             \
/*  The portRESTORE_CONTEXT macro supports the retrieval and restoration of the state of a task at the  */   \
/*  conclusion of either an RTOS tick interrupt or a vPortYield function call.                          */   \
/*                                                                                                      */   \
/*  When either of these events takes place, a decision is made as to which task is to be resumed, by   */   \
/*  way of a call to the vTaskSwitchContext function.  Then, portRESTORE_CONTEXT copies the values in   */   \
/*  that task's px stack to those respective registers and memory locations that the task was using or  */   \
/*  could have been using at the time it was last suspended.  These include the indirect addressing     */   \
/*  register, FSR0, which in the meantime is used in this macro for data memory access.                 */   \
/*                                                                                                      */   \
/*  The restore operation requires the retrieval of the address of the top, or finish (highest address  */   \
/*  value), of the px stack.  When the TCB was set up for the task, the address of the first byte in    */   \
/*  the px stack was determined and stored in the member of the TCB defined as "(unsigned char)         */   \
/*  *pxTopOfStack".  By the time portRESTORE_CONTEXT is called, however, this value will have been      */   \
/*  successively incremented (in portSAVE_CONTEXT) such that it contains the address of the last byte   */   \
/*  in the px stack, that is, the byte with the highest address.                                        */   \
/*                                                                                                      */   \
/*  The first step needed to access pxTopOfStack is to load FSR0 with the address of the TCB.  More     */   \
/*  specifically, it is loaded with the address of the byte at the lowest, or starting, address in the  */   \
/*  TCB.                                                                                                */   \
                                                                                                             \
                                                                                                             \
   _asm                                                                                                      \
                                                                                                             \
       MOVFF   pxCurrentTCB,       FSR0L                                                                     \
       MOVFF   pxCurrentTCB + 1,   FSR0H                                                                     \
                                                                                                             \
                                                                                                             \
/*  To avoid possible confusion, it should be noted that pxCurrentTCB is simply a two-byte pointer      */   \
/*  variable.  It is not in itself a representation of the TCB structure.  Rather, it refers to the TCB */   \
/*  structure that was set aside within the ucHeap[ configTOTAL_HEAP_SIZE ] array by the portMalloc     */   \
/*  function.                                                                                           */   \
/*                                                                                                      */   \
/*  In a typical example, the TCB may start at location 0x0104 in the heap, while the compiler happened */   \
/*  to put pxCurrentTCB at 0x0361 (as shown in the map file).  In that case, the byte at location       */   \
/*  0x0361 will have the value 0x04 and the byte at 0x0362 will have the value 0x01.  Given that, the   */   \
/*  instruction "MOVFF pxCurrentTCB, FSR0L" will put 0x04 into FSR0L, and the instruction "MOVFF        */   \
/*  pxCurrentTCB + 1, FSR0L" will put 0x01 into FRS0H, so that FSR0 now contains 0x0104.                */   \
/*                                                                                                      */   \
/*  It turns out that pxTopOfStack is the first member in the TCB.  Thus, FSR0 is presently pointing to */   \
/*  pxTopOfStack and the first step is thus done.                                                       */   \
/*                                                                                                      */   \
/*  The next step is to copy the value in pxTopOfStack to FSR0, so that FSR0 is then pointing to the    */   \
/*  byte with the highest address, that is, the top, of the px stack.                                   */   \
                                                                                                             \
                                                                                                             \
       MOVFF   POSTINC0,   WREG                                                                              \
       MOVFF   WREG,       tempFSR0L                                                                         \
                                                                                                             \
       MOVFF   INDF0,      WREG                                                                              \
       MOVFF   WREG,       tempFSR0H                                                                         \
                                                                                                             \
       MOVFF   tempFSR0L,  FSR0L                                                                             \
       MOVFF   tempFSR0H,  FSR0H                                                                             \
                                                                                                             \
                                                                                                             \
/*  FSR0 now points to the low byte of pxTopOfStack.  The value of this byte, and that of the one after */   \
/*  it, constitute the address of the top of the px stack.                                              */   \
/*                                                                                                      */   \
/*  The contents of the px stack will now be retrieved and the corresponding registers and memory       */   \
/*  locations will be populated.  The procedure will index downward through the px stack, in the        */   \
/*  direction opposite to that done in portSAVE_CONTEXT.                                                */   \
/*                                                                                                      */   \
/*  The PIC 18F8520 uses a block of registers called the "Return Address Stack" to facilitate the       */   \
/*  management of interrupts and functions.  When an interrupt takes place or a function call is made,  */   \
/*  the value of the program counter is pushed (placed) on this stack.  Later, upon returning from that */   \
/*  interrupt or function, that value is popped (removed) and copied back to the program counter so     */   \
/*  that the interrupted function can resume.                                                           */   \
/*                                                                                                      */   \
/*  The pointer, or indexer, to the Return Address Stack is called "STKPTR".  When a new program        */   \
/*  counter value is pushed onto this stack, STKPTR is incremented and when one is popped, STKPTR is    */   \
/*  decremented.  When STKPTR is zero, the Return Address Stack is considered empty.  Thus, STKPTR      */   \
/*  indicates the number of entries that are on the Return Address Stack at any given time.             */   \
/*                                                                                                      */   \
/*  The byte that FSR0 is now pointing to contains the value that was in STKPTR when the                */   \
/*  portSAVE_CONTEXT macro was run.                                                                     */   \
/*                                                                                                      */   \
/*  This value is now retrieved from the px stack and set aside.                                        */   \
                                                                                                             \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdSTKPTR                                                                        \
                                                                                                             \
                                                                                                             \
/*  A while loop is now set up that sequences through the Return Address Stack, populating it with      */   \
/*  those corresponding values that have been saved in the px stack.  Each entry in the Return Address  */   \
/*  Stack consists of three bytes, called "TOSU", "TOSH", and "TOSL", for the most significant, middle, */   \
/*  and least significant bytes respectively.                                                           */   \
/*                                                                                                      */   \
/*  STKPTR serves as the pointer to (indexer into) the hardware stack.  It is first set to zero.        */   \
                                                                                                             \
                                                                                                             \
       MOVLW   0x00                                                                                          \
       MOVFF   WREG,       STKPTR                                                                            \
                                                                                                             \
   _endasm                                                                                                   \
                                                                                                             \
    while(STKPTR < holdSTKPTR)                                                                               \
    {                                                                                                        \
       _asm                                                                                                  \
                                                                                                             \
           PUSH                                                                                              \
                                                                                                             \
           MOVF    POSTDEC0, 0, 0                                                                            \
           MOVWF   TOSU, 0                                                                                   \
           MOVF    POSTDEC0, 0, 0                                                                            \
           MOVWF   TOSH, 0                                                                                   \
           MOVF    POSTDEC0, 0, 0                                                                            \
           MOVWF   TOSL, 0                                                                                   \
                                                                                                             \
       _endasm                                                                                               \
    }                                                                                                        \
                                                                                                             \
                                                                                                             \
/*  When the while loop concludes, STKPTR will be left having the value that is in holdSTKPTR.  Thus,   */   \
/*  STKPTR has now been restored, along with the entries to the hardware stack.                         */   \
/*                                                                                                      */   \
/*  The compiler generates code that uses a section in data memory for the so-called ".tmpdata" and     */   \
/*  "MATH_DATA" variables.  This section is referred to as the "uc block", and it begins at address     */   \
/*  0x000000.  The number of bytes to be set aside for this section is given by                         */   \
/*  "portCOMPILER_MANAGED_MEMORY_SIZE", a value which must be set by the user, that is defined at the   */   \
/*  beginning of this file.                                                                             */   \
/*                                                                                                      */   \
/*  For performing the copying of data from the px stack to the uc block, FRS0 is used.  A slightly     */   \
/*  elaborate scheme is necessary, in which FSR0 is used alternately as an indexer to the px stack and  */   \
/*  as an indexer to the uc block.  This approach was chosen because it was found that attempts to      */   \
/*  include either FSR1 or FSR2 resulted in crashes.  This is believed to be due to the fact that the   */   \
/*  compiler expects FSR1 to be available for use as the software stack pointer, and FSR2 to be         */   \
/*  available for use as the software stack frame pointer.  This is for the stack that is defined in    */   \
/*  the linker script file, and should not be confused with the stacks that are discussed here.         */   \
/*                                                                                                      */   \
/*  The alternating indexing scheme is implemented with the help of two variables called "ucBlockFSR0"  */   \
/*  and "pxStackFSRO".  The procedure begins with the setting of the value of ucBlockFSR0 to the        */   \
/*  finishing (highest) address of the uc block.                                                        */   \
/*                                                                                                      */   \
/*  The uc block is restored starting at its highest address and working down.  Because the ucBlock was */   \
/*  originally built up starting at address 0x000000, the value of its highest address is given by      */   \
/*  portCOMPILER_MANAGED_MEMORY_SIZE - 1.  When the uc block was finished being built, the next higher  */   \
/*  byte was set to portCOMPILER_MANAGED_MEMORY_SIZE , the number of bytes that are stored in the uc    */   \
/*  block.                                                                                              */   \
/*                                                                                                      */   \
/*  When the above while loop concluded, FSR0 was left pointing at this address that contains the value */   \
/*  of portCOMPILER_MANAGED_MEMORY_SIZE.  The starting address for the uc block restoration that will   */   \
/*  follow is obtained by subtracting 1 from this value.                                                */   \
                                                                                                             \
                                                                                                             \
   _asm                                                                                                      \
                                                                                                             \
       MOVLW   0x00                                                                                          \
       MOVFF   WREG,       ucBlockFSR0H                                                                      \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       ADDLW   -1                                                                                            \
       MOVFF   WREG,       ucBlockFSR0L                                                                      \
                                                                                                             \
   _endasm                                                                                                   \
                                                                                                             \
                                                                                                             \
/*  Next, a while loop is set up that will sequence through the px stack and copy data from it to the   */   \
/*  uc block.  It should be noted that the sequencing will be done through both stacks in descending    */   \
/*  order of addressing, in contrast to that used in portSAVE_CONTEXT.                                  */   \
                                                                                                             \
                                                                                                             \
   while(((signed char)ucBlockFSR0L >= 0x00))                                                                \
   {                                                                                                         \
       _asm                                                                                                  \
                                                                                                             \
/*  FSR0 was left pointing to the first or a subsequent byte in the px stack that is to be copied.  The */   \
/*  value of that byte is now captured.                                                                 */   \
                                                                                                             \
           MOVFF   POSTDEC0,       WREG                                                                      \
                                                                                                             \
/*  Save the value of the indexer that points to the px stack.                                          */   \
                                                                                                             \
           MOVFF   FSR0L,          pxStackFSR0L                                                              \
           MOVFF   FSR0H,          pxStackFSR0H                                                              \
                                                                                                             \
/*  Make FSR0 point to the uc block.                                                                    */   \
                                                                                                             \
           MOVFF   ucBlockFSR0L,   FSR0L                                                                     \
           MOVFF   ucBlockFSR0H,   FSR0H                                                                     \
                                                                                                             \
/*  The byte from the px stack, which was captured earlier, is then copied to the uc block.             */   \
                                                                                                             \
           MOVFF   WREG,           POSTDEC0                                                                  \
                                                                                                             \
/*  Set aside the value of the indexer that points to the uc block.                                     */   \
                                                                                                             \
           MOVFF   FSR0L,          ucBlockFSR0L                                                              \
           MOVFF   FSR0H,          ucBlockFSR0H                                                              \
                                                                                                             \
/*  and make FSR0 point to the px stack.                                                                */   \
                                                                                                             \
           MOVFF   pxStackFSR0L,   FSR0L                                                                     \
           MOVFF   pxStackFSR0H,   FSR0H                                                                     \
                                                                                                             \
        _endasm                                                                                              \
                                                                                                             \
/*  The while loop now looks at ucBlockFSR0 and branches back if it is greater than or equal to zero.   */   \
/*  Only FSR0L is actually tested, because only one byte is provided for holding the value of           */   \
/*  portCOMPILER_MANAGED_MEMORY_SIZE.  It should be noted that because ucBlockFSR0L is evaluated as a   */   \
/*  signed value, the size of the uc block cannot be greater than 127.                                  */   \
                                                                                                             \
    }                                                                                                        \
                                                                                                             \
                                                                                                             \
/*  After the while loop concludes, FSR0 is left pointing to the high byte of pvParam.  This and the    */   \
/*  low byte of pvParam are now restored, followed by the program counter holding registers, multiplier */   \
/*  product registers, program memory table registers, and the bank select register.                    */   \
                                                                                                             \
                                                                                                             \
   _asm                                                                                                      \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       pvParam + 1                                                                       \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       pvParam                                                                           \
                                                                                                             \
       MOVFF   POSTDEC0,   PCLATU                                                                            \
       MOVFF   POSTDEC0,   PCLATH                                                                            \
       MOVFF   POSTDEC0,   PRODH                                                                             \
       MOVFF   POSTDEC0,   PRODL                                                                             \
       MOVFF   POSTDEC0,   TBLPTRU                                                                           \
       MOVFF   POSTDEC0,   TBLPTRH                                                                           \
       MOVFF   POSTDEC0,   TBLPTRL                                                                           \
       MOVFF   POSTDEC0,   TABLAT                                                                            \
       MOVFF   POSTDEC0,   BSR                                                                               \
                                                                                                             \
                                                                                                             \
/*  The next group of bytes in the px stack corresponds to those registers whose values must now be     */   \
/*  retrieved but which will not be restored until later.  They are not restored until later because    */   \
/*  FSR0 is used in the meantime.                                                                       */   \
                                                                                                             \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdFSR2H                                                                         \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdFSR2L                                                                         \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdFSR1H                                                                         \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdFSR1L                                                                         \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdFSR0H                                                                         \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdFSR0L                                                                         \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdWREG                                                                          \
                                                                                                             \
       MOVFF   POSTDEC0,   WREG                                                                              \
       MOVFF   WREG,       holdSTATUS                                                                        \
                                                                                                             \
                                                                                                             \
/*  Finally, the registers that were retrieved earlier are now restored.                                */   \
                                                                                                             \
                                                                                                             \
       MOVFF   holdFSR2H,  FSR2H                                                                             \
       MOVFF   holdFSR2L,  FSR2L                                                                             \
                                                                                                             \
       MOVFF   holdFSR1H,  FSR1H                                                                             \
       MOVFF   holdFSR1L,  FSR1L                                                                             \
                                                                                                             \
       MOVFF   holdFSR0H,  FSR0H                                                                             \
       MOVFF   holdFSR0L,  FSR0L                                                                             \
                                                                                                             \
       MOVFF   holdWREG,   WREG                                                                              \
                                                                                                             \
       MOVFF   holdSTATUS, STATUS                                                                            \
                                                                                                             \
   _endasm                                                                                                   \
                                                                                                             \
}

/*  pxPortInitialiseStack                                                                               */

portSTACK_TYPE *pxPortInitialiseStack
                        ( portSTACK_TYPE *pxStackPointer, pdTASK_CODE pxCode, void *pvParamInPxStack )
{
    portSTACK_TYPE     bottomOfProcessStack;
    unsigned portLONG  ulPvParameter;
    unsigned portLONG  ulAddress;
    unsigned portCHAR  ucBlockIndex;

    unsigned long int  index, index1;

/*  The pxPortInitialiseStack function populates a px stack with initial values.  It is called from the */
/*  xTaskCreate function, after xTaskCreate has set up a task and has allocated the TCB and px stack    */
/*  for that task.  The pxPortInitializeStack function can be thought of as the first portCONTEXT_SAVE  */
/*  for that task, with the difference being that some of the values being saved are initial values     */
/*  rather than existing register and data memory values.                                               */
/*                                                                                                      */
/*  The initialize operation requires the retrieval of the address of the bottom, or start (lowest      */
/*  address value), of the px stack.  When the TCB was set up for the task, the address of the first    */
/*  byte in the px stack was determined and stored in the member of the TCB defined as "(unsigned char) */
/*  *pxTopOfStack".                                                                                     */
/*                                                                                                      */
/*  When pxPortInitialiseStack is called, this value is passed to it by way of the " *pxStackPointer "  */
/*  parameter.  Then, as pxPortInitializeStack proceeds, pxStackPointer will be used as an indexer that */
/*  is successively incremented as each new px stack entry is initialized.  When pxPortInitialiseStack  */
/*  concludes, it will return the address of the last byte in the px stack that was populated.          */
/*  Subsequently, xTaskCreate will update the pxStack member of the TCB with this new value.  This is   */
/*  why, when portRESTORE_CONTEXT is run, pxStack contains the address of the last byte in the px stack */
/*  to be populated, rather than the first.                                                             */
/*                                                                                                      */
/*  The second parameter of pxPortInitialiseStack is "pxCode", which is the address in program memory   */
/*  of the task that is being set up.  For example, if the user writes a task that appears at 0x00411A  */
/*  in the map file, the value of pxCode will be 0x00411A.                                              */
/*                                                                                                      */
/*  The third parameter is " *pvParamInPxStack ", and its value will become the initial value of        */
/*  pvParam for the task.  pvParam is available for use in pointing to a variable or a data structure   */
/*  that the user has created for exchanging data with the task.  For example, if the user created a    */
/*  structure called myStruct, and had " &myStruct " for the " *pvParameters " argument in the call to  */
/*  xTaskCreate, then pvParamInPxStack will be set to the address of myStruct.  Later, when the task is */
/*  first run or resumed, that address will be copied to pvParam and will thus be available to the      */
/*  task.                                                                                               */
/*                                                                                                     */
/*  Most of the entries that correspond to register values are simply set to whatever value the         */
/*  associated register has at the time, as opposed to setting them to dummy variables.  The primary    */
/*  reason for this approach is to preserve the relationship among the three indirect addressing        */
/*  registers FSR0, FSR1, and FSR2; attempts to use FSR1 or FSR2 directly in code resulted in crashes.  */
/*  This is believed to be due to the compiler generating code that uses FSR1 as a software stack       */
/*  pointer and FSR2 as a software stack frame pointer.                                                 */
/*                                                                                                      */
/*  It should be noted that the interrupt configuration register, INTCON, is not saved, because it is   */
/*  handled automatically in the processing of the interrupts.  Its value is initialized in the         */
/*  prvSetupTimerAndInterrupts function.                                                                */
/*                                                                                                      */
/*  The ordering of the entries in the px stack was chosen based on a combination of timing priorities  */
/*  and convenience.  For example, in the portSAVE_CONTEXT macro, certain registers such as the status  */
/*  register should be captured as early as possible, and hence the code appears the smoothest if those */
/*  values are saved to the px stack in the same order.  Because pxPortInitializeStack is essentially   */
/*  the first portSAVE_CONTEXT operation, the ordering of the initializations performed here must be    */
/*  the same as those in portSAVE_CONTEXT.                                                              */
/*                                                                                                      */
/*  First, the registers that are to be directly copied are captured and saved.                         */

/*  Capture and save STATUS                                                                             */

    *pxStackPointer = ( portSTACK_TYPE ) STATUS;


/*  Capture and save WREG                                                                               */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) WREG;


/*  Capture and save FSR0                                                                               */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) FSR0L;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) FSR0H;


/*  Capture and save FSR1                                                                               */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) FSR1L;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) FSR1H;


/*  Capture and save FSR2                                                                               */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) FSR2L;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) FSR2H;


/*  Capture and save BSR                                                                                */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) BSR;


/* Capture and save TABLAT                                                                              */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) TABLAT;


/*  Capture and save TBLPTR                                                                             */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) TBLPTRL;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) TBLPTRH;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) TBLPTRU;


/*  Capture and save PROD                                                                               */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) PRODL;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) PRODH;


/*  Capture and save PCLAT                                                                              */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) PCLATH;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) PCLATU;


/*  Next, the value of the third parameter, pvParamInPxStack, is captured and saved.                    */

    ulPvParameter = ( unsigned portLONG ) pvParamInPxStack;

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) ( ulPvParameter & ( unsigned portLONG ) 0x00ff );

    pxStackPointer++;

    ulPvParameter >>= 8;

    *pxStackPointer = ( portSTACK_TYPE ) (ulPvParameter & ( unsigned portLONG ) 0x00ff );


/*  The compiler generates code that uses a section in data memory for the so-called ".tmpdata" and     */
/*  "MATH_DATA" variables.  This section is referred to as the "uc block", and it begins at address     */
/*  0x000000.  The number of bytes to be set aside for this section is given by                         */
/*  "portCOMPILER_MANAGED_MEMORY_SIZE", a value which must be set by the user, that is defined at the   */
/*  beginning of this file.                                                                             */
/*                                                                                                      */
/*  In the portCONTEXT_SAVE macro, the next section of the px stack would be populated with the values  */
/*  that are in the uc block.  However, here in the pxPortInitialiseStack function, that section of the */
/*  px stack is populated with dummy values.  A for loop is used to sequence through this section.      */

    pxStackPointer++;

    for( ucBlockIndex = 0; ucBlockIndex < portCOMPILER_MANAGED_MEMORY_SIZE; ucBlockIndex++ )
    {
        *pxStackPointer = ( portSTACK_TYPE ) (ucBlockIndex);

        pxStackPointer++;
    }


/*  Then, the number of bytes that were copied is saved in the next byte.                               */

    *pxStackPointer = ( portSTACK_TYPE ) portCOMPILER_MANAGED_MEMORY_SIZE;


/*  The PIC 18F8520 uses a block of registers called the "Return Address Stack" to facilitate the       */
/*  management of interrupts and functions.  When an interrupt takes place or a function call is made,  */
/*  the value of the program counter is pushed (placed) on this stack.  Later, upon returning from that */
/*  interrupt or function, that value is popped (removed) and copied back to the program counter so     */
/*  that the interrupted function can resume.  The context switching mechanism of the operating system  */
/*  is based on the fact that this program counter value can be changed inside the interrupting         */
/*  function, so that when the return takes place, a function that is different from the one that was   */
/*  interrupted will be run.                                                                            */
/*                                                                                                      */
/*  The pointer, or indexer, to the Return Address Stack is called "STKPTR".  When a new program        */
/*  counter value is pushed onto this stack, STKPTR is incremented and when one is popped, STKPTR is    */
/*  decremented.  When STKPTR is zero, the Return Address Stack is considered empty.  Thus, STKPTR      */
/*  indicates the number of entries that are on the Return Address Stack at any given time.             */
/*                                                                                                      */
/*  The next step in pxPortInitialiseStack is to initialize the Return Address Stack section of the px  */
/*  stack for the situation where the associated task is to be run for the first time.  For this, only  */
/*  one Return Address Stack entry is needed, and the value of that entry must be the address of the    */
/*  task itself.                                                                                        */
/*                                                                                                      */
/*  First, the full address is retrieved from the pxCode parameter.                                     */

    ulAddress = ( unsigned portLONG ) pxCode;

/*  TOSL is then saved.                                                                                 */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) ( ulAddress & ( unsigned long ) 0x000000FF );


/*  TOSH is then saved.                                                                                 */

    pxStackPointer++;

    ulAddress >>= 8;

    *pxStackPointer = ( portSTACK_TYPE ) ( ulAddress & ( unsigned long ) 0x000000FF );


/*  TOSU is then saved.                                                                                 */

    pxStackPointer++;

    ulAddress >>= 8;

    *pxStackPointer = ( portSTACK_TYPE ) ( ulAddress & ( unsigned long ) 0x000000FF );


/*  The number of entries that were saved to the px stack is now saved.  Here it is simply 1.           */

    pxStackPointer++;

    *pxStackPointer = ( portSTACK_TYPE ) 1;


/*  pxStackPointer now contains the address of the highest byte in the px stack, or the "top" of the px */
/*  stack.  This is returned by the function.                                                           */


    return pxStackPointer;
}

/********************************************************************************************************/
/********************************************************************************************************/

portBASE_TYPE xPortStartScheduler( void )
{
    /* Setup a timer for the tick ISR is using the preemptive scheduler. */

    while(statusflag.NEW_SPI_DATA != 1); Getdata(&rxdata);    Putdata(&txdata);

    prvSetupTimerAndInterrupts();

    /* Restore the context of the first task to run. */

    portRESTORE_CONTEXT();

    INTCONbits.TMR0IE = portBIT_SET;

    /* When the return is made from this function, the program counter should get loaded with the       */
    /* address of the last task that was set up.                                                        */

    return pdTRUE;
}

/********************************************************************************************************/

void vPortEndScheduler( void )
{
    /* According to Richard Barry, it is unlikely that the scheduler for the PIC port will get stopped  */
    /* once it is running.  If as stop is required, one should disable the tick interrupt here, and     */
    /* then return to xPortStartScheduler().                                                            */
}

/********************************************************************************************************/
/********************************************************************************************************/

void vPortYield( void )
{
    portDISABLE_INTERRUPTS();

    PIR1bits.CCP1IF = 0;                   // Clear Timer 1 capture interrupt flag

    portSAVE_CONTEXT();

    vTaskSwitchContext();

    portRESTORE_CONTEXT();

    portENABLE_INTERRUPTS();
}

/********************************************************************************************************/

void vPortEnterCritical( void )
{
    portDISABLE_INTERRUPTS();

    uxCriticalNesting++;
}

/********************************************************************************************************/

void vPortExitCritical( void )
{
    uxCriticalNesting--;

    if(uxCriticalNesting == 0)
    {
        portENABLE_INTERRUPTS();
    }
}

/********************************************************************************************************/
/********************************************************************************************************/

/* Vector for Low Priority ISR. */

#pragma code LowPriorityInterruptVector = 0x000818

static void InterruptVectorLow( void )
{
    _asm    goto LowPriorityInterruptHandler    _endasm
}
#pragma code


/* Vector for High Priority ISR. */

/* The code for the High Priority ISR is contained in Vex_library.lib .                                 */

/********************************************************************************************************/

#pragma interruptlow LowPriorityInterruptHandler

static void LowPriorityInterruptHandler (void)
{
    if( INTCONbits.TMR0IF )
    {
        prvTimerZeroOverflowISR();
    }
    else if ( PIR1bits.CCP1IF )
    {
        prvTickISR();
    }
    else if ( INTCON3bits.INT2IF )
    {
        prvExternalInterruptISR();
    }
    else if ( PIR3bits.RC2IF )
    {
        vSerialRxISR();
    }
    else if ( PIR3bits.TX2IF )
    {
        vSerialTxISR();
    }
    else
    {
    }
}


/********************************************************************************************************/
/********************************************************************************************************/

/* Interrupt Event and Processing Sequence                                                              */

static void prvTimerZeroOverflowISR( void )
{
    INTCONbits.TMR0IF = 0;                 // Clear Timer 0 overflow interrupt flag

    TMR1H = ( unsigned char ) 0x00;        // Reset Timer 1 to zero
    TMR1L = ( unsigned char ) 0x00;

    PIR1bits.CCP1IF   = 0;                 // Clear Timer 1 capture interrupt flag to prevent immediate firing

    PIE1bits.CCP1IE   = 1;                 // Enable Timer 1 capture interrupt

    T1CONbits.TMR1ON  = 1;                 // Start Timer 1
}

/********************************************************************************************************/

static void prvTickISR( void )
{
    PIR1bits.CCP1IF   = 0;                 // Clear Timer 1 capture interrupt flag

    PIE1bits.CCP1IE   = 0;                 // Disable Timer 1 capture interrupt

    T1CONbits.TMR1ON  = 0;                 // Stop Timer 1

    TMR1H = ( unsigned portCHAR ) 0x00;
    TMR1L = ( unsigned portCHAR ) 0x00;

    while(statusflag.NEW_SPI_DATA != 1);

    Getdata(&rxdata);

    //pwm01 = PWM_in1;                     // This is handled by the data exchange
                                           // between the two tasks to demonstrate
                                           // the use of the pvParam pointer.

    Putdata(&txdata);

    portSAVE_CONTEXT( );

    vTaskIncrementTick();

    #if configUSE_PREEMPTION == 1
    {
        vTaskSwitchContext();
    }
    #endif

    portRESTORE_CONTEXT();

    INTCONbits.TMR0IE = portBIT_SET;
}

/********************************************************************************************************/
/********************************************************************************************************/

void prvSetupTimerAndInterrupts( void )
{
    unsigned portLONG ulCompareValue;
    unsigned portCHAR ucByte;

    TMR1H = ( unsigned portCHAR ) 0x00;    // Although Timer 1 is set to zero each time that
    TMR1L = ( unsigned portCHAR ) 0x00;    // the Timer 0 Overflow ISR runs, we include these
                                           // here for instructive purposes.

    uxCriticalNesting  = 0;                // This is for tracking of interrupt nesting by the
                                           // vPortEnterCritical and vPortExitCritical
                                           // functions used by FreeRTOS.

    ulCompareValue     = 17000;            // This value was chosen such that a Timer 1 Capture
                                           // Interrupt will happen 4000 microseconds after the
                                           // Timer 1 is started.  We start Timer 1 in the
                                           // Timer 0 Overflow ISR.  This is all done so that
                                           // the Timer 1 Capture Interrupt will happen a few
                                           // microseconds before the Vex library code says
                                           // that new data are ready for reading by Getdata.

    CCPR1L             = ( unsigned portCHAR ) ( ulCompareValue & ( unsigned portLONG ) 0xff );

    ulCompareValue     >>= ( unsigned portLONG ) 8;

    CCPR1H             = ( unsigned portCHAR ) ( ulCompareValue & ( unsigned portLONG ) 0xff );

    CCP1CONbits.CCP1M0 = portBIT_CLEAR;    // These configure the Capture system to mark a
    CCP1CONbits.CCP1M1 = portBIT_SET;      // capture event when the Timer 1 counter value
    CCP1CONbits.CCP1M2 = portBIT_CLEAR;    // reaches the value in CCPR1.  When this occurs
    CCP1CONbits.CCP1M3 = portBIT_SET;      // the Timer 1 Capture Interrupt will happen.

    RCONbits.IPEN      = portBIT_SET;      // Interrupt Priority Enable. Default is 1 but
                                           // we have here anyway for instructive purposes

    INTCONbits.RBIE    = portBIT_CLEAR;    //

    INTCONbits.RBIF    = portBIT_CLEAR;    //

    INTCONbits.INT0IF  = portBIT_CLEAR;    //

    INTCON2bits.TMR0IP = portBIT_CLEAR;    // Make Timer 0 Overflow Interrupt a low priority
                                           // interrupt

    INTCONbits.TMR0IE  = portBIT_SET;      // Enable Timer 0 Overflow Interrupt so that it is
                                           // ready when the first Timer 0 Overflow happens

    INTCONbits.TMR0IF  = portBIT_CLEAR;    // Clear Timer 0 Overflow Interrupt Flag so that
                                           // the Timer 0 Interrupt ISR does not run
                                           // prematurely.

    IPR1bits.CCP1IP    = portBIT_CLEAR;    // Make Timer 1 Capture Interrupt a low priority
                                           // interrupt

    PIE1bits.CCP1IE    = portBIT_CLEAR;    // We want to start with the Timer 1 Capture
                                           // Interrupt disabled, as we will enable it in the
                                           // Timer 0 Overflow ISR.

    INTCONbits.TMR0IF  = portBIT_CLEAR;    // Clear Timer 1 Capture Interrupt Flag so that
                                           // the Timer 1 Capture ISR does not run
                                           // prematurely.


    /* Set up External INT2 Interrupt */


    INTCON2bits.INTEDG2  = portBIT_CLEAR;  // Have External Interrupt 2 get triggred on a low-
                                           // going edge on the input (INT2) pin of the chip

    INTCON3bits.INT2IP   = portBIT_CLEAR;  // Make External Interrupt 2 a low priority
                                           // interrupt

    INTCON3bits.INT2IE   = portBIT_SET;    // Enable External Interrupt 2

    INTCON3bits.INT2IF   = portBIT_CLEAR;  // Clear External Interrupt 2 flag so that
                                           // the External Interrupt ISR does not run
                                           // prematurely

    /* The following is a call to "OpenTimer1" in "\mcc18\src\extended\pmc\Timers\t1open.c" with        */
    /* reference to "\mcc18\h\timers.h" for the parameters that configure the timer, where these        */
    /* parameters are:                                                                                  */
    /*                                                                                                  */
    /* T1_16BIT_RW      = 0b11111111 for 16 bit mode                                                    */
    /* T1_SOURCE_INT    = 0b11111101 for Internal clock source                                          */
    /* T1_PS_1_2        = 0b11011111 for 1:2 prescale value                                             */
    /* T1_CCP1_T3_CCP2  = 0b10111111 for having Timer 1 be the source for the Capture 1 Interrupt       */
    /*                                                                                                  */
    /* For some unknown reason, T1_CCP1_T3_CCP2 is not recognized, so we define it below.               */

    #define T1_CCP1_T3_CCP2 0b10111111

    OpenTimer1( T1_16BIT_RW & T1_SOURCE_INT & T1_PS_1_2 & T1_CCP1_T3_CCP2 );

    T1CONbits.TMR1ON   = portBIT_CLEAR;    // We start Timer 1 in the Timer 0 Overflow ISR.

    INTCONbits.GIEH    = portBIT_SET;

    INTCONbits.GIEL    = portBIT_SET;
}


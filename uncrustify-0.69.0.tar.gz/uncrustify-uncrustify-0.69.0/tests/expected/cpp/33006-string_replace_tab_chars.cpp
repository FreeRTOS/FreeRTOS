void f() {
	auto x = "	test\t 	 	 		...   ???";
}

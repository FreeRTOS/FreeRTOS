#include <stdlib.h>
#include <stdio.h>
#include <sys/exception.h>
#include <signal.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/******** Processor specific ********/
#include <cdefBF561.h>
#include "ezkit_561.h"


#define STACK_SIZE 			(400)		// stack size in # of entries

typedef struct task_params_list
{
	int LED;
	xSemaphoreHandle  event;
}task_params_list_t;

/*********************************************************************
Global variables
*********************************************************************/
xSemaphoreHandle LED0_semaphore;
xSemaphoreHandle LED5_semaphore;

task_params_list_t params[] = 
	{ 	// LED#, pointer to event
		{	1, 	(xSemaphoreHandle )0},
		{	2, 	(xSemaphoreHandle )0},
		{	3, 	(xSemaphoreHandle )0},
		{	4, 	(xSemaphoreHandle )0},
		{	5, 	(xSemaphoreHandle )0},
		{	6,  (xSemaphoreHandle )0}
	};

//--------------------------------------------------------------------------
// Function:	app_init											
//																			
// Parameters:	None														
//																			
// Return:		None														
//																			
// Description:	Initialization function of a given application. Called from
// main() of the test (before uC/OS-II has been started)
//--------------------------------------------------------------------------
void app_init(void)
{
	EZKit_Init_Flags();
	EZKit_Init_Interrupts();

	// Create 2 semaphores for 2 LEDs that will toggled through push buttons
	vSemaphoreCreateBinary( LED0_semaphore );
	vSemaphoreCreateBinary( LED5_semaphore );
	params[0].event = LED0_semaphore;
	params[5].event = LED5_semaphore;
}// end of app_init

//--------------------------------------------------------------------------
// Function:	LED_blink_thread											
//																			
// Parameters:	None														
//																			
// Return:		None														
//																			
// Description:	This function Blinks LED#x and then either pends on a 
//              semaphore or waits for a few ticks
//--------------------------------------------------------------------------
static portTASK_FUNCTION(LED_blink_thread, Param)
{
	task_params_list_t *p = (task_params_list_t *)Param;
	int lite = p->LED;
	xSemaphoreHandle sem = p->event;

    if (sem != (xSemaphoreHandle)0)					// is the semaphore pointer is valid
	{
		while(1)
		{
		    // Button task: sem is non-NULL, pend on it for ever
        	while( xSemaphoreTake( sem, portMAX_DELAY ) != pdTRUE ); 			
			EZKit_Set_LED(lite);						// turn on a single LED passed as arg.
        	
			while( xSemaphoreTake( sem, portMAX_DELAY ) != pdTRUE );
			EZKit_Clear_LED(lite);						// turn off a single LED passed as arg.
        	
		} // end of while(1)
	}
	else
	{
		while(1) 
		{
		    //LED loop tasks: sem is NULL, yield the processor for a little while
			vTaskDelay(lite*10);
			EZKit_Set_LED(lite);						// turn on a single LED passed as arg.
			vTaskDelay(lite*10);
			EZKit_Clear_LED(lite);						// turn off a single LED passed as arg.
		} // end of while (1)
	}

}// end of LED_blink_thread

//--------------------------------------------------------------------------
// Function:	app_launch_threads											
//																			
// Parameters:	None														
//																			
// Return:		None														
//																			
// Description:	This is called from app_main and launches 
// the application threads.
//--------------------------------------------------------------------------
void app_launch_threads(void)
{
	portBASE_TYPE OS_result;
	int i;
		
	// -------------------------------------------------------------
	// Task Priority: 5
	// Description - Toggles LED#13 and then pends on semaphore LED5_sem

	// Task Priorities: 6, 7, 8 and 9
	// Description - 
	// Toggle LED#14, #15, #16 and #17 and sleep for 
	// 6, 7, 8 and 9 ticks respectively

	// Task Priority: 10
	// Description - Toggles LED#18 and then pends on semaphore LED10_sem
	for ( i=0; i<6; i++ )
	{
		if (xTaskCreate(LED_blink_thread, 
							"LED tasks", 
							400,  //300 x 4 bytes
							(void *)&params[i], 
							i + 1,
							(xTaskHandle *) NULL) != pdPASS)
			while(1); 
	}

}// end of app_launch_threads

void SW6_push_button_Callback (void) 
{
	*pFIO0_FLAG_C = (1 << 5);  // clear button state
	asm volatile ("SSYNC;");
	xSemaphoreGiveFromISR(LED0_semaphore, pdFALSE);
}


void SW7_push_button_Callback (void) 
{
    *pFIO0_FLAG_C = (1 << 6);
	asm volatile ("SSYNC;");
	xSemaphoreGiveFromISR(LED5_semaphore, pdFALSE);
}

void IVG11_ISR_Hook (void) 
{
	if (*pFIO0_FLAG_D & (1<<5))				// if PF5 is interrupting source,
		SW6_push_button_Callback();			// call SW6 callback

	if (*pFIO0_FLAG_D & (1<<6))				// if PF6 is interrupting source,
		SW7_push_button_Callback();			// call SW7 callback
}// end of IVG12_ISR_Hook
	


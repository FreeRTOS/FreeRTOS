uint32_t foo ( uint8_t             param1
               , some_datatype     param2
               , datatype          param3
               , another_datatype *param4
               , uint16_t          param5
               , uint32_t *        param6
               );
namespace dudeNamespace { class ForwardFooClass; }

namespace dudeNamespace { class ForwardFooClass; }

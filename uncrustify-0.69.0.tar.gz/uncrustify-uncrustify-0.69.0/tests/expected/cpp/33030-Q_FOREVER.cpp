void Cache::collection()
{
    Q_FOREVER {
        a = 5;
    }
}

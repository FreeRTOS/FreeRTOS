#include "FreeRTOS.h"

#include <stdio.h>

#include "swi.h"

//
//
//
#define LED2 GPIO_IO_P11

//
//
//
void swiInit (void)
{
}

int swiDispatchC (unsigned long r0, unsigned long r1 __attribute__ ((unused)), unsigned long r2 __attribute__ ((unused)), unsigned long swi)
{
  int state = 0;

  switch (swi)
  {
    case SWICALL_YIELDPROCESSOR :
    case SWICALL_A_LED2SET :
    case SWICALL_A_LED2ON :
    case SWICALL_A_LED2OFF :
    case SWICALL_A_LED2TOGGLE :
      printf ("Eeek!  This should have been handled in the asm code\n");
      break;

    case SWICALL_C_LED2SET :
      {
        state = GPIO0_IOPIN & LED2;

        if (r0)
          GPIO0_IOSET = LED2;			
        else
          GPIO0_IOCLR = LED2;
      }
      break;

    case SWICALL_C_LED2ON :
      {
        state = GPIO0_IOPIN & LED2;
        GPIO0_IOCLR = LED2;			
      }
      break;

    case SWICALL_C_LED2OFF :
      {
        state = GPIO0_IOPIN & LED2;
        GPIO0_IOSET = LED2;			
      }
      break;

    case SWICALL_C_LED2TOGGLE :
      {
        if ((state = GPIO0_IOPIN & LED2))
          GPIO0_IOCLR = LED2;
        else
          GPIO0_IOSET = LED2;			
      }
      break;

    default :
      printf ("Eeek! Unhandled SWI value\n");
      break;
  }

  return state;
}

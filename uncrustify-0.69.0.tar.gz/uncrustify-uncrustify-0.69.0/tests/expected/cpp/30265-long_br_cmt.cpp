
namespace a::b
{
   void foo::bar(int xx)
   {
      switch (xx)
      {
      case 1:
         // filler
         while (true)
         {
            if (something)
            {
               do_something();
            }
            else if (something_else)
            {
               do_something_else();
            }
            else
            {
               dont_do_anything();
               break;
            }
         }
         break;

      case 2:
         handle_two();

      default:
         handle_the_rest();
         break;
      } // switch
   } // foo::bar

   class long_class
   {
 private:
      int m_a;
      int m_name;

 public:
      long_class(int a) {}

      void f1() {}

      void f2() {}

      void f3() {}
   }; // class long_class
} // namespace a::b

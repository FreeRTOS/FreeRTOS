/******************************************************************************
 *
 * Example Program       for R32C/111     FreeRTOS
 *
 * author                f.daners@swissworld.com
 *                       Felix Daners Engineering
 *                       Speerstrasse 32
 *                       8200 Schaffhausen
 *                       Switzerland
 *
 * platform              This program runs on
 *                       EVBR32C111-Carrier-USB
 *                       by Glyn GmbH & Co KG, Microcontroller Group
 *                       Distribution:
 *                       Elektor-Verlag GmbH
 *                       Systerfeldstrasse 25
 *                       52072 Aachen
 *                       Product: R32C/111-Starterkit (080928-91)
 *
 *****************************************************************************
 *
 * !!! THIS FILE IS LICENSED SEPARATELY FROM FREERTOS !!!
 *
 * Copyright (c) 2009, Felix Daners Engineering, Switzerland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * - Neither the name of the Felix Daners Engineering nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#pragma language=extended

#include <ior32c111.h>
#include <intrinsics.h>

//-----------------------------------------------------------------------------
// Function   : __low_level_init()
// Description: initializes the processor and its peripherals
// Parameter:   none
// Return:      none
//-----------------------------------------------------------------------------

__intrinsic int __low_level_init(void)
{
    // Crystal is 8MHz
    // PLL set up to output 96MHz
    // Choose CPU Clock of 96MHz/2
    // Peripherial Clock   96MHz/4
    // Base Clock          96MHz/2

    prcr = 0xFF;    // enable write to control registers

    ebc1 = 0x00;    // external bus control
    ebc2 = 0x00;    // external bus control
    //ebc3 = 0x00;    // external bus control

    pm0 = 0x00;     // XXXX XXXX  // Memory Expansion Mode
                    // |||| ||++- Processor mode bit
                    // |||| ||    00: Single-chip mode
                    // |||| ||    01: Memory expansion mode
                    // |||| ||    10: Do not use this combination
                    // |||| ||    11: Microprocessor mode
                    // |||| |+--- R/W mode select bit   0: /RD, /BHE, /WR     1: /RD, /WRH, /WRL
                    // |||| +---- Software reset bit  The device is reset when this bit is set to '1'. (fclk/8)
                    // |+++------ Reserved, write 0
                    // +----------BCLK output disable bit 0: BCLK is output  1: BCLK is not output


    prcr2 = 0x80;   // enable write to CM3 register

    prr = 0xAA;     // enable write to CCR, FMCR, PBC register
                    // value depends on setting of CCR register

    pm2 |= 0x40;    // 0X0X 00X0 processor mode register 2: enable clock change
                    //  | |   +- PM21 System Clock Protect Bit, 0: Protect Clock by PRCR Register, 1:Disable Change
                    //  | +----- PM24 NMI Enable Bit, 0:NMI Disabled 1:NMI Enabled
                    //  +------- f2n Clock Source Select Bit: 0:Peripherial clock Source, 1:Main Clock
                    // Notes:
                    // 1. This register should be rewritten after the PRC1 bit in the PRCR register is set to 1 (write enabled).
                    // 2. Once this bit is set to 1, it cannot be set to 0 by a program.
                    // 3. When the PM21 bit is set to 1, the following bits are not changed by a write access:
                    //    CM02 bit in the CM0 register (the peripheral clock state in wait mode)
                    //    CM05 bit in the CM0 register (start main clock oscillator running)
                    //    CM10 bit in the CM1 register (start PLL clock oscillator running)
                    //    CM20 bit in the CM2 register (oscillator stop detection enabled/disabled)
                    // 4. When the PM24 bit is set to 0 (NMI disabled), the forced cutoff of the three-phase
                    //    motor control timers is not available.


    cm0 = 0x00;     // 0XXX XXXX  // Output f1
                    //  ||| ||++- Clock Output Function Select 0:P_53, 1:fC, 2:f8, 3:f32
                    //  ||| |+--- Peripherial Clock Stop Bit 0: not stopped, 1: stopped
                    //  ||| +---- XCIN-XCOUT Drive Capability: 0:Low, 1:High
                    //  ||+------ Port XC Switch Bit: 0:I/O Port, 1:XCIN-XCOUT oscillator
                    //  |+------- Main Clock Oscillator (XINXOUT) Stop Bit, 0: Start, 1:Stop
                    //  +-------- Watchdog Timer Function select: 0: Interrupt, 1:Reset

    cm1 = 0x20;     // 0XX0 000X  // XIN-XOUT Drive High
                    //  ||     +- PLL Clock Oscillator Stop, 0:Start, 1:Stop
                    //  xx------- XIN-XOUT Drive Power, 0:Low, 1:High, 2:Superlow, 3:do not use

    cm2 = 0x00;     // 0000 XX0X  // Enable main clock,do not detect stop
                    //      || +- Oscillator Stop Detection Enable, 0:Disabled, 1:Enabled
                    //      |+--- Oscillator Stop Detection Flag, 0:Never stopped, 1: stop detected
                    //      +---- Main clock Monitor Flag, 0:Main Clock Oscillator active, 1:stopped

    cm3 = 0x02;     // 0000 00XX  // low speed mode clock control register
                    //        ++- Low Speed Mode Base Clock Select Bit, 0:fC, 1:f256, 2:fOCO4, 3:reserved

    // R32C/111 Group Hardware Manual
    // Table 8.2 PLC1 and PLC0 Register Settings
    // Main Clock | r | Reference   |  n |  a |  m | PLC1 | PLC0 |  m/r | PLL Clock
    // [MHz]      |   | Clock [MHz] |    |    |    |      |      |      | MHz
    // -----------+---+-------------+----+----+----+------+------+------+-----------
    //          4 | 2 |           2 |  9 |  3 | 48 |  01h |  68h |   24 |  96
    //          6 | 2 |           3 |  6 |  2 | 32 |  01h |  45h |   16 |  96
    // -->      8 | 3 |      2.6667 |  7 |  1 | 36 |  02h |  26h |   12 |  96 <--
    //         10 | 5 |           2 |  9 |  3 | 48 |  04h |  68h |  9.6 |  96
    //         12 | 4 |           3 |  6 |  2 | 32 |  03h |  45h |    8 |  96
    //         16 | 5 |         3.2 |  6 |  0 | 30 |  04h |  05h |    6 |  96
    //          4 | 1 |           4 |  5 |  0 | 25 |  00h |  04h |   25 | 100
    //          6 | 3 |           2 | 10 |  0 | 50 |  02h |  09h | 50/3 | 100
    //          8 | 2 |           4 |  5 |  0 | 25 |  01h |  04h | 25/2 | 100
    //         10 | 3 |      3.3333 |  6 |  0 | 30 |  02h |  05h |   10 | 100
    //         12 | 3 |           4 |  5 |  0 | 25 |  02h |  04h | 25/3 | 100
    //         16 | 4 |           4 |  5 |  0 | 25 |  03h |  04h | 25/4 | 100
    //          4 | 1 |           4 |  6 |  0 | 30 |  00h |  05h |   30 | 120
    //          6 | 2 |           3 |  8 |  0 | 40 |  01h |  07h |   20 | 120
    //          8 | 2 |           4 |  6 |  0 | 30 |  01h |  05h |   15 | 120
    //         10 | 3 |      3.3333 |  7 |  1 | 36 |  02h |  26h |   12 | 120
    //         12 | 3 |           4 |  6 |  0 | 30 |  02h |  05h |   10 | 120
    //         16 | 4 |           4 |  6 |  0 | 30 |  03h |  05h |  7.5 | 120
    //          4 | 1 |           4 |  6 |  2 | 32 |  00h |  45h |   32 | 128
    //          6 | 3 |           2 | 12 |  4 | 64 |  02h |  8Bh | 64/3 | 128
    //          8 | 2 |           4 |  6 |  2 | 32 |  01h |  45h |   16 | 128
    //         10 | 5 |           2 | 12 |  4 | 64 |  04h |  8Bh | 12.8 | 128
    //         12 | 3 |           4 |  6 |  2 | 32 |  02h |  45h | 32/3 | 128
    //         16 | 4 |           4 |  6 |  2 | 32 |  03h |  45h |    8 | 128
    prcr = 0xFF;    // enable write to control registers
    plc0 = 0x26;
    prcr = 0xFF;    // enable write to control registers
    plc1 = 0x02;
    seo = 0;        // pll mode

    __delay_cycles(0x1000);


    ccr = 0x1C;     // X0XX XXXX  // clock control register
                    // | || ||++- Base Clock Divide Ratio Select Bit,
                    // | || ||    0:Divide-by-6, 1:Divide-by-4, 2:Divide-by-3, 3:Divide-by-2
                    // | || ++--- CPU Clock Divide Ratio Select Bit,
                    // | ||       0:Divide-by-4, 1:Divide-by-3, 2:Divide-by-2, 3:No division
                    // | ++------ Peripheral Bus Clock Divide Ratio Select Bit PCD1, PCD0
                    // |          0:Do not use this combination, 1:Divide-by-2, 2:Divide-by-3, 3:Divide-by-4
                    // +--------- Base Clock Source Select Bit
                    // Notes:
                    // 1. This register should be rewritten after the value of PRR register is set to AAh (write enabled).
    ccr = 0x1F;     // 2. The divide ratios of the base clock and peripheral bus clock should not be changed simultaneously.
                    //    Otherwise, the peripheral bus clock frequency may be over the operational maximum. To increase the base
                    //    clock frequency, the divide ratio of the peripheral bus clock should be increased before reducing the divide
                    //    ratio of base clock.
                    // 3. The divide ratio of the CPU clock should be equal to or lower than that of peripheral bus clock.
                    // 4. This bit should be set only once after the reset operation, and the setting should not be changed. To rewrite
                    //    this bit, the PBC register should be rewritten first.
                    // 5. To set this bit to 1, a 32-bit write access to addresses 0004h to 0007h should be performed.
                    // 6. These low speed clocks are switched by setting bits CM31 and CM30 in the CM3 register.



    bcs = 0;        // base clock source is PLL

    prcr = 0xFF;
    pm3 =  0x40;    // 0XX0 0000  // Processor Mode Register 3 // Divide by 4
                    //  ++------- Peripheral Clock Source Divide Ratio Select Bit
                    //            0:Divide-by-8, 1:Divide-by6, 2:Divide-by-4, 3:Divide-by-2

    pm2 &= ~0x02;   // processor mode register 2: disable clock change
    prcr = 0x00;    // disable write to control register


    tcspr = 0x06;   // X000 XXXX  // count source prescaler register
                    // |    ++++- Divide Ratio Select Bit. f2n is either the main clock or
                    // |          peripheral clock source divided by
                    // |          2n. If n = 0, the clock is not divided (n = setting value)
                    // +--------- Divider Operation Enable, 0:Stop divider operation, 1:Start

    tcspr = 0x86;   // X000 XXXX  // count source prescaler register
                    // |    ++++- Divide Ratio Select Bit. f2n is either the main clock or
                    // |          peripheral clock source divided by
                    // |          2n. If n = 0, the clock is not divided (n = setting value)
                    // +--------- Divider Operation Enable, 0:Stop divider operation, 1:Start


    cpsrf = 0x00;   // X000 0000  // clock prescaler reset register
                    // +--------- Clock Prescaler Reset Bit, When this bit is
                    //            set to 1, fC divide-by-32 divider is initialized.
                    //            The bit is read as 0

    pbc =  0x4504;  // 0XXX XXXX 000X XXXX  //Peripheral bus control register
                    //  ||| ||||    +-++++- Read Timing Setting Bit
                    //  ||| ||||            Select from the three options below
                    //  ||| ||||            according to the peripheral bus clock
                    //  ||| ||||            setting (bits PCD1 and PCD0 in the
                    //  ||| ||||            CCR register).
                    //  ||| ||||            When bits PCD1 and PCD0 are set
                    //  ||| ||||            to:
                    //  ||| ||||            1. 01b : 00100b
                    //  ||| ||||            2. 10b : 01101b
                    //  ||| ||||            3. 11b : 01111b
                    //  ||+-++++----------- Write Timing Setting Bit
                    //  ||                  Select from the three options below
                    //  ||                  according to the peripheral bus clock
                    //  ||                  setting (bits PCD1 and PCD0 in the CCR register).
                    //  ||                  When bits PCD1 and PCD0 are set to:
                    //  ||                  1. 01b : 00101b
                    //  ||                  2. 10b : 01010b
                    //  ||                  3. 11b : 01111b
                    //  |+----------------- External Bus Format,
                    //  |                   0:Separate bus in some spaces,
                    //  |                   1:Multiplexed bus in all spaces
                    //  +------------------ External Bus Maximum Width Setting Bit, 0:8bit, 1:16bit

    __set_interrupt_level(0);  // allow all interrupt levels...
    return 1;
}

#pragma language=default

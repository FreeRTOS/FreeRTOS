/** ###################################################################
**     Filename  : RTOSdemo.C
**     Project   : RTOSdemo
**     Processor : MC9S12XEP100MAG
**     Version   : Driver 01.12
**     Compiler  : CodeWarrior HCS12X C Compiler
**     Date/Time : 07.04.08, 14:18
**     Abstract  :
**         Main module.
**         Here is to be placed user's code.
**     Settings  :
**     Contents  :
**         No public methods
**
**     (c) Copyright UNIS, spol. s r.o. 1997-2007
**     UNIS, spol. s r.o.
**     Jundrovska 33
**     624 00 Brno
**     Czech Republic
**     http      : www.processorexpert.com
**     mail      : info@processorexpert.com
** ###################################################################*/
/* MODULE RTOSdemo */

/* Including used modules for compiling procedure */
#include "Cpu.h"
#include "Events.h"
#include "TickTimer.h"
#include "COM0.h"
#include "IV1.h"
#include "Byte1.h"
/* Include shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

extern void vMain( void );

void main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  asm("jmp vMain");

  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END RTOSdemo */
/*
** ###################################################################
**
**     This file was created by UNIS Processor Expert 2.98 [03.98]
**     for the Freescale HCS12X series of microcontrollers.
**
** ###################################################################
*/

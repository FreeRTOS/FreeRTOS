int main()
{
	// Newline inserted between '}' and ')'
	v.push_back({ 2, 3.0 }
	            );
	v.push_back({ 2, 3.0 }
	            );
}

#ifndef _ADC_H_
#define _ADC_H_

int adcRead0_3 (void);
void adcInit (void);

#endif

Here's a quick description of the hardware I used and what the demo software does. I've also included a list of the files I updated (pretty obvious to you I'm sure!!) and I've attached the files themselves.
 
Hardware:
 
The demo is designed to run on the controller board that comes with the JN5139 IEEE802.15.4 Evaluation Kit (JN5139-EK000) or with the JN5139 ZigBee Evaluation Kit (JN5139-EK010). This board contains, amongst other things, a 128x64 pixel LCD display which is used to simulate the 6 LED's required by the demo software. The demo software requires that RX and TX on UART1 are connected, this can be achieved by linking pins 4 & 5 on connector J11 (a 6 pin 0.1" header).
 
Software:
 
The demo was built using development tools that are free to download from Jennic's website. I used version 1.7 of the CLI SDK (JN-SW-4027 SDK with CLI) running on a Windows XP machine. The CLI SDK uses Cygwin to provide a Linux like command line interface for windows (I'm sure you are very familiar with cygwin!!). 
 
The demo software itself is based upon the msp430_GCC demo. It uses the LED flash task from minimal set of demo tasks to flash 3 of the 6 LEDs. LED3 on the LCD is used by the check task. LED's 4 & 5 are used by the serial port tasks which just perform a loopback test using UART1. It also performs integer maths, and polled queue tests.
 
Files added:
 
(following are contained in JN5139.zip)
FreeRTOS\Source\portable\GCC\JN5139\port.c
FreeRTOS\Source\portable\GCC\JN5139\portasm.S
FreeRTOS\Source\portable\GCC\JN5139\portmacro.h
 
(following are contained in JN5139_GCC.zip) FreeRTOS\Demo\JN5139_GCC\main.c FreeRTOS\Demo\JN5139_GCC\makefile FreeRTOS\Demo\JN5139_GCC\FreeRTOSConfig.h
FreeRTOS\Demo\JN5139_GCC\ParTest\ParTest.c
FreeRTOS\Demo\JN5139_GCC\serial\serial.c
 
Files edited:
C:\FreeRTOS\Source\include\portable.h
Added following at line 224:
#ifdef GCC_JN5139
    #include "../../Source/portable/GCC/JN5139/portmacro.h"
#endif
 

My HCS12X was run on a SofTec EVB9S12XEP100 Starter Kit, the HCS12 was run on Technological Arts
Adapt9S12DP256 board.

The original project would not compile on the CW V-4.6. I've tracked it down to one of the compiler Flags 'Optimaization-->Create sub functions with common code', this flag made the HCS12X compiler Go bananas... So I just removed it.

I've introduced a new interrupt vector bean for the vPortYield, so that the manual changes in Vectors.c Could be kept at a minimum.

I've introduced some #ifdef __HCS12X__ instead of make a new sub directory under source\portable\CodeWarrior.
As the HCS12X could remap registers I changed the absolute reference to 0x30 (PPAGE register) with some Global definitions made by CodeWarrior (*pxTopOfStack = PPAGE;). 

The CCR register for HCS12X is 12 bit (2 bytes), the HC12 CCR register is only 8 bit.

Some registers have different names on HCS12 and HCS12X so I made some #define and renamed the registers To some anonymous names... This made the #ifdef blocks in the source to be minimal.

The HCS12 timer setup was wrong. The timer is not an ordinary timer but rather a compare register And a free running timer, when the timer equals the compare register an interrupt is generated. The original Implementation only interrupts at roll over, which I found after toggling a bit in the task switch routine And measure by oscilloscope. There is two possible solutions to this problem:
	1. The whole setup of the timer is regarded as a ProcessorExpert job, we will loose a control
		and the FreeRTOSConfig.h must be keept in sync. When changing Xtal or PLL this could be
		forgotten.
	2. We could try to steal the information from the HC12. When the timer frequency is changed
		the compare register will be updated, if we assign the timer to 0, before the call
		and read the compare register just after the frequency is changed we would get very
		near the correct compare value. The timer will start immedeate so during the bean
		return the timer will have got a value. By measure I found that when the bean gives
		a compare value of 20000, the sw got 20054 which is an error of 0.27%. This solution
		will manage it self, regardless of PLL and Xtal changes and I consider it to be the
		best solution.

The portmacro.h has been extended for the portRESTORE_CONTEXT/portSAVE_CONTEXT. The HCS12X Has a lot of page registers which are all saved.

I also prefer to use printf() to debug kernels, but as this is not in the original source I only did this on a local copy. The standard test which print out the upper case alphabet Don't work with this test so it has to be disabled, and I have not done any investigation to Find out what the problem is.

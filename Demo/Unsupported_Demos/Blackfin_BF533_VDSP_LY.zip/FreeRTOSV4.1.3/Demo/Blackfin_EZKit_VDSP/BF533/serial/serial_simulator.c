#include <stdio.h>

/* we must provide this function to use tinysh
 */
void tinysh_char_out(unsigned char c)
{
  putchar((int)c);
}

class MyClass : public BaseClass
{
    //@{ BaseClass interface
#if VERY_LONG_AND_COMPLICATED_DEFINE
    void foo();
#endif // VERY_LONG_AND_COMPLICATED_DEFINE
    //@}
};
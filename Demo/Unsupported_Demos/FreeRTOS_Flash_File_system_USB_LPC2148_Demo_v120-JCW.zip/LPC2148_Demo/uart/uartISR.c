//
//  Standard includes
//
#include <stdlib.h>

//
//  Scheduler includes
//
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

//
//  Demo application includes
//
#include "uart.h"
#include "uartISR.h"

//
//  Constants to determine the ISR source
//
#define serSOURCE_THRE					  ((unsigned portCHAR) 0x02)
#define serSOURCE_RX_TIMEOUT			((unsigned portCHAR) 0x0c)
#define serSOURCE_ERROR					  ((unsigned portCHAR) 0x06)
#define serSOURCE_RX					    ((unsigned portCHAR) 0x04)
#define serINTERRUPT_SOURCE_MASK	((unsigned portCHAR) 0x0f)

//
//  Queues used to hold received characters, and characters waiting to be transmitted
//
static xQueueHandle xRX0Queue; 
static xQueueHandle xTX0Queue; 
static volatile portLONG lTHREEmpty0;
static xQueueHandle xRX1Queue; 
static xQueueHandle xTX1Queue; 
static volatile portLONG lTHREEmpty1;

//
//
//
void uartISRCreateQueues (portCHAR pxPort, unsigned portBASE_TYPE uxQueueLength, xQueueHandle *pxRX0Queue, xQueueHandle *pxTX0Queue, portLONG volatile **pplTHREEmptyFlag)
{
  switch (pxPort)
  {
    case 0:    
      {
        //
        //  Create the queues used to hold Rx and Tx characters
        //
        *pxRX0Queue = xRX0Queue = xQueueCreate (uxQueueLength, (unsigned portBASE_TYPE) sizeof (signed portCHAR));
        *pxTX0Queue = xTX0Queue = xQueueCreate (uxQueueLength + 1, (unsigned portBASE_TYPE) sizeof (signed portCHAR));

        //
        //  Initialise the THRE empty flag - and pass back a reference
        //
        lTHREEmpty0 = (portLONG) pdTRUE;
        *pplTHREEmptyFlag = &lTHREEmpty0;
      }
      break;

    case 1:
      {
        //
        //  Create the queues used to hold Rx and Tx characters
        //
        *pxRX0Queue = xRX1Queue = xQueueCreate (uxQueueLength, (unsigned portCHAR) sizeof (signed portCHAR));
        *pxTX0Queue = xTX1Queue = xQueueCreate (uxQueueLength + 1, (unsigned portCHAR) sizeof (signed portCHAR));

        //
        //  Initialise the THRE empty flag - and pass back a reference
        //
        lTHREEmpty1 = (portLONG) pdTRUE;
        *pplTHREEmptyFlag = &lTHREEmpty1;	
      }
      break;
  }
}

//
//
//
void uartISR0 (void) __attribute__ ((naked));
void uartISR0 (void)
{
  portENTER_SWITCHING_ISR ();

  signed portCHAR cChar;
  portBASE_TYPE xTaskWokenByTx = pdFALSE;
  portBASE_TYPE xTaskWokenByRx = pdFALSE;

  switch (UART0_IIR & serINTERRUPT_SOURCE_MASK)
  {
    //
    //  Not handling this, but clear the interrupt
    //
    case serSOURCE_ERROR :	
      {
        cChar = UART0_LSR;
      }
      break;

    //
    //  The THRE is empty.  If there is another character in the Tx queue, send it now,
    //  otherwise, no more characters, so indicate THRE is available
    //
    case serSOURCE_THRE	:	
      {
        if (xQueueReceiveFromISR (xTX0Queue, &cChar, &xTaskWokenByTx) == pdTRUE)
          UART0_THR = cChar;
        else
          lTHREEmpty0 = pdTRUE;
      }
      break;

    //
    //  A character was received.  Place it in the queue of received characters
    //
    case serSOURCE_RX_TIMEOUT :
    case serSOURCE_RX	:	
      {
        cChar = UART0_RBR;

        if (xQueueSendFromISR (xRX0Queue, &cChar, (portBASE_TYPE) pdFALSE)) 
          xTaskWokenByRx = pdTRUE;
      }
      break;

    default	:
      break;
  }

  VIC_VectAddr = (unsigned portLONG) 0;

  portEXIT_SWITCHING_ISR ((xTaskWokenByTx || xTaskWokenByRx));
}

//
//
//
void uartISR1 (void) __attribute__ ((naked));
void uartISR1 (void)
{
  portENTER_SWITCHING_ISR ();

  signed portCHAR cChar;
  portBASE_TYPE xTaskWokenByTx = pdFALSE;
  portBASE_TYPE xTaskWokenByRx = pdFALSE;

  switch (UART1_IIR & serINTERRUPT_SOURCE_MASK)
  {
    //
    //  Not handling this, but clear the interrupt
    //
    case serSOURCE_ERROR :
      {
        cChar = UART1_LSR;
      }
      break;

    //
    //  The THRE is empty.  If there is another character in the Tx queue, send it now,
    //  otherwise, no more characters, so indicate THRE is available
    //
    case serSOURCE_THRE	:
      {
        if (xQueueReceiveFromISR (xTX1Queue, &cChar, &xTaskWokenByTx) == pdTRUE)
          UART1_THR = cChar;
        else
          lTHREEmpty1 = pdTRUE;
      }
      break;

    //
    //  A character was received.  Place it in the queue of received characters
    //
    case serSOURCE_RX_TIMEOUT :
    case serSOURCE_RX	:
      {
        cChar = UART1_RBR;

        if (xQueueSendFromISR (xRX1Queue, &cChar, (portBASE_TYPE) pdFALSE)) 
          xTaskWokenByRx = pdTRUE;
      }
      break;

    default	:
      break;
  }

  VIC_VectAddr = (unsigned portLONG) 0;

  portEXIT_SWITCHING_ISR ((xTaskWokenByTx || xTaskWokenByRx));
}

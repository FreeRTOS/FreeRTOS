typedef void (*func)();
typedef void (__stdcall *func)();

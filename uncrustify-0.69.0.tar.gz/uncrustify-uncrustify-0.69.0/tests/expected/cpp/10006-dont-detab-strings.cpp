void f() {
	auto x = "\ttest\t \t \t \t\t...   ???";
// *INDENT-OFF*
	 			auto x = "	test\t 	 	 		...   ???";
// *INDENT-ON*
}

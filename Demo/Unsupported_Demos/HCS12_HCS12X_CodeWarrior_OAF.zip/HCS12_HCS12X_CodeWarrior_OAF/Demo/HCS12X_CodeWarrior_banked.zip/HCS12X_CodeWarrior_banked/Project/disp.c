/*******************************************************************
    Copyright Scanmar AS (C) 2005-06
    All Rights Reserved


    This file contain various smart battery routines


    0.1     12-jan-05    oaf    Initial version

*******************************************************************/


/* 1st include bean specific files */

/* 2nd include library files */
#include <ctype.h>
#include <stdio.h>

#include "ComLib\ComLib.h"


/* 3rd include project specific files */
#include "disp.h"


/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
 #########################################################################
*    Allocate strings in table in FLASH (char *far)
*************************************************************************/
#if defined(__HCS12X__)
    #pragma STRING_SEG  __GPAGE_SEG     .text
    #pragma CONST_SEG   __GPAGE_SEG     .text
#else
    #pragma STRING_SEG  __PPAGE_SEG     .text
    #pragma CONST_SEG   __PPAGE_SEG     .text
#endif



void DI_DispChar(char cl, char cr)
{
    DI_OutputChar(0, cl);
    DI_OutputChar(1, cr);
}

/********************************************************************
*   Private methods from here
********************************************************************/

const unsigned char hexnum_table[][5] =
{
    {
        0x3E,   // ..** ***.
        0x45,   // .*.. .*.*
        0x49,   // .*.. *..*
        0x51,   // .*.* ...*
        0x3E,   // ..** ***.
    },

    {
        0x00,   // .... ....
        0x21,   // ..*. ...*
        0x7F,   // .*** ****
        0x01,   // .... ...*
        0x00,   // .... ....
    },

  0x21, 0x43, 0x45, 0x49, 0x31,       // 2
  0x42, 0x41, 0x51, 0x69, 0x46,       // 3
  0x0C, 0x14, 0x24, 0x7F, 0x04,       // 4
  0x72, 0x51, 0x51, 0x51, 0x4E,       // 5
  0x1E, 0x29, 0x49, 0x49, 0x06,       // 6
  0x40, 0x47, 0x48, 0x50, 0x60,       // 7
  0x36, 0x49, 0x49, 0x49, 0x36,       // 8
  0x30, 0x49, 0x49, 0x4A, 0x3C,       // 9
  0x3F, 0x44, 0x44, 0x44, 0x3F,       // A
  0x7F, 0x49, 0x49, 0x49, 0x36,       // B
  0x3E, 0x41, 0x41, 0x41, 0x22,       // C
  0x7F, 0x41, 0x41, 0x22, 0x1C,       // D
  0x7F, 0x49, 0x49, 0x49, 0x41,       // E
  0x7F, 0x48, 0x48, 0x48, 0x40        // F
};

/* Output a single char, right==1, if right display */
static void DI_OutputChar(int right, char c)
{
}

void f()
{
   uint32 x = (uint8)b;
   uint32 x = (uint16)f(a, b);
   uint32 x = (uint32)std::distance(a, b);
}

#include "FreeRTOS.h"
#include "cpu/cpu.h"

//
//  Olimex board specific.  LEDs are on P0.10, P0.11
//
#define partstFIRST_IO			  ((unsigned portLONG) 0x400)
#define partstNUM_LEDS			  (2)
#define partstALL_OUTPUTS_OFF	((unsigned portLONG) 0xffffffff)

//
//
//
void cpuSetupHardware (void)
{
#ifdef RUN_FROM_RAM
  //
  //  Remap the interrupt vectors to RAM if we are are running from RAM
  //
  SCB_MEMMAP = SCB_MEMMAP_URM;
#endif

  //
  //  Configure the RS2332 pins.  All other pins remain at their default of 0
  //
  PCB_PINSEL0 |= (PCB_PINSEL0_P00_TXD0 | PCB_PINSEL0_P01_RXD0 | PCB_PINSEL0_P08_TXD1 | PCB_PINSEL0_P09_RXD1);

  //
  //  Set all GPIO to output other than the P0.14 (BSL), and the JTAG pins.  
  //  The JTAG pins are left as input as I'm not sure what will happen if the 
  //  Wiggler is connected after powerup - not that it would be a good idea to
  //  do that anyway.
  //
  GPIO0_IODIR = ~(GPIO_IO_P14 | GPIO_IO_P15 | GPIO_IO_P15);
  GPIO1_IODIR = ~GPIO_IO_JTAG;

  //
  //  Setup the PLL to multiply the 12Mhz XTAL input by 4, divide by 1
  //
  SCB_PLLCFG = (SCB_PLLCFG_MUL4 | SCB_PLLCFG_DIV1);

  //
  //  Activate the PLL by turning it on then feeding the correct sequence of bytes
  //
  SCB_PLLCON  = SCB_PLLCON_PLLE;
  SCB_PLLFEED = SCB_PLLFEED_FEED1;
  SCB_PLLFEED = SCB_PLLFEED_FEED2;

  //
  //  Wait for the PLL to lock...
  //
  while (!(SCB_PLLSTAT & SCB_PLLSTAT_PLOCK))
    ;

  //
  //  ...before connecting it using the feed sequence again
  //
  SCB_PLLCON  = SCB_PLLCON_PLLC | SCB_PLLCON_PLLE;
  SCB_PLLFEED = SCB_PLLFEED_FEED1;
  SCB_PLLFEED = SCB_PLLFEED_FEED2;

  //
  //  Setup and turn on the MAM.  Three cycle access is used due to the fast
  //  PLL used.  It is possible faster overall performance could be obtained by
  //  tuning the MAM and PLL settings.
  //
  MAM_TIM = MAM_TIM_3;
  MAM_CR = MAM_CR_FULL;

  //
  //  Setup the peripheral bus to be the same as the PLL output (48Mhz)
  //
  SCB_VPBDIV = SCB_VPBDIV_100;

  //
  //  Disable power to all modules
  //
  SCB_PCONP = 0x0000;

  //
  //
  //
  cpuGPIOInitialize ();
}

//
//
//
void cpuPLLDisable (void)
{
  SCB_PLLCON  = 0;
  SCB_PLLFEED = SCB_PLLFEED_FEED1;
  SCB_PLLFEED = SCB_PLLFEED_FEED2;
  SCB_PLLCFG =  0;
}

//
//
//
void cpuT1Disable (void)
{
  T1_TCR = 0;
  T1_PR = 0;
  T1_MCR = 0;
  T1_CCR = 0;
  T1_EMR = 0;
  T1_CTCR = 0;
  T1_IR = 0;
}

//
//
//
void cpuGPIOInitialize (void)
{
	GPIO0_IOSET = partstALL_OUTPUTS_OFF;
}

void cpuToggleLED (unsigned portBASE_TYPE uxLED)
{
  unsigned portLONG ulLED = partstFIRST_IO;

  if (uxLED < partstNUM_LEDS)
  {
    ulLED <<= (unsigned portLONG) uxLED;

    if (GPIO0_IOPIN & ulLED)
      GPIO0_IOCLR = ulLED;
    else
      GPIO0_IOSET = ulLED;			
  }	
}

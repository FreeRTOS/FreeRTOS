
#include "init.h"

#include <avr32/io.h>
#include <stdint.h>

#include "gpio.h"
#include "usart.h"

//-----------------------------------------------------------------------------

#define SDRAM_CLOCK         HSB_CLOCK
#define SDRAM_REFRESH_TIME  781         // 7.81us
#define SDRAM_REFRESH_RATE  SDRAM_REFRESH_TIME * (SDRAM_CLOCK / 1000) / 100000

// Dual MT48LC16M16A2 (64 MB)
#define SDRAM_ROWS    AVR32_SDRAMC_CR_NR_13_ROW_BITS
#define SDRAM_COLS    AVR32_SDRAMC_CR_NC_9_COLUMN_BITS
#define SDRAM_BANKS   AVR32_SDRAMC_CR_NB_FOUR_BANKS
#define SDRAM_CAS     3
#define SDRAM_TWR     2
#define SDRAM_TRC     7
#define SDRAM_TRP     2
#define SDRAM_TRCD    2
#define SDRAM_TRAS    5
#define SDRAM_TXSR    5
#define SDRAM_DBW     AVR32_SDRAMC_CR_DBW_32_BITS

#define SDRAM_BASE          0x10000000
#define SDRAM_PHYS_ADDR     (SDRAM_BASE | 0xA0000000)
#define SDRAM_SIZE          0x04000000  // 64MB

#define EBI_PIO_DATA_MASK   0xFFFF

//-----------------------------------------------------------------------------

void init_sdram_delay(int us)
{
  const int cnt = us * 140;
  int i;

  for (i = 0; i < cnt; i++)
  {
    asm volatile ("NOP");
  }
}

//-----------------------------------------------------------------------------

void init_sdram(void)
{
  volatile unsigned int v;
  volatile unsigned int *sdram = (unsigned int *)SDRAM_PHYS_ADDR;

  // enable SDRAM mode for CS1 in the bus matrix
  AVR32_HMATRIX.sfr[4] |= 0x0002;
  AVR32_HMATRIX.sfr[4] |= 0x0100;

  // enable EBI bus data bits 16-31
  AVR32_PIOE.pdr = EBI_PIO_DATA_MASK;
  AVR32_PIOE.pudr = EBI_PIO_DATA_MASK;
  AVR32_PIOE.asr = EBI_PIO_DATA_MASK;

  // initialize SDRAM controller
  AVR32_SDRAMC.cr = (SDRAM_COLS   << AVR32_SDRAMC_CR_NC)
                  | (SDRAM_ROWS   << AVR32_SDRAMC_CR_NR)
                  | (SDRAM_BANKS  << AVR32_SDRAMC_CR_NB)
                  | (SDRAM_CAS    << AVR32_SDRAMC_CR_CAS)
                  | (SDRAM_TWR    << AVR32_SDRAMC_CR_TWR)
                  | (SDRAM_TRC    << AVR32_SDRAMC_CR_TRC)
                  | (SDRAM_TRP    << AVR32_SDRAMC_CR_TRP)
                  | (SDRAM_TRCD   << AVR32_SDRAMC_CR_TRCD)
                  | (SDRAM_TRAS   << AVR32_SDRAMC_CR_TRAS)
                  | (SDRAM_TXSR   << AVR32_SDRAMC_CR_TXSR)
                  | (SDRAM_DBW    << AVR32_SDRAMC_CR_DBW);

  // send a NOP to turn on the clock (necessary on some chips)
  AVR32_SDRAMC.mr = AVR32_SDRAMC_MODE_NOP;
  v = AVR32_SDRAMC.mr;
  sdram[0] = 0;

  // Initialization sequence for SDRAM, from the data sheet:
  // 1. A minimum pause of 200 us is provided to precede any signal toggle.
  init_sdram_delay(200);

  // 2. A precharge all command is issued to the SDRAM
  AVR32_SDRAMC.mr = AVR32_SDRAMC_MODE_BANKS_PRECHARGE;
  v = AVR32_SDRAMC.mr;
  sdram[0] = 0;

  // 3. Eight auto-refresh (CBR) cycles are provided
  AVR32_SDRAMC.mr = AVR32_SDRAMC_MODE_AUTO_REFRESH;
  v = AVR32_SDRAMC.mr;
  for (v = 0; v < 8; v++)
    sdram[0] = 0;

  // 4. A mode register set (MRS) cycle is issued to program
  //    SDRAM parameters, in particular CAS latency and burst length.
  //    The address will be chosen by the SDRAMC automatically; we
  //    just have to make sure BA[1:0] are set to 0.
  AVR32_SDRAMC.mr = AVR32_SDRAMC_MODE_LOAD_MODE;
  v = AVR32_SDRAMC.mr;
  sdram[0] = 0;

  // 5. The application must go into Normal Mode, setting Mode
  //    to 0 in the Mode Register and performing a write access
  //    at any location in the SDRAM.
  AVR32_SDRAMC.mr = AVR32_SDRAMC_MODE_NORMAL;
  v = AVR32_SDRAMC.mr;
  sdram[0] = 0;

  // 6. Write refresh rate into SDRAMC refresh timer count
  //    register (refresh rate = timing between refresh cycles).
  AVR32_SDRAMC.tr = SDRAM_REFRESH_RATE;

  init_sdram_delay(200);
}

//-----------------------------------------------------------------------------

void init_clk(void)
{
  // *** initialize external FLASH timing ***
  AVR32_SMC.cs[0].mode = (1 << AVR32_SMC_MODE0_READ_MODE)
                       | (1 << AVR32_SMC_MODE0_WRITE_MODE)
                       | (1 << AVR32_SMC_MODE0_BAT)
                       | (1 << AVR32_SMC_MODE0_DBW)
                       | (3 << AVR32_SMC_MODE0_TDF_CYCLES);

  AVR32_SMC.cs[0].cycle = (13 << AVR32_SMC_CYCLE0_NWE_CYCLE)
                        | (12 << AVR32_SMC_CYCLE0_NRD_CYCLE);

  AVR32_SMC.cs[0].pulse = (6  << AVR32_SMC_PULSE0_NWE_PULSE)
                        | (9  << AVR32_SMC_PULSE0_NCS_WR_PULSE)
                        | (10 << AVR32_SMC_PULSE0_NRD_PULSE)
                        | (11 << AVR32_SMC_PULSE0_NCS_RD_PULSE);

  AVR32_SMC.cs[0].setup = (2 << AVR32_SMC_SETUP0_NWE_SETUP)
                        | (1 << AVR32_SMC_SETUP0_NRD_SETUP);

  // *** initialize PLL 0: 140MHz ***
  AVR32_PM.pll0 = (16      << AVR32_PM_PLL0_PLLCOUNT)
                | ((7 - 1) << AVR32_PM_PLL0_PLLMUL)
                | ((1 - 1) << AVR32_PM_PLL0_PLLDIV)
                | (4       << AVR32_PM_PLL0_PLLOPT)
                | (0       << AVR32_PM_PLL1_PLLOSC)
                | (1       << AVR32_PM_PLLEN);

  // wait for PLL 0 to lock
  while (!(AVR32_PM.isr & AVR32_PM_LOCK0_MASK))
    asm volatile ("NOP");

  // set bus clock
  // CPU clock = PLL / 2^0
  // HSB clock = PLL / 2^1
  // PBA clock = PLL / 2^2
  // PBB clock = PLL / 2^1
  AVR32_PM.cksel = (0 << AVR32_PM_CKSEL_CPUDIV) | (0 << AVR32_PM_CKSEL_CPUSEL)
                 | (1 << AVR32_PM_CKSEL_HSBDIV) | (0 << AVR32_PM_CKSEL_HSBSEL)
                 | (1 << AVR32_PM_CKSEL_PBADIV) | (1 << AVR32_PM_CKSEL_PBASEL)
                 | (1 << AVR32_PM_CKSEL_PBBDIV) | (0 << AVR32_PM_CKSEL_PBBSEL);

  // use PLL 0 as main clock
  AVR32_PM.mcctrl = (1 << AVR32_PM_PLLSEL);
}

//-----------------------------------------------------------------------------

void init_usart(void)
{
  static const gpio_map_t USART_GPIO_MAP =
  {
    { AVR32_USART1_RXD_0_PIN, AVR32_USART1_RXD_0_FUNCTION },
    { AVR32_USART1_TXD_0_PIN, AVR32_USART1_TXD_0_FUNCTION }
  };

  static const usart_options_t USART_OPTIONS =
  {
    .baudrate     = 115200,
    .charlength   = 8,
    .paritytype   = USART_NO_PARITY,
    .stopbits     = USART_1_STOPBIT,
    .channelmode  = USART_NORMAL_CHMODE
  };

  usart_init_rs232(&AVR32_USART1, &USART_OPTIONS, PBA_CLOCK);

  gpio_enable_module(USART_GPIO_MAP, 2);
}

//-----------------------------------------------------------------------------

void sdram_memtest(void)
{
  volatile uint16_t *u16_ptr, u16_data;

  usart_write_line(&AVR32_USART1, "Start MemTest 16\n");

  usart_write_line(&AVR32_USART1, "write\n");
  u16_data = 0;
  for (u16_ptr = (uint16_t *)SDRAM_PHYS_ADDR; u16_ptr < (uint16_t *)(SDRAM_PHYS_ADDR + SDRAM_SIZE); u16_ptr++)
  {
    u16_data += 1;
    *u16_ptr = u16_data;
  }
  usart_write_line(&AVR32_USART1, "done\n");

  init_sdram_delay(100000);

  usart_write_line(&AVR32_USART1, "read\n");
  u16_data = 0;
  for (u16_ptr = (uint16_t *)SDRAM_PHYS_ADDR; u16_ptr < (uint16_t *)(SDRAM_PHYS_ADDR + SDRAM_SIZE); u16_ptr++)
  {
    u16_data += 1;

    if (*u16_ptr != u16_data)
    {
      usart_write_line(&AVR32_USART1, "error\n");
    }
  }
  usart_write_line(&AVR32_USART1, "done\n");

  volatile uint32_t *u32_ptr, u32_data;

  usart_write_line(&AVR32_USART1, "Start MemTest 32\n");

  usart_write_line(&AVR32_USART1, "write\n");
  u32_data = 0;
  for (u32_ptr = (uint32_t *)SDRAM_PHYS_ADDR; u32_ptr < (uint32_t *)(SDRAM_PHYS_ADDR + SDRAM_SIZE); u32_ptr++)
  {
    u32_data += 1;
    *u32_ptr = u32_data;
  }
  usart_write_line(&AVR32_USART1, "done\n");

  init_sdram_delay(100000);

  usart_write_line(&AVR32_USART1, "read\n");
  u32_data = 0;
  for (u32_ptr = (uint32_t *)SDRAM_PHYS_ADDR; u32_ptr < (uint32_t *)(SDRAM_PHYS_ADDR + SDRAM_SIZE); u32_ptr++)
  {
    u32_data += 1;

    if (*u32_ptr != u32_data)
    {
      usart_write_line(&AVR32_USART1, "error\n");
    }
  }
  usart_write_line(&AVR32_USART1, "done\n");
}

//-----------------------------------------------------------------------------

void _init_board(void)
{
  init_clk();
  init_sdram();
  init_usart();

  //sdram_memtest();
}

//-----------------------------------------------------------------------------



#ifndef __FONTS_H
#define __FONTS_H


//#include "stm32f10x_lib.h"

#define FONT_WIDTH	8
#define FONT_HEIGHT	10

#endif /* __LCD_H */

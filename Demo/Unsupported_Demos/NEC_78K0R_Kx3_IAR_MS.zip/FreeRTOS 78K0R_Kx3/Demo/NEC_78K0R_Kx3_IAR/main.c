/*
	FreeRTOS.org V5.0.2 - Copyright (C) 2003-2008 Richard Barry.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

    ***************************************************************************
    ***************************************************************************
    *                                                                         *
    * SAVE TIME AND MONEY!  We can port FreeRTOS.org to your own hardware,    *
    * and even write all or part of your application on your behalf.          *
    * See http://www.OpenRTOS.com for details of the services we provide to   *
    * expedite your project.                                                  *
    *                                                                         *
    ***************************************************************************
    ***************************************************************************

	Please ensure to read the configuration and relevant port sections of the
	online documentation.

	http://www.FreeRTOS.org - Documentation, latest information, license and 
	contact details.

	http://www.SafeRTOS.com - A version that is certified for use in safety 
	critical systems.

	http://www.OpenRTOS.com - Commercial support, development, porting, 
	licensing and training services.
*/

#include <stdlib.h>
#include <string.h>
/* Scheduler include files. */
#include "FreeRTOS.h"
#include "task.h"
/* Demo file headers. */
#include "int78K0R.h"
#include "PollQ.h"
#include "LED.h"
#include "print.h"
#include "semtest.h"

/* 
 * Priority definitions for most of the tasks in the demo application.  Some
 * tasks just use the idle priority. 
 */
#define mainCHECK_TASK_PRIORITY	( tskIDLE_PRIORITY + 2 )
#define mainQUEUE_POLL_PRIORITY	( tskIDLE_PRIORITY + 1 )
#define mainSEMTEST_PRIORITY    ( tskIDLE_PRIORITY + 1 )
#define mainLED_TOGGLE_PRIORITY ( tskIDLE_PRIORITY + 1 )

/* The period between executions of the check task. */
#define mainCHECK_PERIOD	( ( portTickType ) 3000 / portTICK_RATE_MS  )
//#define	CG_OPTION               0x85

/* 
 * 78K0R/Kx3 Option Byte Definition
 * watchdog disabled, LVI enabled, OCD interface enabled
 */
__root __far const unsigned portCHAR OptionByte[OPT_BYTES_SIZE] @ 0x00C0 = {
       WATCHDOG_DISABLED, LVI_ENABLED, RESERVED_FF, OCD_ENABLED};

/* Security Byte Definition */
__root __far const unsigned portCHAR SecuIDCode[SECU_ID_SIZE]   @ 0x00C4 = {
       0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

/* The task function for the "Check" task. */
static void vErrorChecks( void *pvParameters );

/*
 * Checks the unique counts of other tasks to ensure they are still operational.
 */
static void prvCheckOtherTasksAreStillRunning( void );

/* 78K0R/Kx3 low level init Initialization of the System Clock */
int __low_level_init(void);


portSHORT main( void )  
{
        /* Create the standard demo tasks. */
	vStartIntegerMathTasks( tskIDLE_PRIORITY );
	vStartPolledQueueTasks( mainQUEUE_POLL_PRIORITY );
        vStartSemaphoreTasks(mainSEMTEST_PRIORITY); 
        /* Create a easy Port Pin Toggle Task */
        vStartLEDToggleTasks( mainLED_TOGGLE_PRIORITY );
	/* Create the tasks defined within this file. */
	xTaskCreate( vErrorChecks, "Check", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );
	vPrintInitialise();
        /* In this port, to use preemptive scheduler define configUSE_PREEMPTION
         * as 1 in FreeRTOSconfig.h.  To use the cooperative scheduler define
         * configUSE_PREEMPTION as 0.
         */
        vTaskStartScheduler();

	return 0;
}
/*-----------------------------------------------------------*/

static void vErrorChecks( void *pvParameters )
{
static volatile unsigned portLONG ulDummyVariable = 3UL;

        /* The parameters are not used. */
	( void ) pvParameters;

        /* Cycle for ever, delaying then checking all the other tasks are still
         * operating without error.
         */
	for( ;; )
	{
		vTaskDelay( mainCHECK_PERIOD );

                /* Perform a bit of 32bit maths to ensure the registers used by the
                 * integer tasks get some exercise. The result here is not important -
                 * see the demo application documentation for more info.
                 */
		ulDummyVariable *= 3;
		
		prvCheckOtherTasksAreStillRunning();
	}
}
/*-----------------------------------------------------------*/

static void prvCheckOtherTasksAreStillRunning( void )
{
static volatile portBASE_TYPE xErrorHasOccurred = pdFALSE;

	if( xAreIntegerMathsTaskStillRunning() != pdTRUE )
	{
		xErrorHasOccurred = pdTRUE;
	}
	if( xArePollingQueuesStillRunning() != pdTRUE)
	{
		xErrorHasOccurred = pdTRUE;
	}
        if( xAreSemaphoreTasksStillRunning() != pdTRUE)
        {
                xErrorHasOccurred = pdTRUE;
        }     
        if( xAreLEDToggleTaskStillRunning() != pdTRUE)
        {
                xErrorHasOccurred = pdTRUE;
        }
}
/*-----------------------------------------------------------*/
int __low_level_init(void){
        portDISABLE_INTERRUPTS();
        unsigned portCHAR resetflag = RESF;
/* 
 * Clock Configuration: 
 * In this port, to use the internal high speed clock source of the microcontroller
 * define the configCLOCK_SOURCE as 1 in FreeRTOSConfig.h.  To use an external 
 * clock define configCLOCK_SOURCE as 0.
 */ 
#if configCLOCK_SOURCE == 1      
        /*
        * Set XT1 and XT2 in Input Port Mode
        * Set X1  and X2  in Input Port Mode 
        * High speed oszillation frequency 2MHz <= fMX <= 10MHz
        */
        CMC = 0x00;
        /* X1 external oszillation stopped */
        MSTOP = 1;
        /* enable internal high speed oszillation */
        HIOSTOP = 0;
        MCM0 = 0;
        /* stop internal subsystem clock */
        XTSTOP = 1;
        /* Set clock speed */
        CSS = 0;
        CKC &= (unsigned portCHAR)~0x07;
        CKC |= 0x00;
#else
        /* 
        * XT1 and XT2 pin in input port mode
        * X1  and X2  pin in crystal resonator mode      
        * High speed oszillation frequency 10MHz < fMX <= 20MHz  
        */       
        CMC   = 0x41;  
        /* Set oscillation stabilization time */
        OSTS  = 0x07;            
        /* Set speed mode: fMX > 10MHz for Flash memory high speed operation */
        OSMC  = 0x01;             
        /* 
        * Start up X1 oscillator operation
        * Internal high-speed oscillator operating
        */
        MSTOP = 0; 
        /* Check oscillation stabilization time status */
        while(OSTC < 0x07)  
        {
                /* wait until X1 clock stabilization time */
                portNOP();             
        }
        /* Switch CPU clock to X1 oscillator */
        MCM0 = 1;             
        while(MCS != 1)  
        {    
                /* wait until CPU and peripherals operate with fX1 clock */         
                portNOP();
        }
        /* Stop the internal high-speed oscillator operation */
        HIOSTOP = 1;
        /* Stop the XT1 oscillator operation */
        XTSTOP  = 1;
        /* 
        * operating frequency f = fx
        * Change clock generator setting, if necessary 
        */
        CKC &= 0xF8;   
        /* From here onwards the X1 oscillator is supplied to the CPU */
#endif
        portENABLE_INTERRUPTS();
        return pdTRUE;    
}
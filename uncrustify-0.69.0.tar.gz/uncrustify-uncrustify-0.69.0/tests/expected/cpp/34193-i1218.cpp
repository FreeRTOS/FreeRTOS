// Do not add a new line because of the vbrace close that is above col 25
// after return 1;
int main()
{
	if(1)
		return 1;
	return 0;
}
        #define EXTRACTX360ACHIEVEMENT  X360Achievement_INTERNAL& mapping = ExtractMonoObjectData<X360Achievement_INTERNAL>(self); /*huh?*/ \
                                        const XACHIEVEMENT_DETAILS* achievement = xenon::Achievements::GetDetails(mapping.m_index);

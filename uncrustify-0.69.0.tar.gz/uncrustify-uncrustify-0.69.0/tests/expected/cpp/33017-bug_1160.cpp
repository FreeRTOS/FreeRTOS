template<typename T1>
class Class1
{
public:
    status.time_count = duration_cast<::milliseconds>
        (steady_clock::now().time_since_epoch()).count();
};

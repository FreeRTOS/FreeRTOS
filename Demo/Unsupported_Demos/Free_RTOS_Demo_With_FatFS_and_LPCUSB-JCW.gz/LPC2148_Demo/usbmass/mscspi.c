/*****************************************************************************\
*              efs - General purpose Embedded Filesystem library              *
*          --------------------- -----------------------------------          *
*                                                                             *
* Filename : lpc2000_spi.c                                                     *
* Description : This  contains the functions needed to use efs for        *
*               accessing files on an SD-card connected to an LPC2xxx.        *
*                                                                             *
* This library is free software; you can redistribute it and/or               *
* modify it under the terms of the GNU Lesser General Public                  *
* License as published by the Free Software Foundation; either                *
* version 2.1 of the License, or (at your option) any later version.          *
*                                                                             *
* This library is distributed in the hope that it will be useful,             *
* but WITHOUT ANY WARRANTY; without even the implied warranty of              *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           *
* Lesser General Public License for more details.                             *
*                                                                             *
*                                                    (c)2005 Martin Thomas    *
*                                                                             *
\*****************************************************************************/

/*
  2006, Bertrik Sikken, modified for LPCUSB
*/

//
//
//
#include "FreeRTOS.h"

#include "../fatfs/spi.h"

#include "mscspi.h"

//
//
//
#define SELECT_CARD()   do { GPIO0_IOCLR = GPIO_IO_P20; } while (0)
#define UNSELECT_CARD() do { GPIO0_IOSET = GPIO_IO_P20; } while (0)

//
//
//
void mscspiInit (void)
{
  spiInit ();
}

//
//
//
U8 mscspiTransferByte (U8 outgoing)
{
  U8 r;

  spiChipSelect (1);
  r = spiTransferByte (outgoing);
  spiChipSelect (0);

  return r;
}

//
//
//
void mscspiSendBlock (U8 *pbBuf, int iLen)
{
  spiChipSelect (1);
  spiSendBlock (pbBuf, iLen);
  spiChipSelect (0);
}

//
//
//
void mscspiReceiveBlock (U8 *pbBuf, int iLen)
{
  spiChipSelect (1);
  spiReceiveBlock (pbBuf, iLen);
  spiChipSelect (0);
}

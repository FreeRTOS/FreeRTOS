#ifndef _SENSORS_H_
#define _SENSORS_H_

#include "semphr.h"

//
//
//
typedef struct sensorData_s
{
  int  sensorCount;
  int  adcChanges;
}
sensorData_t;

//
//
//
int sensorsCopyData (sensorData_t *dst);
portTASK_FUNCTION_PROTO (vSensorsTask, pvParameters __attribute__ ((unused)));

#endif

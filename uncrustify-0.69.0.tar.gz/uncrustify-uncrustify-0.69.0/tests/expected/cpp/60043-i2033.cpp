/* *INDENT-OFF* */
enum E_SUNSENSOR {
    EXAMPLE1,
    EXAMPLE2,
    SN005
};
/* *INDENT-ON* */

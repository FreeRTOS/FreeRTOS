typedef std::pair<Type* const, TypeB> Object;

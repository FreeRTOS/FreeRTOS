
#ifndef INITIALIZE_SDRAM_AND_CLOCK_H
#define INITIALIZE_SDRAM_AND_CLOCK_H

//-----------------------------------------------------------------------------

#define PLL_CLOCK     140000000
#define HSB_CLOCK     PLL_CLOCK / 2
#define PBA_CLOCK     PLL_CLOCK / 4
#define PBB_CLOCK     PLL_CLOCK / 2

//-----------------------------------------------------------------------------

// ACHTUNG:
// Diese Funktion wird im Assembler-Startcode in der Datei crt0.x aufgerufen.
// Der SDRAM muss initialisiert sein bevor die Compiler-Sektionen in das RAM
// kopiert werden, damit der SDRAM auch f�r anderes als den HEAP f�r malloc
// genutzt werden kann. Das Linker-Skript muss in diesem Fall entsprechend
// angepasst werden.
void _init_board(void);

//-----------------------------------------------------------------------------

#endif

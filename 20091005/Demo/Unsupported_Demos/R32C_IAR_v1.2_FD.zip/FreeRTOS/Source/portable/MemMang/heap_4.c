/*pm--------------------------------------------------------------
 *
 * From the book :
 * Writing Bug-Free C Code
 * A Programming Style That Automatically Detects Bugs in C Code
 * by Jerry Jongerius / January 1995
 *
 * Used to check if all memory from heap is freed whith cleanup
 *
 *
 *  OUTLINE:
 *
 *    This module REPLACES the memory management routines of
 *    the C run-time library.  As such, this new interface
 *    should be used exclusively.
 *
 *  IMPLEMENTATION:
 *
 *    A wrapper is provided around all memory objects that
 *    allows for run-time type checking, symbolic dumps of
 *    the heap and validation of heap pointers.
 *
 *  NOTES:
 *
 *    - YOU must code an FmIsPtrOk() that works properly for
 *      your environment.
 *
 *
 *--------------------------------------------------------------*/


/* PORT TO IAR R32C */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#ifdef __cplusplus
  #define EXTERNC extern "C"
#else
  #define EXTERNC
#endif

#define APIENTRY


typedef void * LPVOID;
typedef char * LPSTR;
typedef char CSCHAR;
typedef unsigned long int SIZET;
#define LOCAL static
typedef unsigned char BOOL;
#define FAR
#define FALSE 0
#define TRUE  1
#define NEAR

typedef struct {
    LPSTR lpVarName;
    } CLASSDESC, FAR*LPCLASSDESC;
#define ISPOWER2(x) (!((x)&((x)-1)))

#define CompilerAssert(expr)       typedef char UNIQUE_NAME[expr]
#define UNIQUE_NAME                     MAKE_NAME(__LINE__)
#define MAKE_NAME(line)                 MAKE_NAME2(line)
#define MAKE_NAME2(line)                constraint_ ## line


/*--- WinAssert support ---*/
#define USEWINASSERT CSCHAR szSRCFILE[]=__FILE__;   \
  BOOL static NEAR _DoWinAssert( int nLine ) {      \
    ReportWinAssert(szSRCFILE, nLine);              \
    WinAssert(nLine);                               \
    return(FALSE);                                  \
    }
#define AssertError _DoWinAssert(__LINE__)
#define WinAssert(exp) if (!(exp)) {AssertError;} else
EXTERNC void APIENTRY ReportWinAssert( LPSTR s, int i)
{
  while(1);
}

/*--- Heap manager prototypes ---*/
EXTERNC LPVOID APIENTRY FmNew      ( SIZET s, LPCLASSDESC p, LPSTR t, int i);
EXTERNC LPVOID APIENTRY FmFree     ( LPVOID );
EXTERNC void   APIENTRY FmWalkHeap ( void );
EXTERNC BOOL   APIENTRY FmIsPtrOk  ( LPVOID );
int APIENTRY FmWalkHeap1( void );

void *pvPortMalloc( size_t xWantedSize )
{
  return FmNew(xWantedSize,NULL,"",0);
}
void vPortFree( void *pv )
{
  FmFree(pv);
}

int GetNumObjectsOnHeap( void )
{
  return FmWalkHeap1();
}

/* END PORT TO IAR */



USEWINASSERT

/*--- Heap objects are aligned on sizeof(int) boundaries ---*/
#define ALIGNMENT (sizeof(long int))
#define DOALIGN(num) (((num)+ALIGNMENT-1)&~(ALIGNMENT-1))
CompilerAssert(ISPOWER2(ALIGNMENT));

/*--- Declare what LPPREFIX/LPPOSTFIX are ---*/
typedef struct tagPREFIX  FAR*LPPREFIX;
typedef struct tagPOSTFIX FAR*LPPOSTFIX;

/*--- Prefix structure before every heap object---*/
typedef struct tagPREFIX {
    LPPREFIX lpPrev;           /* previous object in heap      */
    LPPREFIX lpNext;           /* next object in heap          */
    LPPOSTFIX lpPostfix;       /* ptr to postfix object        */
    LPSTR lpFilename;          /* filename ptr or NULL         */
    long lLineNumber;          /* line number or 0             */
    LPVOID lpMem;              /* FmNew() ptr of object        */
    LPCLASSDESC lpClassDesc;   /* class descriptor ptr or NULL */
    } PREFIX;

/*--- Postfix structure after every heap object ---*/
typedef struct tagPOSTFIX {
    LPPREFIX lpPrefix;
    } POSTFIX;

/*--- Verify alignment of prefix structure ---*/
CompilerAssert(!(sizeof(PREFIX)%ALIGNMENT));

/*--- Points to first object in linked list of heap objects ---*/
static LPPREFIX lpHeapHead=NULL;

/*--- Local prototypes ---*/
void LOCAL AddToLinkedList      ( LPPREFIX );
void LOCAL RemoveFromLinkedList ( LPPREFIX );
BOOL LOCAL VerifyHeapPointer    ( LPVOID );
void LOCAL RenderDesc           ( LPPREFIX, LPSTR );


/*pf--------------------------------------------------------------
 *
 *  DESCRIPTION: (Far Memory New)  JLJ
 *
 *    Allocate a new block of memory from the heap.
 *
 *  ARGUMENTS:
 *
 *    wSize       - Size of object to allocate
 *    lpClassDesc - Class descriptor for object (or NULL)
 *    lpFile      - Filename where object was allocated
 *    nLine       - Line number where object was allocated
 *
 *  RETURNS:
 *
 *    A long pointer to the memory object or NULL
 *
 *--------------------------------------------------------------*/

LPVOID APIENTRY FmNew( SIZET wSize, LPCLASSDESC lpClassDesc,
    LPSTR lpFile, int nLine )
{
  LPPREFIX lpPrefix;
  wSize = DOALIGN(wSize);
  lpPrefix=(LPPREFIX)malloc(sizeof(PREFIX)+wSize+sizeof(POSTFIX));
  if (lpPrefix) {
    AddToLinkedList( lpPrefix );
    lpPrefix->lpPostfix = (LPPOSTFIX)((LPSTR)(lpPrefix+1)+wSize);
    lpPrefix->lpPostfix->lpPrefix = lpPrefix;
    lpPrefix->lpFilename = lpFile;
    lpPrefix->lLineNumber = nLine;
    lpPrefix->lpMem = lpPrefix+1;
    lpPrefix->lpClassDesc = lpClassDesc;
    memset( lpPrefix->lpMem, 0, wSize );
    }
  else {
    AssertError;             /* Report out of memory error */
    }
  return(lpPrefix ? lpPrefix+1 : NULL);

} /* FmNew */


/*pf--------------------------------------------------------------
 *
 *  DESCRIPTION: (Far Memory Free)  JLJ
 *
 *    Free a block of memory that was previously allocated
 *    through FmNew().
 *
 *  ARGUMENTS:
 *
 *    lpMem - Heap pointer to free or NULL
 *
 *  RETURNS:
 *
 *    NULL
 *
 *--------------------------------------------------------------*/

LPVOID APIENTRY FmFree( LPVOID lpMem )
{
    if (VerifyHeapPointer(lpMem)) {
       LPPREFIX lpPrefix=(LPPREFIX)lpMem-1;
       SIZET wSize=(LPSTR)(lpPrefix->lpPostfix+1)-(LPSTR)lpPrefix;
       RemoveFromLinkedList( lpPrefix );
       memset( lpPrefix, 0, wSize );
       free(lpPrefix);
       }
    return (NULL);

} /* FmFree */

/*pf--------------------------------------------------------------
 *
 *  DESCRIPTION: (Num Objects on Heap)  JLJ
 *
 *    Display a symbolic dump of the heap by walking the
 *    heap and displaying all objects in the heap.
 *
 *  ARGUMENTS:
 *
 *    (void)
 *
 *  RETURNS:
 *
 *   number of allocated objects on heap
 *
 *--------------------------------------------------------------*/

int APIENTRY FmWalkHeap1( void )
{
    int n=0;
    if (lpHeapHead) {
        LPPREFIX lpCur=lpHeapHead;
        while (VerifyHeapPointer(&lpCur[1])) {
            ++n;
            lpCur = lpCur->lpNext;
            if (lpCur==lpHeapHead) {
                break;
                }
            }
        }
    return n;
}


/*pf--------------------------------------------------------------
 *
 *  DESCRIPTION: (Walk Heap)  JLJ
 *
 *    Display a symbolic dump of the heap by walking the
 *    heap and displaying all objects in the heap.
 *
 *  ARGUMENTS:
 *
 *    (void)
 *
 *  RETURNS:
 *
 *    (void)
 *
 *--------------------------------------------------------------*/

void APIENTRY FmWalkHeap( void )
{
    if (lpHeapHead) {
        LPPREFIX lpCur=lpHeapHead;
        while (VerifyHeapPointer(&lpCur[1])) {
            char buffer[100];
            RenderDesc( lpCur, buffer );
            /*--- print out buffer ---*/
            //printf( "walk: %s\n", buffer );
            lpCur = lpCur->lpNext;
            if (lpCur==lpHeapHead) {
                break;
                }
            }
        }

} /* FmWalkHeap */


/*p---------------------------------------------------------------
 *
 *  DESCRIPTION: (Add Heap Object to Linked List)  JLJ
 *
 *    Add the given heap object into the doubly linked list
 *    of heap objects.
 *
 *  ARGUMENTS:
 *
 *    lpAdd - Prefix pointer to heap object
 *
 *  RETURNS:
 *
 *    (void)
 *
 *--------------------------------------------------------------*/

void LOCAL AddToLinkedList( LPPREFIX lpAdd )
{
    /*--- Add before current head of list ---*/
    if (lpHeapHead) {
        lpAdd->lpPrev = lpHeapHead->lpPrev;
        (lpAdd->lpPrev)->lpNext = lpAdd;
        lpAdd->lpNext = lpHeapHead;
        (lpAdd->lpNext)->lpPrev = lpAdd;
        }

    /*--- Else first node ---*/
    else {
        lpAdd->lpPrev = lpAdd;
        lpAdd->lpNext = lpAdd;
        }

    /*--- Make new item head of list ---*/
    lpHeapHead = lpAdd;

} /* AddToLinkedList */


/*p---------------------------------------------------------------
 *
 *  DESCRIPTION: (Remove Heap Object from Linked List)  JLJ
 *
 *    Remove the given heap object from the doubly linked list
 *    of heap objects.
 *
 *  ARGUMENTS:
 *
 *    lpRemove - Prefix pointer to heap object
 *
 *  RETURNS:
 *
 *    (void)
 *
 *--------------------------------------------------------------*/

void LOCAL RemoveFromLinkedList( LPPREFIX lpRemove )
{

    /*--- Remove from doubly linked list ---*/
    (lpRemove->lpPrev)->lpNext = lpRemove->lpNext;
    (lpRemove->lpNext)->lpPrev = lpRemove->lpPrev;

    /*--- Possibly correct head pointer ---*/
    if (lpRemove==lpHeapHead) {
        lpHeapHead = ((lpRemove->lpNext==lpRemove) ? NULL :
            lpRemove->lpNext);
        }

} /* RemoveFromLinkedList */


/*p---------------------------------------------------------------
 *
 *  DESCRIPTION: (Verify Heap Pointer)  JLJ
 *
 *    Verify that a pointer points into that heap to a valid
 *    object in the heap.
 *
 *  ARGUMENTS:
 *
 *    lpMem - Heap pointer to validate
 *
 *  RETURNS:
 *
 *    Heap pointer is valid (TRUE) or not (FALSE)
 *
 *--------------------------------------------------------------*/

BOOL LOCAL VerifyHeapPointer( LPVOID lpMem )
{
  BOOL bOk=FALSE;

  if (lpMem) {
    WinAssert(FmIsPtrOk(lpMem)) {
      LPPREFIX lpPrefix=(LPPREFIX)lpMem-1;
      WinAssert(lpPrefix->lpMem==lpMem) {
        WinAssert(lpPrefix->lpPostfix->lpPrefix==lpPrefix) {
          bOk = TRUE;
          }
        }
      }
    }

  return (bOk);

} /* VerifyHeapPointer */


/*pf--------------------------------------------------------------
 *
 *  DESCRIPTION: (Does Pointer Point into the Heap)  JLJ
 *
 *    Does the given memory pointer point anywhere into
 *    the heap.
 *
 *  ARGUMENTS:
 *
 *    lpMem - Heap pointer to check
 *
 *  RETURNS:
 *
 *    Pointer points into the heap (TRUE) or not (FALSE)
 *
 *--------------------------------------------------------------*/

#if (defined(_WINDOWS) || defined(_WINDLL))
BOOL APIENTRY FmIsPtrOk( LPVOID lpMem )
{
    BOOL bOk=FALSE;
    _asm xor ax, ax                  ;; assume bad selector
    _asm lsl ax, word ptr [lpMem+2]  ;; get selector limit
    _asm cmp word ptr [lpMem], ax    ;; is ptr offset under limit
    _asm jae done                    ;; no, bad pointer
    _asm mov bOk, 1                  ;; yes, pointer OK
    _asm done:
    return (bOk);

} /* FmIsPtrOk */
#else
BOOL APIENTRY FmIsPtrOk( LPVOID lpMem )
{
    return ((lpMem) && (!((long)lpMem&(ALIGNMENT-1))));

} /* FmIsPtrOk */
#endif


/*p---------------------------------------------------------------
 *
 *  DESCRIPTION: (Render Description of Heap Object)  JLJ
 *
 *    Render a text description for the given heap object.
 *
 *  ARGUMENTS:
 *
 *    lpPrefix - Prefix pointer to heap object
 *    lpBuffer - Where to place text description
 *
 *  RETURNS:
 *
 *    (void)
 *
 *--------------------------------------------------------------*/

void LOCAL RenderDesc( LPPREFIX lpPrefix, LPSTR lpBuffer )
{
    if (lpPrefix->lpMem==&lpPrefix[1]) {
        sprintf( lpBuffer, "%08lx ", lpPrefix );
        if (lpPrefix->lpFilename) {
            sprintf( lpBuffer+strlen(lpBuffer), "%12s %4ld ",
                lpPrefix->lpFilename, lpPrefix->lLineNumber );
            }
        if (lpPrefix->lpClassDesc) {
            sprintf( lpBuffer+strlen(lpBuffer), "%s",
                lpPrefix->lpClassDesc->lpVarName );
            }
        }
    else {
        strcpy( lpBuffer, "(bad)" );
        }

} /* RenderDesc */

#ifndef _RTCISR_H_
#define _RTCISR_H_

void rtcISRInit (void);
void rtcISR (void);

#endif


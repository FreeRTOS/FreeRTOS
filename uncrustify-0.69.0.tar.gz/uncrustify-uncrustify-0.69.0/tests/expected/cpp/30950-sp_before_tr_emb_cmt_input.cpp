/* leading cmt */ int w;
int y;  /* embedded cmt */ int z;
// whole cpp cmt
int x;  // trailing cpp cmt
/* whole c cmt */
int x;  /* trailing c cmt */
struct foo {  // trailing cmt
  int x;  // trailing cmt
  // whole cmt
  int a;  /* emb cmt */ int b;  // trailing cmt
};  // trailing cmt
int a;  /* emb cmt */ int b;  // trailing cmt

#ifndef _CPU_H_
#define _CPU_H_

void cpuSetupHardware (void);
void cpuPLLDisable (void);
void cpuT1Disable (void);
void cpuGPIOInitialize (void);
void cpuToggleLED (unsigned portBASE_TYPE uxLED);

#endif

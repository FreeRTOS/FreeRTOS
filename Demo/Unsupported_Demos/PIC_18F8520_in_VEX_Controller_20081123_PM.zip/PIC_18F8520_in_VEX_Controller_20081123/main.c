/*  Copyright (c) 2008 by Paul A. Murphy                                                                */
/*                                                                                                      */
/*  The author hereby grants permission to use, copy, modify, distribute, and license this software and */
/*  its documentation for any purpose, provided that existing copyright notices are retained in all     */
/*  copies and that this notice and the following disclaimer are included verbatim in any               */
/*  distributions.  No written agreement, license, or royalty fee is required for any of the authorized */
/*  uses.                                                                                               */
/*                                                                                                      */
/*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR *AS IS* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,   */
/*  BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  */
/*  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,       */
/*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF         */
/*  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER       */
/*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE */
/*  POSSIBILITY OF SUCH DAMAGE.                                                                         */
/*                                                                                                      */
/*                                                                                                      */
/*                                                                                                      */
/*  Demonstration                                                                                       */
/*                                                                                                      */
/*  The handling of two user-generated tasks is demonstrated, in which the first task reads an analog   */
/*  signal and the second tasks sends a modified version of this signal to a motor.                     */
/*                                                                                                      */
/*  The creation and handling of the FreeRTOS queues is also demonstrated, as queues are used to handle */
/*  the serial communications.                                                                          */
/*                                                                                                      */
/*  In addition to the analog signal, the first task also reads a signal from a VEX radio-control       */
/*  receiver.  The first task also reads the controller's serial port.  In addition to sending a        */
/*  command to the motor, the second task sends that command out over the controller's serial port.     */
/*                                                                                                      */
/*  The exchange of the data between the two tasks is provided by means of a common data structure      */
/*  called "myStruct".  In the call to xTaskCreate that is made to set up each of the two tasks, the    */
/*  address of this data structure is passed in by way of the parameter called "pvParam".  In each      */
/*  task, a pointer to the structure type is declared, and then it is set to the value of that address. */
/*  In this way, each task has a pointer to the common data structure.                                  */
/*                                                                                                      */
/*  The demonstration requires that a VEX radio-control receiver be connected to the controller's Rx1   */
/*  jack (Rx2 also works), and that it be receiving signals from a VEX radio-control transmitter.       */
/*                                                                                                      */
/*  For the analog signal, a potentiometer with a resistance of the order of 10 kilohms is needed.      */
/*  This is connected to Port 1 in the "ANALOG/DIGITAL" group of ports on the controller.  The voltage  */
/*  on its wiper arm is read by the command " Get_Analog_Value (0x00) " in the first task.  The voltage */
/*  on this or any of the other inputs should be kept to between 0 and + 5 volts.                       */
/*                                                                                                      */
/*  For the serial communications, the "RX" and "TX" ports, which are also in the "ANALOG/DIGITAL"      */
/*  group of ports, are used.  For RS-232 communications with a computer, a level shifting adapter      */
/*  is needed.                                                                                          */
/*                                                                                                      */
/*  For the output, a VEX motor was used, although any comparable hobby motor can be used.  This        */
/*  demonstration expects that it be connected to Port 1 in the " MOTORS " group of ports.              */
/*                                                                                                      */
/*                                                                                                      */



/* Header files for controller-specific code                                                            */

#include "ifi_picdefs.h"                 // Similar to p18f8520.h from Microchip

#include "ifi_aliases.h"
#include "ifi_default.h"
#include "ifi_utilities.h"
#include "user_routines.h"

/* Header files for FreeRTOS code 																	    */

#include "stddef.h"
#include "FreeRTOSConfig.h"

#include "FreeRTOS.h"
#include "task.h"

#include "serial.h"

#include "queue.h"

/* Defines																								*/

#define	serQUEUE_LENTGH 	30           // Length of queue that holds serial streams


/* Declarations of functions in VEX Starter Code														*/

void 			IFI_Initialization(void);


/* Declarations of tasks written for this demonstration                                                 */

static void		testTask_1( void );      // This function is the first of the two tasks to be demonstrated
static void		testTask_2( void );      // This function is the second of the two tasks to be demonstrated


/* Declaration of a pointer to a data structure that the user can create for intertask communication	*/

extern void 			*pvParam;

/* Type definition of the data structure that will be used for exchanging data between the two tasks.   */

typedef struct
{
	signed char   rxChar;
	signed char   rxCharReceived;
	signed char   txChar;
	signed char   txCharTransmitted;
	unsigned char radioControlSignal;
	unsigned int  adValue;

}
MYSTRUCT;

/* Declaration of VEX Robotics structures for the radio control signals                                 */

/* Note: Please do not confuse the "txdata" and "rxdata" terms with the RS-232 related terms.           */

tx_data_record			txdata;
rx_data_record			rxdata;
packed_struct			statusflag;


/* Declaration of serial port handle for use by code in serial.c for RS-232 communications              */

static 					xComPortHandle xPortHandle;

/* Declarations of user variables                                                                       */

extern unsigned char	rxChar, txChar;

void main ()
{
	static MYSTRUCT myStruct;	         // Declaration of structure used for communication between tasks
	                                     // The address of this will be used by FreeRTOS in each task

	static unsigned long int index;

    char taskName1[] = "task_1";         // A task designation name that FreeRTOS needs for the first task

    char taskName2[] = "task_2";         // A task designation name that FreeRTOS needs for the second task

    xTaskHandle xHandleLocal_1;          // Task handles needed by FreeRTOS for the first task

    xTaskHandle xHandleLocal_2;          // Task handles needed by FreeRTOS for the second task

    IFI_Initialization();                // Initialization function in "Vex_library.lib"

    User_Initialization();               // Initialization function in "user_routines.c"

    vPortInitialiseBlocks();             // Sets a "next free byte" value to zero in FreeRTOS memory allocation

    /* Initialize the RS-232 serial port                                                                     */

    xPortHandle = xSerialPortInitMinimal( (unsigned portLONG) 115200, (unsigned portBASE_TYPE) serQUEUE_LENTGH );

    /* Instruct FreeRTOS to set up the two tasks for the demonstration.                                      */

    xTaskCreate( testTask_1, taskName1, configMINIMAL_STACK_SIZE, (void *) &myStruct, tskIDLE_PRIORITY, xHandleLocal_1);

    xTaskCreate( testTask_2, taskName2, configMINIMAL_STACK_SIZE, (void *) &myStruct, tskIDLE_PRIORITY, xHandleLocal_2);

    /* Start the FreeRTOS scheduler.                                                                         */

    vTaskStartScheduler();

    for (;;)
    {
    }
}

static void testTask_1()
{
	static MYSTRUCT      * psThisStruct1;          // Declare psThisStruct as a pointer to MYSTRUCT

	static portTickType  xLastExecutionTime;       // A running count of the clock tick provided by the
	                                               // Master processor is updated every 18.5 milliseconds
	                                               // In user-created tasks such as this one, this count
	                                               // must is checked and is saved in xLastExecutionTime.

    static char          thisChar;                 // Character that is received by the controller

    static char          thisCharReceived;         // Boolean indicating whether or not a new char was
                                                   // received

    static unsigned int xTimeOutTicks;


    psThisStruct1 = (MYSTRUCT * ) pvParam;         // Set value of pointer to value in pvParam

    xLastExecutionTime = xTaskGetTickCount();

    xTimeOutTicks = (signed int) 5400;

    for (;;)
    {
		psThisStruct1 -> rxCharReceived = xSerialGetChar( xPortHandle, &thisChar, xTimeOutTicks );

		if ( ( psThisStruct1 -> rxCharReceived ) != 0 )
		{
			psThisStruct1 -> rxChar = thisChar;
		}

		psThisStruct1 -> adValue = Get_Analog_Value (0x00);

		psThisStruct1 -> radioControlSignal = PWM_in1;

		vTaskDelayUntil (&xLastExecutionTime, (portTickType) 2);
    }
}

static void testTask_2()
{
	static MYSTRUCT      * psThisStruct2;          // Declare psThisStruct as a pointer to MYSTRUCT

	static portTickType  xLastExecutionTime;       // A running count of the clock tick provided by the
	                                               // Master processor is updated every 18.5 milliseconds
	                                               // In user-created tasks such as this one, this count
	                                               // must is checked and is saved in xLastExecutionTime.

    signed char          thisCharTransmitted;

    static unsigned int  xTimeOutTicks;

	static unsigned int  thisAdValue;

	static unsigned char scaledAdValue;

	static unsigned char tableIndex;

	psThisStruct2 = (MYSTRUCT * ) pvParam;         // Set value of pointer to value in pvParam

    xLastExecutionTime = xTaskGetTickCount();

    xTimeOutTicks = (unsigned int) 5400;

    for (;;)
    {
		thisAdValue = psThisStruct2 -> adValue;

		scaledAdValue = (unsigned char) ( thisAdValue / 4 );

//		pwm01 = thisAdValue = psThisStruct2 -> radioControlSignal;

		pwm01 = scaledAdValue;

		printUnsignedNumberPair((unsigned int) scaledAdValue, (unsigned int) pwm01);

		vTaskDelayUntil (&xLastExecutionTime, (portTickType) 50);
    }
}



class X16
{
X16()                        = delete;
public:
void z(int x   = 0);
virtual void f(int x, int y) = 0;
int hhi = 9;
void g(int x   = 0);
int i   = 9;
void x(int ggs = 0);
};

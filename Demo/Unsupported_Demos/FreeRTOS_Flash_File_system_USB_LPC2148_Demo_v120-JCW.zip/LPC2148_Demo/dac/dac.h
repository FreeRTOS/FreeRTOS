#ifndef _DAC_H_
#define _DAC_H_

void dacInit (void);
unsigned int dacSet (unsigned int newValue);

#endif

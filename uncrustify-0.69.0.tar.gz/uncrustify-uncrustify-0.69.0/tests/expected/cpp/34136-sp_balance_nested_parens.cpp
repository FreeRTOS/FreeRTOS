void MainWindow::createView()
{
        a = B( (c) + (d) );
        a = B( (c) + (d) );
        a = B( (c) + (d) );
}


//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include <avr32/io.h>

#include "init.h"
#include "gpio.h"
#include "usart.h"

#include "FreeRTOS.h"
#include "task.h"

//-----------------------------------------------------------------------------

#define LED1      (1 << 23)
#define LED2      (1 << 24)
#define LED3      (1 << 25)
#define LED4      (1 << 26)
#define LED5      (1 << 27)
#define LED6      (1 << 28)
#define LED7      (1 << 29)
#define LED8      (1 << 30)

#define LED_MASK  (LED1 | LED2 | LED3 | LED4 | LED5 | LED6 | LED7 | LED8)

//-----------------------------------------------------------------------------

void vApplicationTickHook(void)
{
}

//-----------------------------------------------------------------------------

void vApplicationIdleHook(void)
{


}

//-----------------------------------------------------------------------------

void vApplicationStackOverflowHook(xTaskHandle *pxTask, portCHAR *pcTaskName)
{
}

//-----------------------------------------------------------------------------

static portTASK_FUNCTION_PROTO( LedTask, pvParameters );

static portTASK_FUNCTION( LedTask, pvParameters )
{
  portTickType lastWakeTime;
  int state = 0;
  int led, ledMask;

  // The parameters are not used.
  led = (int)pvParameters;
  ledMask = (1 << (led + 22));

  lastWakeTime = xTaskGetTickCount();

  while (1)
  {
    vTaskDelayUntil(&lastWakeTime, led * 125);

    state ^= 1;

    if (state)
      AVR32_PIOA.sodr = ledMask;
    else
      AVR32_PIOA.codr = ledMask;
  }
}

//-----------------------------------------------------------------------------

void _init_startup(void);

int main(void)
{
  AVR32_PIOA.per = LED_MASK;
  AVR32_PIOA.oer = LED_MASK;
  AVR32_PIOA.codr = LED_MASK;

  // initialize FreeRTOS exception and interrupts
  _init_startup();

  xTaskCreate(LedTask, (const signed portCHAR *)"LED1", 512, (void *)1, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);
  xTaskCreate(LedTask, (const signed portCHAR *)"LED2", 512, (void *)2, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);
  xTaskCreate(LedTask, (const signed portCHAR *)"LED3", 512, (void *)3, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);
  xTaskCreate(LedTask, (const signed portCHAR *)"LED4", 512, (void *)4, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);
  xTaskCreate(LedTask, (const signed portCHAR *)"LED5", 512, (void *)5, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);
  xTaskCreate(LedTask, (const signed portCHAR *)"LED6", 512, (void *)6, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);
  xTaskCreate(LedTask, (const signed portCHAR *)"LED7", 512, (void *)7, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);
  xTaskCreate(LedTask, (const signed portCHAR *)"LED8", 512, (void *)8, tskIDLE_PRIORITY + 1, (xTaskHandle *)NULL);

  vTaskStartScheduler();

  while (1)
  {
    asm volatile ("NOP");
  }

  return 0;
}

//-----------------------------------------------------------------------------




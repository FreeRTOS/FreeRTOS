void myClass::foo() {
	int bar;
	std::string str;


	DbConfig::configuredDatabase()->apply(db);

	std::string str2;
	std::string str2;

	f();
	DbConfig::configuredDatabase()->apply(db);

	int bar;
	std::string str;
	std::string str2;

	f();
}
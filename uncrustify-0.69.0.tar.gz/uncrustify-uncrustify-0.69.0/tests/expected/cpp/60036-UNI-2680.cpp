A(B(C(
    D(a |
        b | c))));

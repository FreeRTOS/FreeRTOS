
The files are generated automatically. Therefore they do not contain any comments.

To use one of the fonts simply copy the appropriate C and H file into the project directory and rename them to "fonts.c" respectively "fonts.h".

Additionally you may have to change some parameters and array sizes to adapt your application.



{
        QString fileName = QFileDialog::getOpenFileName(this,
             tr("Choose Configuration File"), ui->leStrategyFile->text(),
             tr("Configuration Files (*.cfg);; All Files (*.*)"), 0);

        pSettings = new QSettings(QCoreApplication::applicationDirPath() + "/" +
             QCoreApplication::applicationName() + ".ini",
             QSettings::IniFormat);
}
int a ()
{
        double a_very_long_variable = test (foobar1,
             foobar5);

        double a_other_very_long = asdfasdfasdfasdfasdf + asdfasfafasdfa +
             asdfasdfasdf - asdfasdf + 56598;

        a_other_very_long = asdfasdfasdfasdfasdf + asdfasfafasdfa +
             asdfasdfasdf - asdfasdf + 56598;

        testadsfa (dfasdf,
             aaafsdfa);
        return 0;
}

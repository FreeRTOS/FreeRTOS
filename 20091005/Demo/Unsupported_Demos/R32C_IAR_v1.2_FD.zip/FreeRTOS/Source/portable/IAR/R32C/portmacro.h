/*! \file *********************************************************************
 *
 * \brief FreeRTOS port header for IAR R32C
 *
 * \author 2009, Felix Daners Engineering. f.daners@swissworld.com
 *
 * All Interupts share ISTACK
 * Tasks use User Stack
 * Interupts (Vectors 0..127) do not use any space on task stack
 *****************************************************************************
 *
 * !!! THIS FILE IS LICENSED SEPARATELY FROM FREERTOS !!!
 *
 * Copyright (c) 2009, Felix Daners Engineering, Switzerland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Neither the name of the Felix Daners Engineering nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/


#ifndef PORTMACRO_H
#define PORTMACRO_H

/* IO definitions for the chosen device. */
#include <ior32c111.h>
#ifndef __IAR_SYSTEMS_ASM__
  #include <intrinsics.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif


/* Type definitions. */
#define portCHAR        char
#define portFLOAT       float
#define portDOUBLE      double
#define portLONG        long
#define portSHORT       short
#define portSTACK_TYPE  unsigned portLONG
#define portBASE_TYPE   portLONG
#define portFLAG_TYPE   unsigned portLONG


#define TASK_DELAY_MS(x)   ( (x)        /portTICK_RATE_MS )
#define TASK_DELAY_S(x)    ( (x)*1000   /portTICK_RATE_MS )
#define TASK_DELAY_MIN(x)  ( (x)*60*1000/portTICK_RATE_MS )

#ifndef __IAR_SYSTEMS_ASM__
  #if ( configUSE_16_BIT_TICKS == 1 )
    typedef unsigned portSHORT portTickType;
	#define portMAX_DELAY ( portTickType ) 0xffff
  #else
    typedef unsigned portLONG portTickType;
	#define portMAX_DELAY ( portTickType ) 0xffffffff
  #endif
#endif
/*-----------------------------------------------------------*/

/* Architecture specifics. */
#define portSTACK_GROWTH      ( -1 )
#define portTICK_RATE_MS      ( ( portTickType ) 1000 / configTICK_RATE_HZ )
#define portBYTE_ALIGNMENT       1
#define portNOP()             {__no_operation();}
#define portYIELD_VECTOR      1
/* due to a bug in IAR R32C Compiler intrinsic __get_interrupt_level
   __set_interrupt_level functions, this is done in asm_func.s53 */
#ifndef __IAR_SYSTEMS_ASM__
  unsigned portBASE_TYPE portSetInterruptMaskFromISR(void);
  void portClearInterruptMaskFromISR(unsigned portBASE_TYPE saved);
#endif
#define portSET_INTERRUPT_MASK_FROM_ISR() portSetInterruptMaskFromISR()
#define portCLEAR_INTERRUPT_MASK_FROM_ISR( uxSavedStatusRegister ) \
{ \
	portClearInterruptMaskFromISR(uxSavedStatusRegister);\
}

/*-----------------------------------------------------------*/

/* Task utilities. */
/*-----------------------------------------------------------*/



/* Critical section management. */
#define portDISABLE_INTERRUPTS()  {__set_interrupt_level(configMAX_SYSCALL_INTERRUPT_PRIORITY);}
#define portENABLE_INTERRUPTS()   {__set_interrupt_level(configKERNEL_INTERRUPT_PRIORITY);}


#define portCRITICAL_NESTING_IN_TCB (1)
#ifndef __IAR_SYSTEMS_ASM__
  extern void vTaskEnterCritical(void);
  extern void vTaskExitCritical(void);
#endif
#define portENTER_CRITICAL() do { vTaskEnterCritical(); } while (0)
#define portEXIT_CRITICAL()  do { vTaskExitCritical(); } while (0)

/* there is another possible implementation of critical section
   that uses the task stack to store the flags which more efficient
   but which need to be used with care because it potentionally
   could mess up the stack
// be careful, the current state is stored on the stack! when use, make sure to have matching
// ENTER/EXIT pairs that do not mess up the stack. DO NOT:
// portENTER_CRITICAL();
// { int test;  // allocated on the stack!
//   portLEAVE_CRITICAL();
//   return;
// }
#define portENTER_CRITICAL() \
{ \
    asm("PUSHC FLG");\
    __set_interrupt_level(configMAX_SYSCALL_INTERRUPT_PRIORITY);\
}
#define  portEXIT_CRITICAL() \
{ \
    asm("POPC FLG");\
}
*/

/*-----------------------------------------------------------*/


/*=============================================================================================*/


/* this is non maskable! always yields even if I flag cleared */
#define portYIELD()                 {__software_interrupt(portYIELD_VECTOR);}


/* Defines the prototype to which task functions must conform. */
#ifndef __IAR_SYSTEMS_ASM__
  typedef void __data24 * pdTASK_PARAM;
  typedef void (__task *pdTASK_CODE)( pdTASK_PARAM );
  typedef portBASE_TYPE __data24 * pdISR_PARAM;
#endif

/* Task function macros as described on the FreeRTOS.org WEB site.
 * neither task nor user interrupts need to save context ant entry.
 * this is done by entry exit code in asm_func.s34 */
#define portTASK_FUNCTION_PROTO( vFunction, pvParameters ) __task void  vFunction( pdTASK_PARAM pvParameters )
#define portTASK_FUNCTION( vFunction, pvParameters )  __task void  vFunction( pdTASK_PARAM pvParameters )
#define portINTERRUPT_HANDLER_PROTO(isrFunction) __task void isrFunction ( pdISR_PARAM pxSwitchRequired__ )
#define portINTERRUPT_HANDLER(isrFunction) __task void isrFunction ( pdISR_PARAM pxSwitchRequired__ )

#define portEND_SWITCHING_ISR( xSwitchRequired ) if (1) {(*pxSwitchRequired__) |= xSwitchRequired;} else ((void)0)

#pragma diag_suppress=Pa082


#ifdef __cplusplus
}
#endif

#endif /* PORTMACRO_H */

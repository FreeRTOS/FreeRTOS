class MyClass
{
public:
	void foo(::some::very::looong::_and::complicated::name::MyType& a,
	        ::some::very::looong::_and::complicated::name::MyType& b,
	        some::very::looong::_and::complicated::name::MyType& c);
};
void foo()
{
        return [=](T* t) {
        };
}

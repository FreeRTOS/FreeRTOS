/*******************************************************************
    Copyright Scanmar AS (C) 2005-06
    All Rights Reserved


    This file contain various smart battery routines


    0.1     12-jan-05    oaf    Initial version

*******************************************************************/


/* 1st include bean specific files */


/* 2nd include library files */


/* 3rd include project specific files */


/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
 #########################################################################
*    Allocate strings in table in FLASH (char *far)
*************************************************************************/
#if defined(__HCS12X__)
    #pragma STRING_SEG  __GPAGE_SEG     .text
    #pragma CONST_SEG   __GPAGE_SEG     .text
#else
    #pragma STRING_SEG  __PPAGE_SEG     .text
    #pragma CONST_SEG   __PPAGE_SEG     .text
#endif




void myMain(void);

/********************************************************************
*   Private methods from here
********************************************************************/

static void myInit(void);

static void myWork(void);

static unsigned int SwService_GetCharsInRxBufHelper(void);

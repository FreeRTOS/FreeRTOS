class STDMETHOD
{
        STDMETHOD(GetValues) (BSTR bsName, REFDATA** pData);
        STDMETHOD(GetValues) (BSTR bsName, REFDATA** pData);
};

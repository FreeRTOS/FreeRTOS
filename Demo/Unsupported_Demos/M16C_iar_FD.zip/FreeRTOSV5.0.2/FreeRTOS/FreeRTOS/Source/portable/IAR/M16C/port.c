/*! \file *********************************************************************
 *
 * \brief FreeRTOS port  for IAR M16C
 *
 * \author  (c) Copyright 2008, Felix Daners Engineering. f.daners@swissworld.com
 *
 * FreeRTOS.org is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FreeRTOS.org is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FreeRTOS.org; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * A special exception to the GPL can be applied should you wish to distribute
 * a combined work that includes FreeRTOS.org, without being obliged to provide
 * the source code for any proprietary components.  See the licensing section
 * of http://www.FreeRTOS.org for full details of how and when the exception
 * can be applied.
 *
 *****************************************************************************/

#include "FreeRTOS.h"
#include "task.h"

#ifdef __cplusplus
  extern "C" {
#endif

/*
 * Setup the stack of a new task so it is ready to be placed under the
 * scheduler control.  The registers have to be placed on the stack in
 * the order that the port expects to find them.
 */
portSTACK_TYPE *pxPortInitialiseStack( portSTACK_TYPE *pxTopOfStack,
                                                pdTASK_CODE pxCode,
                                                pdTASK_PARAM pvParameters )
{
  /* select user stack, enable interrupt, set interrupt level to kernel */
  portSTACK_TYPE flag = 0x0040 | 0x0080 | (configKERNEL_INTERRUPT_PRIORITY<<12);

  pxTopOfStack--;

  /* | FLG(H) | PC(H)  | FLG(L)          | */
  *pxTopOfStack-- = (flag & 0x00FF)
                    | (((unsigned portLONG)pxCode >> 8) & 0x00000F00)
                    | ((flag << 4) & 0xF000);

  /* | PC(M)           |  PC(L)          | */
  *pxTopOfStack-- = (portSTACK_TYPE)(((unsigned portLONG)pxCode ) & 0x0000FFFF);

  /* | FB                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0xFBFB;

  /* | SB                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0x3B3B;

  /* | A1                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0xA1A1;

  /* | A0                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0xA0A0;

  /* | R3                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0x3333;

  /* | R2                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)((unsigned portLONG)pvParameters >> 16L);

  /* | R1                                | */
  *pxTopOfStack-- = (portSTACK_TYPE)0x1111;

  /* | R0                                | */
  *pxTopOfStack   = (portSTACK_TYPE)((unsigned portLONG)pvParameters & 0x0000FFFFL);

   return pxTopOfStack;
}

/*
 * Map to the memory management routines required for the port.
 */
/* we use one of the MemMang implementations
 void *pvPortMalloc( size_t xSize )
{
  return NULL;
}

void vPortFree( void *pv )
{
}

void vPortInitialiseBlocks( void )
{
}
*/


/* these come from asm_func.s34 */
extern void portStartScheduler_asm(void);
extern void portEndScheduler_asm(void);

/* if you choose another timer for os tick, you need to change the ISR handler in asm_func.s34 */
/** reset ms timer function */
/* This routine setups timer 1 and clears timer flag */
static void rtos_tick_timer_uninstall(void)
{
  tb0s = 0x00;      // stop timer B0 (count flag)
}

/** set ms timer function */
/* This routine setups timer B0 and clears timer flag */
static void rtos_tick_timer_install(void)
{
  /* this function is called before interrupts are enabled */

  TB0MR = 0x40;     // XXXX XXXX
                    // |||| ||++- operation mode: 00: timer 01: event counter 10:one shot timer 11: PWM
                    // |||| |+--- pulse output at pin TA4out 0: OFF 1: ON
                    // |||| +---- gate function: 0: timer counts only when TA0in is "L", 1: .. is "H"
                    // |||+------ gate function  0: not available 1: available
                    // ||+------- must always be 0 in timer mode
                    // ++-------- count source select bits: 00:f1  01:f8  10:f32 11:fc32

  TB0 = 1500-1;     // 1ms resolution @ 12MHz f8
  tb0s = 0x01;      // start timer B0 (count flag)
  TB0IC = configMAX_SYSCALL_INTERRUPT_PRIORITY;// interrupt priority level select bit 0...7
}



/*
 * Setup the hardware ready for the scheduler to take control.  This generally
 * sets up a tick interrupt and sets timers for the correct tick frequency.
 */
portBASE_TYPE xPortStartScheduler( void )
{
  rtos_tick_timer_install();

  /* this enables interrupts because the initialized stack frame contains
     the flag register status */
  portStartScheduler_asm();

  return pdFALSE;
}

/*
 * Undo any hardware/ISR setup that was performed by xPortStartScheduler() so
 * the hardware is left in its original condition after the scheduler stops
 * executing.
 */
void vPortEndScheduler( void )
{
  rtos_tick_timer_uninstall();
  portEndScheduler_asm();
}


#ifdef __cplusplus
  }
#endif


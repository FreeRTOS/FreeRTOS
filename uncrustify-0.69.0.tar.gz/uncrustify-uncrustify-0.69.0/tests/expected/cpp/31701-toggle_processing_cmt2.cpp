void func() {
}

// *INDENT-OFF*
void func() { }
// ??DEF??

void func() {
}

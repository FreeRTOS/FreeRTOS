/*
FreeRTOS.org V4.1.2 - Copyright (C) 2003-2006 Richard Barry.

This file is part of the FreeRTOS.org distribution.

FreeRTOS.org is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

FreeRTOS.org is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with FreeRTOS.org; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

A special exception to the GPL can be applied should you wish to distribute
a combined work that includes FreeRTOS.org, without being obliged to provide
the source code for any proprietary components.  See the licensing section 
of http://www.FreeRTOS.org for full details of how and when the exception
can be applied.

***************************************************************************
See http://www.FreeRTOS.org for documentation, latest information, license 
and contact details.  Please ensure to read the configuration and relevant 
port sections of the online documentation.
***************************************************************************
*/

/*
Changes from V2.4.0

+ Made serial ISR handling more complete and robust.

Changes from V2.4.1

+ Split serial.c into serial.c and serialISR.c.  serial.c can be 
compiled using ARM or THUMB modes.  serialISR.c must always be
compiled in ARM mode.
+ Another small change to cSerialPutChar().

Changed from V2.5.1

+ In cSerialPutChar() an extra check is made to ensure the post to
the queue was successful if then attempting to retrieve the posted
character.

*/

/* 
This file contains all the serial port components that can be compiled to
either ARM or THUMB mode.  Components that must be compiled to ARM mode are
contained in serialISR.c.
*/

/* Standard includes. */
#include <stdlib.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

/* Demo application includes. */
#include "serial.h"
#include "serialISR.h"

/* This *MUST* match the order in the eParity definition. */
const unsigned portLONG ulParityFromEnum[] =
{
  AT91C_US_PAR_NONE,
  AT91C_US_PAR_ODD,
  AT91C_US_PAR_EVEN,
  AT91C_US_PAR_MARK,
  AT91C_US_PAR_SPACE
};

/* This *MUST* match the order in the eStopBits definition. */
const unsigned portLONG ulStopBitsFromEnum[] =
{
  AT91C_US_NBSTOP_1_BIT,
  AT91C_US_NBSTOP_2_BIT
};

/* This *MUST* match the order in the eDataBits definition. */
const unsigned portLONG ulDataBitsFromEnum[] =
{
  AT91C_US_CHRL_5_BITS,
  AT91C_US_CHRL_6_BITS,
  AT91C_US_CHRL_7_BITS,
  AT91C_US_CHRL_8_BITS
};

/* This *MUST* match the order in the eBaud definition. */
const unsigned portLONG ulSpeedFromEnum[] = 
{ 
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (    50 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (    75 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (   110 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (   134 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (   150 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (   200 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (   300 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (   600 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (  1200 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (  1800 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (  2400 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (  4800 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (  9600 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / ( 19200 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / ( 38400 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / ( 57600 * 16.0)) + 0.5),
  ( unsigned portLONG ) ((configCPU_CLOCK_HZ / (115200 * 16.0)) + 0.5)
};

typedef struct
{
  AT91PS_USART  addr;                   // USART Base Address
  unsigned      id;                     // Peripheral ID
  unsigned      intLevel;               // Interrupt Level
  void         *intHandler;             // Interrupt Handler
  AT91PS_PIO    pioBase;                // PIO Base Address
  unsigned      txPin;                  // TX Pin
  unsigned      rxPin;                  // RX Pin
} xUsart;

const xUsart usart[MAX_USARTS] =
{
#ifdef USART0
  [USART0] = {AT91C_BASE_US0,  AT91C_ID_US0, 5, vUSART0_ISR, AT91C_BASE_PIOB, AT91C_PB4_TXD0,  AT91C_PB5_RXD0},
#endif
#ifdef USART1
  [USART1] = {AT91C_BASE_US1,  AT91C_ID_US1, 5, vUSART1_ISR, AT91C_BASE_PIOB, AT91C_PB6_TXD1,  AT91C_PB7_RXD1},
#endif
#ifdef USART2
  [USART2] = {AT91C_BASE_US2,  AT91C_ID_US2, 5, vUSART2_ISR, AT91C_BASE_PIOB, AT91C_PB8_TXD2,  AT91C_PB9_RXD2},
#endif
#ifdef USART3
  [USART3] = {AT91C_BASE_US3,  AT91C_ID_US3, 5, vUSART3_ISR, AT91C_BASE_PIOB, AT91C_PB10_TXD3, AT91C_PB11_RXD3},
#endif
#ifdef USART4
  [USART4] = {AT91C_BASE_US4,  AT91C_ID_US4, 5, vUSART4_ISR, AT91C_BASE_PIOA, AT91C_PA31_TXD4, AT91C_PA30_RXD4},
#endif
#ifdef USART5
  [USART5] = {AT91C_BASE_US5,  AT91C_ID_US5, 5, vUSART5_ISR, AT91C_BASE_PIOB, AT91C_PB12_TXD5, AT91C_PB13_RXD5},
#endif
};

/*-----------------------------------------------------------*/

/* Misc constants. */
#define serINVALID_QUEUE          ( ( xQueueHandle ) 0 )
#define serHANDLE                 ( ( xComPortHandle ) 1 )
#define serNO_BLOCK               ( ( portTickType ) 0 )

/*-----------------------------------------------------------*/
xComPort xPortStatus[ MAX_USARTS ];

/*-----------------------------------------------------------*/
void USART_ISR( xComPort *pComPort )
{
  AT91PS_USART pUsart = pComPort->pUsart;
  unsigned portLONG ulStatus;
  signed portCHAR cChar;
  portBASE_TYPE xTaskWokenByTx = pdFALSE, xTaskWokenByRx = pdFALSE;

  /* What caused the interrupt? */
  ulStatus = pUsart->US_CSR &= pUsart->US_IMR;

  if ( ulStatus & AT91C_US_TXRDY )
    {
    /* The interrupt was caused by the THR becoming empty.  Are there any
    more characters to transmit? */
    if( xQueueReceiveFromISR( pComPort->xCharsForTx, &cChar, &xTaskWokenByTx ) == pdTRUE )
      {
      /* A character was retrieved from the queue so can be sent to the
      THR now. */
      pUsart->US_THR = cChar;
      }
    else
      {
      /* Queue empty, nothing to send so turn off the Tx interrupt. */
      pUsart->US_IDR = AT91C_US_TXRDY;
      }   
    }

  if ( ulStatus & AT91C_US_RXRDY )
    {
    /* The interrupt was caused by a character being received.  Grab the
    character from the RHR and place it in the queue of received 
    characters. */
    cChar = pUsart->US_RHR;
    xTaskWokenByRx = xQueueSendFromISR( pComPort->xRxedChars, &cChar, xTaskWokenByRx );
    }

  /* End the interrupt in the AIC. */
  AT91C_BASE_AIC->AIC_EOICR = 0;

  /* If an event caused a task to unblock then we call "Yield from ISR"
  to ensure that the unblocked task is the task that executes when the
  interrupt completes if the unblocked task has a priority higher than
  the interrupted task. */
  if ( xTaskWokenByTx || xTaskWokenByRx )
    {
    portYIELD_FROM_ISR();
    }
}

/*-----------------------------------------------------------*/

xComPortHandle xSerialPortInit( eCOMPort ePort,
                                eBaud eWantedBaud,
                                eParity eWantedParity,
                                eDataBits eWantedDataBits,
                                eStopBits eWantedStopBits,
                                unsigned portBASE_TYPE uxBufferLength )
{
  xComPort     *pComPort;
  AT91PS_USART  pUsart;                 // USART Base Address
  unsigned      usartID;                // USART Perpherial ID
  AT91PS_PIO    pioBase;                // PIO Base Address
  unsigned      pioPins;                // RX & TX PIO Pins

  if ( ePort >= MAX_USARTS )
    return (xComPortHandle) 0;

  pComPort = &xPortStatus[ePort];
  
  pComPort->xRxedChars = xQueueCreate( uxBufferLength, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );

  if ( pComPort->xRxedChars == serINVALID_QUEUE )
    return (xComPortHandle) 0;

  pComPort->xCharsForTx = xQueueCreate( uxBufferLength + 1, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );

  if ( pComPort->xCharsForTx == serINVALID_QUEUE )
    {
    vQueueDelete(pComPort->xRxedChars);
    return (xComPortHandle) 0;
    }

  pUsart = pComPort->pUsart = usart[ePort].addr;
  usartID = usart[ePort].id;
  pioBase = usart[ePort].pioBase;
  pioPins = (usart[ePort].txPin | usart[ePort].rxPin);

  portENTER_CRITICAL();
    {
    /* Enable the USART clock. */
    AT91C_BASE_PMC->PMC_PCER = 1 << usartID;

    // Disable interrupts
    pUsart->US_IDR = 0xFFFFFFFF;

    /* Reset various status bits (just in case)... */
    pUsart->US_CR = AT91C_US_RSTSTA;

    // Enable RXD & TXD pins
    pioBase->PIO_ASR = pioPins;
    pioBase->PIO_PDR = pioPins;

    // Reset receiver and transmitter
    pUsart->US_CR = ( AT91C_US_RSTRX |
                      AT91C_US_RSTTX |
                      AT91C_US_RXDIS |
                      AT91C_US_TXDIS );

    pUsart->US_BRGR = ulSpeedFromEnum[eWantedBaud];

    /* Write the Timeguard Register */
    pUsart->US_TTGR = 0;

    // Define the USART mode
    pUsart->US_MR = ( ulDataBitsFromEnum[eWantedDataBits] |
                      ulParityFromEnum[eWantedParity] |
                      ulStopBitsFromEnum[eWantedStopBits] );

    /* Enable Rx and Tx. */
    pUsart->US_CR = ( AT91C_US_RXEN | AT91C_US_TXEN );

    /* Enable the Rx interrupts.  The Tx interrupts are not enabled
     * until there are characters to be transmitted. */
    pUsart->US_IER = AT91C_US_RXRDY;

    /* Enable the interrupts in the AIC. */
    // Disable the interrupt on the interrupt controller
    AT91C_BASE_AIC->AIC_IDCR = 0x1 << usartID;

    // Save the interrupt handler routine pointer
    AT91C_BASE_AIC->AIC_SVR[usartID] = (unsigned int) usart[ePort].intHandler;

    // Set the interrupt type and priority
    AT91C_BASE_AIC->AIC_SMR[usartID] = ( AT91C_AIC_SRCTYPE_INT_LEVEL_SENSITIVE |
                                         usart[ePort].intLevel );

    // Clear the interrupt on the interrupt controller
    AT91C_BASE_AIC->AIC_ICCR = 0x1 << usartID;

    // Enable the interrupt on the interrupt controller
    AT91C_BASE_AIC->AIC_IECR = 0x1 << usartID;
    }
  portEXIT_CRITICAL();

  return (xComPortHandle) pComPort;
}

/*-----------------------------------------------------------*/

xComPortHandle xSerialPortInitMinimal( unsigned portLONG ulWantedBaud,
                                       unsigned portBASE_TYPE uxQueueLength )
{
  eBaud eWantedBaud;

  for (eWantedBaud = ser50; eWantedBaud <= ser115200; eWantedBaud++)
    {
    portLONG lDiff = (configCPU_CLOCK_HZ / (ulWantedBaud * 16)) - ulSpeedFromEnum[eWantedBaud];

    if ( ( lDiff <=  1 ) &&
         ( lDiff >= -1 ) )
      return xSerialPortInit(serCOM1, eWantedBaud, serNO_PARITY, serBITS_8, serSTOP_1, uxQueueLength);
    }

  return ( xComPortHandle ) 0;
}
/*-----------------------------------------------------------*/

signed portBASE_TYPE xSerialGetChar( xComPortHandle pxPort,
                                     signed portCHAR *pcRxedChar,
                                     portTickType xBlockTime )
{
  xComPort *pComPort = ( xComPort *) pxPort;

  /* Get the next character from the buffer.  Return false if no characters
  are available, or arrive before xBlockTime expires. */
  if ( xQueueReceive( pComPort->xRxedChars, pcRxedChar, xBlockTime ) )
    return pdTRUE;

  return pdFALSE;
}
/*-----------------------------------------------------------*/

void vSerialPutString( xComPortHandle pxPort,
                       const signed portCHAR * const pcString,
                       unsigned portSHORT usStringLength )
{
  signed portCHAR *pxNext;

  /* NOTE: This implementation does not handle the queue being full as no
  block time is used! */
  ( void ) usStringLength;

  /* Send each character in the string, one at a time. */
  pxNext = ( signed portCHAR * ) pcString;

  while ( *pxNext )
    {
    xSerialPutChar( pxPort, *pxNext, serNO_BLOCK );
    pxNext++;
    }
}
/*-----------------------------------------------------------*/

signed portBASE_TYPE xSerialPutChar( xComPortHandle pxPort,
                                     signed portCHAR cOutChar,
                                     portTickType xBlockTime )
{
  xComPort *pComPort = ( xComPort *) pxPort;
  AT91PS_USART pUsart = pComPort->pUsart;

  /* Place the character in the queue of characters to be transmitted. */
  if( xQueueSend( pComPort->xCharsForTx, &cOutChar, xBlockTime ) != pdPASS )
    {
    return pdFAIL;
    }

  /* Turn on the Tx interrupt so the ISR will remove the character from the
  queue and send it.   This does not need to be in a critical section as
  if the interrupt has already removed the character the next interrupt
  will simply turn off the Tx interrupt again. */
  pUsart->US_IER = AT91C_US_TXRDY;

  return pdPASS;
}
/*-----------------------------------------------------------*/

void vSerialClose( xComPortHandle xPort )
{
  /* Not supported as not required by the demo application. */
  ( void ) xPort;
}
/*-----------------------------------------------------------*/







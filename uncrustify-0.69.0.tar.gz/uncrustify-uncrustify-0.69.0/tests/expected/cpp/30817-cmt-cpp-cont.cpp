#include "foo.h"

//
// plshade z xmin xmax ymin ymax \
// sh_min sh_max sh_cmap sh_color sh_width \
// min_col min_wid max_col max_wid \
// rect [[pltr x y] | NULL ] [wrap]
//--------------------------------------------------------------------------

void foo()
{
   // plshade z xmin xmax ymin ymax \
   // sh_min sh_max sh_cmap sh_color sh_width \
   // min_col min_wid max_col max_wid \
   //       rect [[pltr x y] | NULL ] [wrap]
   //--------------------------------------------------------------------------
}

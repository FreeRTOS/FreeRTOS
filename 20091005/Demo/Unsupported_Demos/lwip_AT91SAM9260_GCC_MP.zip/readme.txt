This port is heavily based on lwip_demo_rowley port because of many similiarities between AT91SAM9260 and AT91SAM7X256.
Port is based on FreeRTOS v5.0.4.
Bootloader is AT91Bootstrap v1.9 with few modifications for my board (modifications include 16-bit SDRAM initialization and AT45DB041B detection). 

1. About this port:
This port is intended to work with AT91SAM9260 microcontroller under GCC development enviroment. AT91SAM9260 doesnt have internal programmable flash included, so it is necessary to upload the code into the external SDRAM memory located at 0x20000000. This is done by first level bootloader (AT91Bootstrap). 
It is assumed that microcontroller works in BMS=1 mode (pin BMS connected to VCC) so boot process is as follows:
- At reset the boot ROM code is loaded,
- ROM code detects external serial memory (AT45DB041B in case of my board) and downloads AT91Bootstrap code into internal SRAM0,
- ROM code jumps to SRAM0 address and runs AT91Bootstrap code,

AT91Bootstrap does necessary low-level operations:
- configures PLL,
- configures SDRAM (single K4S561632 SDRAM chip 4M x 16bit x 4banks, refer to AT91Bootstrap code for other configurations)
- detects serial memory AT45DB041B connected to SPI0_NPCS1 (PC11) and downloads code from address 0x00008000 into SDRAM address mapped at 0x20000000,
- code jumps to address 0x20000000, from this point the FreeRTOS code is being run.

2. Development board
This code was tested on the minimal development board based on modified AT91SAM9260-EK schematics including:
- ethernet phy STE100P connected to MII interface (should work with original DM9161 without modifications),
- Atmel serial flash connected to SPI0_NPCS1 (PC11) (AT45DB041B on my board, but AT91SAM9260-EK flash should also be detected by bootloader software),
- leds connected to PB0, PB2, PB4, PB6 pins of microcontroller,
- USB connected to DDP and DDM pins as in AT91SAM9260-EK,
- K4S561632 SDRAM connected to 16-bit data bus (AT91SAM9260-EK uses two such memories but should work in 16-bit mode without modifications).

3. Code Modifications (based on lwip_demo_rowley):
- boot.s and atmel-rom.ld were modified to work with the code uploaded directly to SDRAM memory by the first level bootloader (AT91Bootstrap code). It is necessary to copy the interrupt vectors to address 0x0 of microcontroller memory (this is done by boot.s).
- SAM7_EMAC.c was modified to work with AT91SAM9620 EMAC pin mappings, also PHY configuration code WAS COMMENTED OUT so this demo should work with any MII compatible ethernet PHY (STE100P in my case)
- USB-CDC.c was modified to work with AT91SAM9260 USB interface (only difference is the presence of internal pullup resistor, refer to vInitUSBInterface function.
- AT91Startup.c was removed from the code - is is assumed that all low-level operations (PLL configuration, SDRAM configuration) are done by AT91Bootstrap),
- only MII mode of EMAC code was tested because my STE100P works in this mode,
- partest code was modified to work with LEDS located at PB0, PB2, PB4, PB6 pins of microcontroller.
- default IP address is 192.168.2.3/255.255.255.0

4. Usage:
Steps necessary to run the code:
- compile AT91Bootstrap for AT91SAM9260 (makefile located in AT91Bootstrap\board\at91sam9260ek\dataflash directory),
- download the FreeRTOS v5.0.4 code and merge it with files included in the archive,
- compile this demo,
- set microcontroller to BMS=1 mode (BMS connected to VCC - code run from internal ROM)
- upload AT91Bootstrap boot file to dataflash at chipselect 1 (SAM-BA can be used)
- upload FreeRTOS code to dataflash at address 0x8000 (SAM-BA can be used)
- reset microcontroller,
- leds should start flashing indicating that the code works fine,
- demo web page can be accessed at 192.168.2.3
- virtual com port can be accessed after installing drivers included in USB directory

5. Usage on AT91SAM9260-EK board
- this code should work in AT91SAM9260-EK board without or with few modifications
- user should change LED mapping in board.h file
- user can try to uncomment the phy configuration in xEMACInit function to work with DP9161 Phy maintenance options but this is probably not necessary to access the board on ethernet (at least it work with STE100P and DP83846 with this code commented).

6. Author
Mateusz Plocinski, mateusz.plocinski@gmail.com
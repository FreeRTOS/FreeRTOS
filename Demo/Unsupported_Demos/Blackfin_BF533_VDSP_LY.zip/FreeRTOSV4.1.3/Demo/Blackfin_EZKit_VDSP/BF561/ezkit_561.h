#ifndef BF561_EZKit_H
#define BF561_EZKit_H

#include <sys/exception.h>
#include <signal.h>
#include <cdefBF561.h>

extern void EZKit_Init_Flags (void);
extern void EZKit_Init_Interrupts(void);
extern void EZKit_Set_LED(char lite);
extern void EZKit_Clear_LED(char lite);
extern void app_init(void);
extern void app_launch_threads(void);
EX_INTERRUPT_HANDLER (IVG11_ISR);

#endif /* BF561_EZKit_H */

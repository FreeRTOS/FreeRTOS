		Here is something to know about this Demo.


Origins:
-------------
First there is some information where the source files are coming from.
However I did some major modifications on it but this will be explained later on.

"main.c":		Were it comes from ... I don't know exactly anymore.
			It is a mixture from different examples delivered
			by FreeRTOS, Rowley and STMicro.

"lcd.c":		Contains LCD-Task and -routines. It is from the ST-Demo
			that is shipped with the board and is also available on
			ST's homepage. Meanwhile I guess, there are plenty of
			versions scattered all over the web.

"lcd.h":		Header for "lcd.c" with definitions and declarations.
			Has same origin as "lcd.c" and was modified too.

"mainISR.c":		As far as I remember the original file is from an
			"ARM7_LPC2138_Rowley" Demo. Then I replaced the content
			according to my needs and to the FreeRTOS help pages.

"ADC_task.c":		It is written by me. Nevertheless I got some
			"inspirations" from other FreeRTOS examples ;-).

"fonts.c":		I wrote it by myself because I changed the character font.
			However I did follow the example of STMicro's file
			"fonts.h". In my opinion a header file should not contain
			any code. So I'd rather include it separately. In some
			later versions of ST's file "lcd.c" the font is directly
			included meanwhile. But in order to be able to exchange
			fonts it's better to keep it separated.

"heap_1.c":		It's a FreeRTOS-Source.
			I added a new function "vPortGetHeapSize( void )" to check
			how much RAM is still free after all tasks, queues and
			semaphores are created. It has proved to be very useful
			meanwhile in other applications, especially if MCU-RAM
			is smaller than 8k.

"stm32f10x_conf.h":
"stm32f10x_it.c":	The Files are part of ST's Library software and shall be
			adapted for FreeRTOS and for the application.
			Some I/O-Ports are used for debugging purposes.

"logo1.c".."logo4.c":	Converted Bitmaps to be displayed at start of application.
			The Files are generated with a Perl-script that I wrote
			to skip the Header of the BMP-File and to make a C-File
			from a (binary) BMP-File.

"STM32F10x_Startup.s":	A Rowley File that defines interrupt vector table and
			startup-code. It has to be adapted for FreeRTOS to
			plug-in the SVC Handler- and SysTick-Handler.
			If an application uses its own ISR's then the
			function pointers have to be entered here.


What the Demo does:
----------------------
It starts five tasks that do the following things:

LED-Task:	It uses LED1, LED2 and LED3 to display a kind of heartbeat.
		For this it issues a "moving dot" that walks back and forth
		between LED1 and LED3 with two seconds pause in between.

LCD-Task:	There is more than one task that may use the display to output
		some information. But display operations are quite time consuming.
		Therefore it is better to establish a dedicated task that
		exclusively does this. So the other tasks are not delayed by
		concurrent attempts to access the display.
		The LCD-Task uses a queue for all other tasks to enter their
		display requests and waits on it until there is something to do.
		Each "Sender-"Task has its own display area that can be treated
		like a window. At start it displays some "introducing information".

Button-Task:	This Task waits for "Key" button to be pressed and if so, then
		it generates a table with task statistics.
		The table is afterwards sent to LCD-Task.
		During initialization the Button-Task sends a String to LCD-Task
		that contains all available characters of the character set.

Check-Task:	Originally this task is from other FreeRTOS examples to check
		if all created tasks are still working well.
		Now it only generates a string to display both system clock
		and free heap space every five seconds.
		The string is then passed to the LCD-Task.

ADC-Task:	The ADC-Task initializes an A/D-conversion algorithm that
		cyclically reads eight samples from the potentiometer and
		transfers it to RAM using DMA.
		Then the DMA generates an interrupt that ADC-Task is waiting for.
		If all samples are written then the ADC Task evaluates the
		average value, converts it to a value between 0 and 100 and uses
		this value to set a PWM-Duty cycle at LED4.
		Furthermore it sends a display message to LCD-Task if the
		value has changed.


***** Have Fun *****

Gert Schmalfuss
(www.hiconnect.de)





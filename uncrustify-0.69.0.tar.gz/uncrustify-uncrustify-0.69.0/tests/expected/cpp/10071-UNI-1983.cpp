typedef HRESULT (WINAPI *Foo)(const void* pData, SIZE_T size, UINT flags, const char* szStr, D3D10BlobHack** ppBlob);

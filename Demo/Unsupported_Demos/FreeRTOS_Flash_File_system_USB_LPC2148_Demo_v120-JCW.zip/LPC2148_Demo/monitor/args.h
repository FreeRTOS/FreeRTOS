#ifndef _ARGS_H_
#define _ARGS_H_

int argsGetLine (int fd, U8 *buffer, int bufferLength);
int argsParse (char *cmd, char **argv, int sizeofArgv, int *argc);

#endif

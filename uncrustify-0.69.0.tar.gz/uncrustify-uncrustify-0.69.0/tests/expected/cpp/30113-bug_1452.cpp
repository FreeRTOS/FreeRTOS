struct foobar {
	char *
	foobarz() { return "foobar"; }
	char *
	foo_bar() { return "foo_bar"; }

	int foo;
};

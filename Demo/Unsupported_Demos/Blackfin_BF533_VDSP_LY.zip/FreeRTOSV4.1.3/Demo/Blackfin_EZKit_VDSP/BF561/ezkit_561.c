#include "ezkit_561.h"

extern unsigned int freertos_global_imask;

void EZKit_Init_Flags (void)
{
	// enable PF5 and PF6 edge interrupt
	*pFIO0_EDGE		= 0x0060;
	*pFIO0_MASKA_D	= 0x0060;
	
	// enable push button PF5, PF6, PF7, PF8
	*pFIO0_DIR		= 0x0000;
	*pFIO0_POLAR	= 0x0000;
	*pFIO0_INEN		= 0x0060;
	
	
	*pFIO2_DIR		= 0xFFFF;		// LEDs
	*pFIO2_FLAG_S 	= 0xFFFF;
	
	*pFIO2_FLAG_C	= 0xFFFF;
	
}// end of EZKit_Init_Flags

void EZKit_Init_Interrupts(void)
{
	// enable FlagA interrupt
	*pSICB_IMASK1 = 0x00018000;

	register_handler_ex (ik_ivg11,                   // Register IVG11 ISR and enable
	               		 IVG11_ISR, EX_INT_ENABLE);  // IVG11 - Flag interrupt
	// This is very important for FreeRTOS
	// Remember to set the globle interrupt status 
	freertos_global_imask |= 0x81F;

}// end of EZKit_Init_Interrupts

void EZKit_Set_LED(char lite)
{
	*pFIO2_FLAG_S = (1 << (lite - 1));

}// end of EZKit_Set_LED


void EZKit_Clear_LED(char lite)
{
	*pFIO2_FLAG_C = ( 1 << (lite - 1));
}// end of EZKit_Clear_LED


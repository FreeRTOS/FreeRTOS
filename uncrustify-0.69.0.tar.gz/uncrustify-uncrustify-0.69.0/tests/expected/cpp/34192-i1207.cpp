#include <vector>
std::vector<int> f()
{
	return std::vector<int>{1};
}

int main()
{
	return f()[0];
}
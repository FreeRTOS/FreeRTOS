/*
	FreeRTOS.org V4.1.3 - Copyright (C) 2003-2006 Richard Barry.

	This file is part of the FreeRTOS.org distribution.

	FreeRTOS.org is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	FreeRTOS.org is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with FreeRTOS.org; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	A special exception to the GPL can be applied should you wish to distribute
	a combined work that includes FreeRTOS.org, without being obliged to provide
	the source code for any proprietary components.  See the licensing section 
	of http://www.FreeRTOS.org for full details of how and when the exception
	can be applied.

	***************************************************************************
	See http://www.FreeRTOS.org for documentation, latest information, license 
	and contact details.  Please ensure to read the configuration and relevant 
	port sections of the online documentation.
	***************************************************************************
*/

/* Part of FreeRTOS porting code on Blackfin processor */
/* Luke Yang <magic.yyang@gmail.com> */

/*-----------------------------------------------------------
 * Implementation of functions defined in portable.h for the Cygnal port.
 *----------------------------------------------------------*/

/* Standard includes. */
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"

#include <sys/exception.h>

#define portNO_CRITICAL_NESTING		( ( unsigned portLONG ) 0 )

/* We require the address of the pxCurrentTCB variable, but don't want to know
any details of its type. */
typedef void tskTCB;
extern volatile tskTCB * volatile pxCurrentTCB;
extern void vTaskSwitchContext( void );
extern void vTaskIncrementTick( void );

/*
 * Setup the hardware to generate an interrupt off timer 2 at the required 
 * frequency.
 */
extern void prvSetupTimerInterrupt( void );

/* global IMASK status 
 * defalut value enables core timer and soft int 14,15
 */
unsigned int freertos_global_imask = 0xC05F;

/*-----------------------------------------------------------*/

/* 
 * See header file for description. 
 */
portSTACK_TYPE *pxPortInitialiseStack( portSTACK_TYPE *pxTopOfStack, pdTASK_CODE pxCode, void *pvParameters )
{
	unsigned portLONG ulAddress;
    
	int i;
    	/* Setup the initial stack of the task.  The stack is set exactly as
	expected by the portRESTORE_CONTEXT() macro. */
    
	/* Simulate how the stack would look after a call to the scheduler tick 
	ISR. */
	ulAddress = ( unsigned portLONG ) pxCode;
	for (i = 14; i > 0; i--) {
	    // R0 - R7, P0 - P5 value - caller's incoming argument #1
	    *--pxTopOfStack = (portSTACK_TYPE) pvParameters;
	}
	
	*--pxTopOfStack = (portSTACK_TYPE) 0x5F;			// IMASK -- only core timer is enabled
	
	*--pxTopOfStack = (portSTACK_TYPE) ulAddress;       // RETS value - NO task should return with RTS - however, 
	
	*--pxTopOfStack = (portSTACK_TYPE) 0x0000;			// ASTAT value - caller's ASTAT value - value irrelevant
	
	*--pxTopOfStack = ( portSTACK_TYPE ) ulAddress;   // RETI value - pushing the start address of the task
			
	/* The remaining registers are straight forward. */
	for (i=27; i>0; i--)						// remaining reg values - R7:3, P5:3, 4 words of A1:0(.W,.X)
	{                           				// LT0, LT1, LC0, LC1, LB0, LB1, I3:0, M3:0, L3:0, B3:0, 
		*--pxTopOfStack = (portSTACK_TYPE) 0;   // All values irrelevant
	}

	/* Some optimisation levels use the stack differently to others.  This 
	means the interrupt flags cannot always be stored on the stack and will
	instead be stored in a variable, which is then saved as part of the
	tasks context. */
	//*--pxTopOfStack = portNO_CRITICAL_NESTING;
	
	return pxTopOfStack;
}
/*-----------------------------------------------------------*/

/* 
 * See header file for description. 
 */
portBASE_TYPE xPortStartScheduler( void )
{
	char tmp[220];
	/* Setup core timer to generate the RTOS tick. */
	register_handler_ex (ik_ivg14, (ex_handler_fn)vContextSwitch, EX_INT_ENABLE);
	prvSetupTimerInterrupt();	

	/* start the first task. Current context is discarded and will switch to the first task context */
	pxCurrentTCB = tmp;
	vStartFirstTask();

	/* Should never get here! */
	return 0;
}
/*-----------------------------------------------------------*/

void vPortEndScheduler( void )
{
	/* It is unlikely that the Blackfin port will require this function as there
	is nothing to return to.  */
}
/*-----------------------------------------------------------*/

#define vPortEnterCritical() portDISABLE_INTERRUPTS()
#define vPortExitCritical() portENABLE_INTERRUPTS()


/*              PUTCHAR.C

   The ANSI "putchar" function.

   The putchar function writes the character c to the
   output-stream pointed to by stream.
   The function returns the character written. If an writing
   error  occurs the putchar shall return EOF.

   $Revision: 1.1 $

   Copyright 1986 - 1999 IAR Systems. All rights reserved.
*/


#include <stdio.h>
#include <FreeRTOS.h>

#include "uart.h"

int putchar(int ch)
{
    uint8_t c = (uint8_t)ch;
	SendBuffer(1, &c,1);
    return ch;
}


void function(int a
              , int b
              , int c);

enum Test {
	A,
	B,
	C,
	D,
	E
}

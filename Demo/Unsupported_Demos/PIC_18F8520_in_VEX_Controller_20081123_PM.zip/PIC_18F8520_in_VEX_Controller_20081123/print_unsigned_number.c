/*  Copyright (C) 2008      Paul Murphy                                                                 */
/*                                                                                                      */
/*  The author hereby grants permission to use, copy, modify, distribute, and license this software and */
/*  its documentation for any purpose, provided that existing copyright notices are retained in all     */
/*  copies and that this notice and the following disclaimer are included verbatim in any               */
/*  distributions.  No written agreement, license, or royalty fee is required for any of the authorized */
/*  uses.                                                                                               */
/*                                                                                                      */
/*  THIS SOFTWARE IS PROVIDED BY THE AUTHOR *AS IS* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,   */
/*  BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  */
/*  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,       */
/*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF         */
/*  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER       */
/*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING    */
/*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE */
/*  POSSIBILITY OF SUCH DAMAGE.                                                                         */
/*                                                                                                      */
/*                                                                                                      */
/*                                                                                                      */


#include "FreeRTOS.h"
#include "task.h"
#include "serial.h"

void printUnsignedNumber(unsigned int input)
{
	unsigned int  thisNumber;
	unsigned char thisThousands;
	unsigned char thisHundreds;
	unsigned char thisTens;
	unsigned char thisUnits;

	unsigned char thisChar;

	xComPortHandle xPortHandle;

	unsigned int  xTimeOutTicks = (unsigned int) 5400;

	thisThousands = 0;
	thisHundreds = 0;
	thisTens = 0;
	thisUnits = 0;

	thisNumber = (unsigned int) input;

	while (thisNumber > 999)
	{
		thisThousands++;

		thisNumber = thisNumber - 1000;
	}

	while (thisNumber > 99)
	{
		thisHundreds++;

		thisNumber = thisNumber - 100;
	}

	while (thisNumber > 9)
	{
		thisTens++;

		thisNumber = thisNumber - 10;
	}

	while (thisNumber > (unsigned int) 0)
	{
		thisUnits++;

		thisNumber = thisNumber - 1;
	}

	thisChar = thisThousands + 48;

	xSerialPutChar( xPortHandle, thisChar, xTimeOutTicks );

	thisChar = thisHundreds + 48;

	xSerialPutChar( xPortHandle, thisChar, xTimeOutTicks );

	thisChar = thisTens + 48;

	xSerialPutChar( xPortHandle, thisChar, xTimeOutTicks );

	thisChar = thisUnits + 48;

	xSerialPutChar( xPortHandle, thisChar, xTimeOutTicks );
}

void printUnsignedNumberPair(unsigned int input1, unsigned int input2)
{
	unsigned int  thisNumber1, thisNumber2;
	unsigned char thisThousands1, thisThousands2;
	unsigned char thisHundreds1, thisHundreds2;
	unsigned char thisTens1, thisTens2;
	unsigned char thisUnits1, thisUnits2;

	unsigned char thisChar1, thisChar2;

	xComPortHandle xPortHandle;

	unsigned int  xTimeOutTicks = (unsigned int) 5400;

	thisThousands1 = 0;
	thisHundreds1 = 0;
	thisTens1 = 0;
	thisUnits1 = 0;

	thisThousands2 = 0;
	thisHundreds2 = 0;
	thisTens2 = 0;
	thisUnits2 = 0;

	thisNumber1 = input1;

	while (thisNumber1 > 999)
	{
		thisThousands1++;

		thisNumber1 = thisNumber1 - 1000;
	}

	while (thisNumber1 > 99)
	{
		thisHundreds1++;

		thisNumber1 = thisNumber1 - 100;
	}

	while (thisNumber1 > 9)
	{
		thisTens1++;

		thisNumber1 = thisNumber1 - 10;
	}

	while (thisNumber1 > 0)
	{
		thisUnits1++;

		thisNumber1 = thisNumber1 - 1;
	}

	thisChar1 = thisThousands1 + 48;

	xSerialPutChar( xPortHandle, (signed char) thisChar1, xTimeOutTicks );

	thisChar1 = thisHundreds1 + 48;

	xSerialPutChar( xPortHandle, (signed char) thisChar1, xTimeOutTicks );

	thisChar1 = thisTens1 + 48;

	xSerialPutChar( xPortHandle, (signed char) thisChar1, xTimeOutTicks );

	thisChar1 = thisUnits1 + 48;

	xSerialPutChar( xPortHandle, (signed char) thisChar1, xTimeOutTicks );

	xSerialPutChar( xPortHandle, 0x20, xTimeOutTicks );


	thisNumber2 = input2;

	while (thisNumber2 > (unsigned int) 999)
	{
		thisThousands2++;

		thisNumber2 = thisNumber2 - 1000;
	}

	while (thisNumber2 > (unsigned int) 99)
	{
		thisHundreds2++;

		thisNumber2 = thisNumber2 - 100;
	}

	while (thisNumber2 > (unsigned int) 9)
	{
		thisTens2++;

		thisNumber2 = thisNumber2 - 10;
	}

	while (thisNumber2 > (unsigned int) 0)
	{
		thisUnits2++;

		thisNumber2 = thisNumber2 - 1;
	}

	thisChar2 = thisThousands2 + 48;

	xSerialPutChar( xPortHandle, (signed char) thisChar2, xTimeOutTicks );

	thisChar2 = thisHundreds2 + 48;

	xSerialPutChar( xPortHandle, (signed char) thisChar2, xTimeOutTicks );

	thisChar2 = thisTens2 + 48;

	xSerialPutChar( xPortHandle, (signed char)thisChar2, xTimeOutTicks );

	thisChar2 = thisUnits2 + 48;

	xSerialPutChar( xPortHandle, (signed char) thisChar2, xTimeOutTicks );

}


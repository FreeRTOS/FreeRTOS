#ifndef _EINTSISR_H_
#define _EINTSISR_H_

void eintsISR_EINT0 (void);
void eintsISR_EINT2 (void);

#endif

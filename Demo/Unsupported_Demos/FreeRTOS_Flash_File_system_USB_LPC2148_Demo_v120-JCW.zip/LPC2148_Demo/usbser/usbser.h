#ifndef _USBSER_H_
#define _USBSER_H_

#include "FreeRTOS.h"
#include "queue.h"

//
//
//
signed portBASE_TYPE usbserPutChar (signed portCHAR cOutChar, portTickType xBlockTime);
signed portBASE_TYPE usbserPutString (const signed portCHAR * const pcString, portTickType xBlockTime);
signed portBASE_TYPE usbserGetChar (signed portCHAR *pcRxedChar, portTickType xBlockTime);
void usbserInit (void);
void usbserGetRxQueue (xQueueHandle *qh);

#endif

/* ----------------------------------------------------------------------------
 *         ATMEL Microcontroller Software Support  -  ROUSSET  -
 * ----------------------------------------------------------------------------
 * Copyright (c) 2006, Atmel Corporation
 *
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaiimer below.
 * 
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the disclaimer below in the documentation and/or
 * other materials provided with the distribution. 
 * 
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission. 
 * 
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ----------------------------------------------------------------------------
 */
/*-----------------------------------------------------------------------------
 *  File Name           : BOARD.h
 *  Object              : AT91SAM9260-EK Evaluation Board Features Definition File
 *  Creation            : FDy   10-Nov-2006
 *-----------------------------------------------------------------------------
 */
#ifndef BOARD_H
#define BOARD_H

#include "AT91SAM9260.h"

// eCOMPort is an enum in serial.h and as such its values are not
// available to the preprocessor.  We will parallel them here.
#define _serCOM1              0
#define _serCOM2              1
#define _serCOM3              2
#define _serCOM4              3
#define _serCOM5              4
#define _serCOM6              5

// There are two USARTs configured on the AT91SAM9260-EK.  Assign them
// to serCOM1 & serCOM2.  NOTE: Any USART can be assigned to any unused
// _serCOM
#define USART0                _serCOM1
#define USART1                _serCOM2
//#define USART2                _serCOM3
//#define USART3                _serCOM4
//#define USART4                _serCOM5
//#define USART5                _serCOM6

/*-----------------*/
/* LEDs Definition */
/*-----------------*/
#define LED1                  AT91C_PIO_PA6       // PA6
#define LED2                  AT91C_PIO_PA9       // PA9
#define NB_LED                2
#define LED_MASK              (LED1|LED2)

#define LED_BASE_PIO          (AT91C_BASE_PIOA)
#define LED_ID_PIO            (AT91C_ID_PIOA)

/*-------------------------------*/
/* Push Button Definition        */
/*-------------------------------*/
#define SW1_MASK              AT91C_PIO_PA30      // PA30
#define SW2_MASK              AT91C_PIO_PA31      // PA31
#define SW_MASK               (SW1_MASK|SW2_MASK)

#define SW_BASE_PIO           (AT91C_BASE_PIOA)
#define SW_ID_PIO             (AT91C_ID_PIOA)

#define DBGU_BAUD_RATE        115200

/*---------------*/
/* SPI interface */
/*---------------*/
/* MN5 SERIAL DATAFLASH AT45DB642E
   SPI   Name : Port
   SPI  SCK  PA14 / SPI_SPCK
   CS        PA11 / SPI_NPCS0
   SO        PA12 /SPI_MISO
   SI        PA13 /SPI_MOSI
*/
#define DATAFLASH_PERI        Peripheral_A
#define DATAFLASH_SI          AT91C_PA13_MOSI
#define DATAFLASH_SO          AT91C_PA12_MISO
#define DATAFLASH_CS          AT91C_PA11_NPCS0
#define DATAFLASH_SCK         AT91C_PA14_SPCK

/*---------------*/
/* Clocks       */
/*--------------*/
#define AT91B_MAIN_OSC        18432000            // Main Oscillator MAINCK
#define AT91B_MCK             ((18432000*97/9)/2) // Output PLLA Clock (198,656 MHz)
#define AT91B_MASTER_CLOCK    AT91B_MCK

#endif /* BOARD_H */

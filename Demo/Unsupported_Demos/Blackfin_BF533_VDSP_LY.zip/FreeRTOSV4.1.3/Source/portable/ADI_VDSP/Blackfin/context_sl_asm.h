/* Part of FreeRTOS porting code on Blackfin processor */
/* Luke Yang <magic.yyang@gmail.com> */

.extern  _pxCurrentTCB;
.extern  _freertos_global_imask;
/*
 * portRESTORE_CONTEXT, portRESTORE_CONTEXT, portENTER_SWITCHING_ISR
 * and portEXIT_SWITCHING_ISR can only be called from ARM mode, but
 * are included here for efficiency.  An attempt to call one from
 * THUMB mode code will result in a compile time error.
 */

#define _portRESTORE_CONTEXT				\
	/* Set the LR to the task stack. */		\
	/* load pxCurrentTCB into SP */			\
	P1.L = _pxCurrentTCB;					\
	P1.H = _pxCurrentTCB;					\
	P0 = [P1];								\
	SP = [P0];								\
	/* keep loading other reg */			\
	LB1 = [ SP ++ ] ;						\
	LB0 = [ SP ++ ] ;						\
	LT1 = [ SP ++ ] ;						\
	LT0 = [ SP ++ ] ;						\
	LC1 = [ SP ++ ] ;						\
	LC0 = [ SP ++ ] ;						\
	R0 = [ SP ++ ] ;						\
	A1 = R0 ;								\
	R0 = [ SP ++ ] ;						\
	A1.x = R0.L ;							\
	R0 = [ SP ++ ] ;						\
	A0 = R0 ;								\
	R0 = [ SP ++ ] ;						\
	A0.x = R0.L ;							\
	M3 = [ SP ++ ] ;						\
	M2 = [ SP ++ ] ;						\
	M1 = [ SP ++ ] ;						\
	M0 = [ SP ++ ] ;						\
	L3 = [ SP ++ ] ;						\
	L2 = [ SP ++ ] ;						\
	L1 = [ SP ++ ] ;						\
	L0 = [ SP ++ ] ;						\
	B3 = [ SP ++ ] ;						\
	B2 = [ SP ++ ] ;						\
	B1 = [ SP ++ ] ;						\
	B0 = [ SP ++ ] ;						\
	I3 = [ SP ++ ] ;						\
	I2 = [ SP ++ ] ;						\
	I1 = [ SP ++ ] ;						\
	I0 = [ SP ++ ] ;						\
	FP = [ SP ++ ] ;						\
	/* IPEND[4] will stay set when RETI popped from stack */\
	RETI = [ SP ++ ] ;						\
	ASTAT = [ SP ++ ] ;						\
	RETS = [ SP ++ ] ;						\
	/* get old IMASK from stack */			\
	R0 = [ SP ++ ] ;						\
	/* if interrupt is not disabled previously */	\
	CC = BITTST( R0, 6 );					\
	if !CC JUMP 14;							\
	/* update IMASK from global_imask */	\
	P1.L = _freertos_global_imask;			\
	P1.H = _freertos_global_imask;			\
	R1 = [P1];								\
	R0 = R0 | R1;							\
	/* should jump here by offset */		\
	STI R0;		/* restore IMASK */			\
	( R7:0 , P5:0 ) = [ SP ++ ] ;			\
	/* simulate a return from interrupt (also clears IPEND[4]) */\
	RTI		
	
/*-----------------------------------------------------------
* 			The convention for the task frame (after context save is complete) is as follows: 
*			(stack represented from high to low memory as per convention)  
*				(*** High memory ***)    
*						
*   					R7:0	(R7 is lower than R0)
*   					P5:0	(P5 is lower than P0)
*						IMASK		
*						RETS   	(function return address of thread)
*	   					ASTAT
*						RETI  	(interrupt return address: $PC of thread)
*						FP		(frame pointer)
*						I3:0	(I3 is lower than I0)
*						B3:0	(B3 is lower than B0)
*						L3:0	(L3 is lower than L0)
*						M3:0	(M3 is lower than M0)
*					   	A0.x
*					   	A0.w
*					   	A1.x
*					   	A1.w
*					   	LC1:0	(LC1 is lower than LC0)
*					   	LT1:0	(LT1 is lower than LT0)
*StkPtr -> (* Low memory *)	LB1:0	(LB1 is lower than LB0)
*	
*******************************************************************************/
#define _portSAVE_CONTEXT					\
	[ -- SP ] = ( R7:0 , P5:0 ) ;			\
	CLI R0;									\
	[ -- SP ] = R0;  /* save IMASK */		\
	STI R0;									\
	[ -- SP ] = RETS ;						\
	[ -- SP ] = ASTAT ; 					\
	/* this enables the interrupt */		\
	[ -- SP ] = RETI ; 						\
	[ -- SP ] = FP ;						\
	[ -- SP ] = I0 ;						\
	[ -- SP ] = I1 ;						\
	[ -- SP ] = I2 ;						\
	[ -- SP ] = I3 ;						\
	[ -- SP ] = B0 ;						\
	[ -- SP ] = B1 ;						\
	[ -- SP ] = B2 ;						\
	[ -- SP ] = B3 ;						\
	[ -- SP ] = L0 ;						\
	[ -- SP ] = L1 ;						\
	[ -- SP ] = L2 ;						\
	[ -- SP ] = L3 ;						\
	[ -- SP ] = M0 ;						\
	[ -- SP ] = M1 ;						\
	[ -- SP ] = M2 ;						\
	[ -- SP ] = M3 ;						\
	R1.L = A0.x ;							\
	[ -- SP ] = R1 ;						\
	R1 = A0.w ;								\
	[ -- SP ] = R1 ;						\
	R1.L = A1.x ;							\
	[ -- SP ] = R1 ;						\
	R1 = A1.w ;								\
	[ -- SP ] = R1 ;						\
	[ -- SP ] = LC0 ;						\
	[ -- SP ] = LC1 ;						\
	[ -- SP ] = LT0 ;						\
	[ -- SP ] = LT1 ;						\
	[ -- SP ] = LB0 ;						\
	[ -- SP ] = LB1 ;						\
	/* save stack pointer into [*CurrentTCB] */\
	P1.L = _pxCurrentTCB;					\
	P1.H = _pxCurrentTCB;					\
	P2 = [P1];								\
	R0 = SP;								\
	[P2] = R0
	
/*-----------------------------------------------------------
 * ISR entry and exit macros.  These are only required if a task switch
 * is required from the ISR.
 *----------------------------------------------------------*/
#define _portENTER_SWITCHING_ISR _portSAVE_CONTEXT

#define _portEXIT_SWITCHING_ISR				\
		.extern _vTaskSwitchContext;		\
		call.X _vTaskSwitchContext;			\
		_portRESTORE_CONTEXT

	
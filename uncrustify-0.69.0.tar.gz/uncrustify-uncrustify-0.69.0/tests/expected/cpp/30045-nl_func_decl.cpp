
void bla ( );
void ble( int a, char b );
void ble2 ( int a, char b );


void bla
(
)
{
}

void bla2
(
)
{
}

void ble
(
	int a,
	char b
)
{
}

void ble2
(
	int a,
	char b
)
{
}

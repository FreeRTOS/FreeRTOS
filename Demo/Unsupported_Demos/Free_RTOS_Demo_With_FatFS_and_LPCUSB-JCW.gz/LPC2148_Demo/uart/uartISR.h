#ifndef _UARTISR_H_
#define _UARTISR_H_

#include "FreeRTOS.h"
#include "queue.h"

//
//
//
void uartISRCreateQueues (portCHAR pxPort, unsigned portBASE_TYPE uxQueueLength, xQueueHandle *pxRX0Queue, xQueueHandle *pxTX0Queue, portLONG volatile **pplTHREEmptyFlag);
void uartISR0 (void);
void uartISR1 (void);
signed portBASE_TYPE uart0PostSpecialFromISR (U8 special);
signed portBASE_TYPE uart1PostSpecialFromISR (U8 special);

#endif

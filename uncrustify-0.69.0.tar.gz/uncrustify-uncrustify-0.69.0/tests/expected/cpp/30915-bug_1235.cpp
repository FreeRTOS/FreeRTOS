namespace dudeNamespace { class ForwardFooClass; }

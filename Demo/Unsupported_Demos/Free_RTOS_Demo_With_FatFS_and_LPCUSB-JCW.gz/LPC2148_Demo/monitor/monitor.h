#ifndef _MONITOR_H_
#define _MONITOR_H_

portTASK_FUNCTION_PROTO (vMonitorTask, pvParameters __attribute__ ((unused)));

#endif

/**
 * @file kw_subst2.cpp
 * Description
 *
 * $Id$
 */
#include <string>

namespace bar
{

	/**
	 * CLASS:  CFoo
	 * TODO: DESCRIPTION
	 */
	class CFoo
	{
	int foo1(int arg);
private:
	/**
	 * foo2
	 * TODO: DESCRIPTION
	 * @return TODO
	 */
	int foo2()
	{
	}
	};

	/**
	 * foo1
	 * TODO: DESCRIPTION
	 * @param arg TODO
	 * @param arg2 TODO
	 * @return TODO
	 */
	int CFoo::foo1(int arg, char arg2)
	{
	}

	/**
	 * foo2
	 * TODO: DESCRIPTION
	 * @return TODO
	 */
	int CFoo::foo2()
	{
	}

	/**
	 * operator +
	 * TODO: DESCRIPTION
	 * @return TODO
	 */
	int CFoo::operator +()
	{
	}

	/**
	 * func
	 * TODO: DESCRIPTION
	 * @return TODO
	 */
	map<string, int> func()
	{
		// some codes
	}

	/**
	 * some_func
	 * TODO: DESCRIPTION
	 * @return TODO
	 */
	int some_func(void)
	{
	}

}

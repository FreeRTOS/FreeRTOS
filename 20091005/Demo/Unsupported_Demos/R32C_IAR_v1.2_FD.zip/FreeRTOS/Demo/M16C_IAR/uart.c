//==============================================================================
// Copyright (c) by ndd Medizintechnik Zuerich, Switzerland.All rights reserved.
// -----------------------------------------------------------------------------
// Project: EasyOne
// Module :
// File   : UART.C
// Content: UART module
// -----------------------------------------------------------------------------
// RCS Version Information:
// $Source: /home/cvs/cvsroot/kunden/NDD_Medizintechnik/PictBridge/PictBridgeCradle/USBware/target/FreeRTOS/Demo/M16C_IAR/uart.c,v $
// $Revision: 1.2 $
// $Name:  $
// $Author: fd $
// $Date: 2008/08/28 17:52:57 $
//==============================================================================

#ifndef _PC_TEST
  #include <iom16c62p.h>
#if __VER__ > 300
	  #include <intrinsics.h>
#else
	  #include <intrm16c.h>
#endif
#endif
#include <string.h>
//#include "EZ1_TYPES.H"
//#include "ez1_macros.h"
#ifndef _PC_TEST
  //#include "EZ1_CradleHardware.h"
#endif
//#include "ez1_CradleDebug.h"
//#include "includes.h"
#define DEBUG
#include <FreeRTOS.h>
#include "uart.h"

#if __VER__ > 300
	#define TXD_D       p6_3
#else
	bit TXD_D     = p6_3;
#endif
#if __VER__ > 300
	#define RXD_RCLK    p6_2
#else
	bit RXD_RCLK  = p6_2;
#endif
#if __VER__ > 300
	#define RTS_CLK     p7_4 //P6.1;
#else
	bit RTS_CLK   = p7_4; //P6.1;
#endif
#if __VER__ > 300
	#define CTS_ACK     p6_1 //P7.4;
#else
	bit CTS_ACK   = p6_1; //P7.4;
#endif

#define TXD_D_DIR         pd6_3
#define RXD_RCLK_DIR      pd6_2
#define RTS_CLK_DIR       pd7_4
#define CTS_ACK_DIR       pd6_1
#define OUTPUT  1
#define INPUT   0
#define CPUCLK  12000000




//=============================================================================
// CONSTANT DEFINITIONS
//=============================================================================
// defines to set UART mode
#define SEVEN     0x04
#define EIGHT     0x05
#define NINE      0x06
#define INTERNAL  0x00
#define EXTERNAL  0x08
#define ONE_STOP  0x00
#define TWO_STOP  0x10
#define EVEN      0x60
#define ODD       0x40
#define NO_PARITY 0x00

// defines for RX/TX queue
#ifdef DEBUG
  #define MAX_NO_OF_UART  2
#else
  #define MAX_NO_OF_UART  1
#endif
#ifndef _BOOTLOADER
  #define RX_BUF_SIZE     512u
  #define TX_BUF_SIZE     128u
#else
  #define RX_BUF_SIZE     8u
  #define TX_BUF_SIZE     128u
#endif
#define RX_QUEUE_EMPTY(a)	(Uart[(a)].wRxHead == Uart[(a)].wRxTail)
#define TX_QUEUE_EMPTY(a)	(Uart[(a)].wTxHead == Uart[(a)].wTxTail)

//=============================================================================
// VARIABLE DEFINITIONS
//=============================================================================
// RS232 state variables
typedef struct
{
  uint8_t bTxDisabled :1;
  uint8_t bRxDisabled :1;
  uint8_t bModemActive:1;
  uint8_t bBinaryMode :1;
  uint8_t bFlowCtrlOn:1;   // NONE, RTS/CTS [XON/XOFF]
  uint8_t bTxActive:1;// = FALSE;
  uint8_t abyRxBuffer[RX_BUF_SIZE];
  volatile uint16_t wRxHead;
  volatile uint16_t wRxTail;
  uint8_t abyTxBuffer[TX_BUF_SIZE];
  uint16_t wTxHead;
  uint16_t wTxTail;
  uint8_t byBaudrate;
  uint8_t byLastError;
#ifdef DEBUG
  uint16_t wMaxRxBufferSize;
#endif
} UART_STRUCT;

static volatile UART_STRUCT TAR_DATA16 Uart[MAX_NO_OF_UART];

#pragma diag_suppress=Pa082,Pa079

//=============================================================================
// FUNCTIONS
//=============================================================================

uint8_t IsTxQueueEmpty(uint8_t byUart)
{
    uint8_t ret;
    __disable_interrupt();
    ret = ((Uart[byUart].wTxHead == Uart[byUart].wTxTail));
    __enable_interrupt();
    return ret;
}


//-----------------------------------------------------------------------------
// RS232 PC connection
//-----------------------------------------------------------------------------

// RX/TX queue functions ------------------------------------------------------
uint8_t CheckByteReceived(uint8_t byUart)
{
  if(byUart < MAX_NO_OF_UART)
  { if (! RX_QUEUE_EMPTY(byUart))
    { return((!0));
    }
  }
  return (0);
}

void FlushRxQueue(uint8_t byUart)
{ if(byUart < MAX_NO_OF_UART)
  { Uart[byUart].wRxTail = Uart[byUart].wRxHead;
  }
}
void FlushTxQueue(uint8_t byUart)
{ if(byUart < MAX_NO_OF_UART)
  { Uart[byUart].wTxTail = Uart[byUart].wTxHead;
  }
}

#ifndef _PC_TEST

#if __VER__ > 300
	#pragma vector=18
	__interrupt void Uart0RxInterrupt (void)
#else
	interrupt [18*4] void Uart0RxInterrupt (void)
#endif
{
  uint16_t wBufferSize;
  uint8_t byUartState = U0RBH;
  // XXXX X--X
  // |||| |||+------ Receive Data D8
  // |||| |++------- unused
  // |||| +--------- Arbitration Lost Detecting Flag (2)
  // |||+----------- Overrun Error Flag (1)   0:NO Error 1: Error found
  // ||+------------ Framing Error Flag (1)   0:NO Error 1: Error found
  // |+------------- Parity Error Flag (1)    0:NO Error 1: Error found
  // +-------------- Error Sum Flag (1)       0:NO Error 1: Error found
  /*
    NOTES :
    1. When the SMD2 to SMD0 bits in the UiMR register = 000b (serial I/O disabled) or the RE bit in the UiC1 register = 0 (reception disabled), all of the SUM,
    PER, FER and OER bits are set to �0� (no error). The SUM bit is set to �0� (no error) when all of the PER, FER and OER bits = 0 (no error).
    Also, the PER and FER bits are set to �0� by reading the lower byte of the UiRB register.
    2. The ABT bit is set to �0� by writing �0� in a program. (Writing �1� has no effect)
    (b15) Symbol Address After Reset
  */

  Uart[0].abyRxBuffer[Uart[0].wRxHead] = U0RBL;

  __enable_interrupt();

  if((byUartState & 0xF0) != 0x00)
  {
    __no_operation();
  }

  Uart[0].wRxHead = (++Uart[0].wRxHead) % RX_BUF_SIZE;
  wBufferSize = (Uart[0].wRxHead - Uart[0].wRxTail) % RX_BUF_SIZE;

  if(wBufferSize == 0)
	{ Uart[0].byLastError = OVERRUN_ERROR;
	}

//  if(Uart[0].wRxHead == Uart[0].wRxTail)
//	{ Uart[0].byLastError = OVERRUN_ERROR;
//	}
#ifdef DEBUG
  if( wBufferSize > Uart[0].wMaxRxBufferSize)
  {
    Uart[0].wMaxRxBufferSize = wBufferSize;
  }
#endif
	if(Uart[0].bFlowCtrlOn == (!0))
  {
    if(wBufferSize > ((RX_BUF_SIZE * 15u)/16u))
  	{ RTS_CLK = 1;
      Uart[0].bRxDisabled = (!0);
  	}else if(wBufferSize < (RX_BUF_SIZE/4u))
  	{ RTS_CLK = 0;
  	}
	}	
}
#if __VER__ > 300
	#pragma vector=17
	__interrupt void Uart0TxInterrupt (void)
#else
	interrupt [17*4] void Uart0TxInterrupt (void)
#endif
{
  __enable_interrupt();
  if(!TX_QUEUE_EMPTY(0))
  { if(Uart[0].bFlowCtrlOn == (!0))
    { if(CTS_ACK == 1) // CTS monitoring
      { Uart[0].bTxActive = 0;
        return;
      }
    }
    // transmit..
    while ((U0C1 & 0x02) != 0x02);  // wait until previous data transmitted
    U0TB = Uart[0].abyTxBuffer[Uart[0].wTxTail];   // transmit data
    Uart[0].wTxTail = (++Uart[0].wTxTail)%TX_BUF_SIZE;
  }else
  { Uart[0].bTxActive = 0;
  }
}

#ifdef DEBUG
#if __VER__ > 300
	#pragma vector=20
	__interrupt void Uart1RxInterrupt (void)
#else
	interrupt [20*4] void Uart1RxInterrupt (void)
#endif
{
  Uart[1].abyRxBuffer[Uart[1].wRxHead] = U1RBL;
  __enable_interrupt();

  Uart[1].wRxHead = (++Uart[1].wRxHead) % RX_BUF_SIZE;
  if(Uart[1].wRxHead == Uart[1].wRxTail)
	{
    Uart[1].byLastError = OVERRUN_ERROR;
	}
}

#ifndef _PC_TEST
#if __VER__ > 300
	#pragma vector=19
	__interrupt void Uart1TxInterrupt (void)
#else
	interrupt [19*4] void Uart1TxInterrupt (void)
#endif
{
  __enable_interrupt();
  if(!TX_QUEUE_EMPTY(1))
  {
    // transmit..
    while ((U1C1 & 0x02) != 0x02);  // wait until previous data transmitted
    U1TB = Uart[1].abyTxBuffer[Uart[1].wTxTail];   // transmit data
    Uart[1].wTxTail = (++Uart[1].wTxTail)%TX_BUF_SIZE;
  }else
  {
    Uart[1].bTxActive = 0;
  }
}
#endif

#endif
uint8_t Rs232_Rx(uint8_t byUart, uint8_t TAR_DATA13* byTemp)
{
	if (! RX_QUEUE_EMPTY(byUart) )
	{
		*byTemp = Uart[byUart].abyRxBuffer[Uart[byUart].wRxTail];
		Uart[byUart].wRxTail = (++Uart[byUart].wRxTail) % RX_BUF_SIZE; // works even for none 2^n values, but then 17 cycles slower! (& (RX_BUF_SIZE-1u);)
		return (!0);
	}
	return 0;
}


void InitRS232(uint8_t byUart)
{
  volatile uint8_t byTemp;

  if(byUart == 0)
  {
    RTS_CLK      = 1;         // RTS high, disable reception
    RTS_CLK_DIR  = OUTPUT;    // RTS input
    CTS_ACK_DIR  = INPUT;     // CTS output
    RXD_RCLK_DIR = INPUT;     // RXD input
    TXD_D_DIR    = OUTPUT;    // TXD output

    U0MR = EIGHT | INTERNAL | ONE_STOP | NO_PARITY;
    FlushRxQueue(0);
    FlushTxQueue(0);
    ResetUartStates();
    // set baudrate
    SetBaudRate(0, BAUD_19200);
    // control register 0
    U0C0 = 0x10;              // XXXX XXXX
                              // |||| |||+- Clock select  00: f1 01: f8 10: f16 11: inhibited
                              // |||| |+--- CTS/RTS function (valid when bit 4=0)
                              // |||| |     0: CTS function selected  1: RTS function selected
                              // |||| +---- Transmit register empty flag
                              // ||||        0: Data present   1: No data present in transmit register
                              // |||+------- CTS/RTS disable bit
                              // |||         0: CTS/RTS enabled  1: CTS/RTS disabled (P60, P64 IO-Ports)
                              // ||+-------- Data output select bit
                              // ||          0: TXD pin is CMOS output   1: TXD pin is open drain output
                              // |+----------Clock polarity       0: For UART mode must be 0
                              // +---------- Transfer format select bit must be always 0
    U0C1 = 0x05;              // XXXX XXXX
                              // |||| |||+------ Transmit enable bit   0: disabled 1:enabled
                              // |||| ||+------- Transmit buffer empty flag  0: Data present TX buf 1: No data
                              // |||| |+-------- Receive enable flag 0: disabled   1: enabled
                              // |||| +----------Receive complete flag 0: No data present in RX buf 1: Data present
                              // ++++------------Not used
  UCON = 0x40;              // XXXX XXXX
                            // |||| |||+- UART0 transmit interrupt cause select bit
                            // |||| |||   0: Transmit buffer empty (TI = 1) 1: Transmission complete (TXEPT = 1)
                            // |||| ||+-- UART1 transmit interrupt cause select bit
                            // |||| ||    0: Transmit buffer empty (TI = 1) 1: Transmission complete (TXEPT = 1)
                            // |||| |+--- UART0 continuous receive mode enable bit
                            // |||| |     0: invalid for UART mode
                            // |||| +---- UART1 continuous receive mode enable bit
                            // ||||       0: invalid  for UART mode
                            // |||+------ CLK/CLKS select bit    0: Invalid for UART mode
                            // ||+------- CLK/CLKS select bit    0: Must be 0 for UART mode
                            // |+-------- Separate CTS/RTS bit   0: CTS/RTS shared pin   1: CTS/RTS separated
                            // +--------- Not used

    __disable_interrupt();
    byTemp = U0RBL; // empty receive buffer...
    // UART0 (EasyOne connection) interrupt control register
    S0RIC = 0x07; // int enabled priority level 4
    S0TIC = 0x04; // int enabled priority level 4
    __enable_interrupt();
    RTS_CLK = 0;    // RTS low, ready to receive
  }else
  {
    pd6_6 = 0;    // RXD1 input
    pd6_7 = 1;    // TXD1 output
    #ifdef DEBUG
      // uart 1 initialization  (DEBUG connection)
      U1MR = EIGHT | INTERNAL | ONE_STOP | NO_PARITY;
      FlushRxQueue(1);
      FlushTxQueue(1);
    #endif
    ResetUartStates();

    #ifdef DEBUG
      SetBaudRate(1, BAUD_57600);
      U1C0 = 0x10;              // XXXX XXXX
      U1C1 = 0x05;              // XXXX XXXX
    #endif

    UCON = 0x40;              // XXXX XXXX
                              // |||| |||+- UART0 transmit interrupt cause select bit
                              // |||| |||   0: Transmit buffer empty (TI = 1) 1: Transmission complete (TXEPT = 1)
                              // |||| ||+-- UART1 transmit interrupt cause select bit
                              // |||| ||    0: Transmit buffer empty (TI = 1) 1: Transmission complete (TXEPT = 1)
                              // |||| |+--- UART0 continuous receive mode enable bit
                              // |||| |     0: invalid for UART mode
                              // |||| +---- UART1 continuous receive mode enable bit
                              // ||||       0: invalid  for UART mode
                              // |||+------ CLK/CLKS select bit    0: Invalid for UART mode
                              // ||+------- CLK/CLKS select bit    0: Must be 0 for UART mode
                              // |+-------- Separate CTS/RTS bit   0: CTS/RTS shared pin   1: CTS/RTS separated
                              // +--------- Not used
    __disable_interrupt();
    #ifdef DEBUG
      byTemp = U1RBL; // empty receive buffer...
      // UART1 (PC RS232) interrupt control register
      S1RIC = 0x01; // int enabled priority level 4
      S1TIC = 0x06; // int enabled priority level 4
    #endif
    __enable_interrupt();
  }
  return;
}
#endif
//----------------------------------------------------------------------------
// Function:    ResetUartStates()
// Description:
// Parameter:
// Return:      none
//----------------------------------------------------------------------------
void ResetUartStates(void)
{
  memset((void*)&Uart,0,sizeof(Uart));
  Uart[0].byLastError = NO_ERROR;
  #ifdef DEBUG
    Uart[1].byLastError = NO_ERROR;
  #endif
  RTS_CLK = 0;
}

#ifdef _MODEM_SUPPORT
//----------------------------------------------------------------------------
// Function:    SetModemState()
// Description: Function to set the state of the MODEM.
// Parameter:
// Return:      none
//----------------------------------------------------------------------------
void SetModemState(uint8_t byUart, uint8_t bModemOn)
{
  Uart[byUart].bModemActive = bModemOn;
}

//----------------------------------------------------------------------------
// Function:    SetModemState()
// Description: Function to set the state of the MODEM.
// Parameter:
// Return:      none
//----------------------------------------------------------------------------
uint8_t CheckModemActive(uint8_t byUart)
{
  return Uart[byUart].bModemActive != 0;
}
#endif

//----------------------------------------------------------------------------
// Function:    SetBinaryMode()
// Description: Function to set the binary mode (TX ONLY)
// Parameter:
// Return:      none
//----------------------------------------------------------------------------
void SetBinaryMode(uint8_t byUart, uint8_t bBinaryOn)
{
  Uart[byUart].bBinaryMode = bBinaryOn;
}

//----------------------------------------------------------------------------
// Function:    SetFlowCtrlState()
// Description: Function to set the state of the flow control to ON/OFF.
// Parameter:
// Return:      none
//----------------------------------------------------------------------------
void SetFlowCtrlState(uint8_t byUart, uint8_t bFlowCtrlOn)
{
  Uart[byUart].bFlowCtrlOn = bFlowCtrlOn;
}


//----------------------------------------------------------------------------
// Function:    SendAscii()
// Description: Function to send a byte in ASCII mode to the PC.
// Parameter:   uint8_t byData data to send
// Return:      none
//----------------------------------------------------------------------------
void SendAscii(uint8_t byUart, uint8_t byData)
{
  extern char IntToAsciiLo(uint8_t byData);
  extern char IntToAsciiHi(uint8_t byData);

#ifndef _PC_TEST
  if(Uart[byUart].bBinaryMode != 0)
  { if(byData == DLE)
    { SendByte(byUart, byData);
    }
    SendByte(byUart, byData);
  }else
  { SendByte(byUart, IntToAsciiHi(byData));
    SendByte(byUart, IntToAsciiLo(byData));
  }
#endif
}

//----------------------------------------------------------------------------
// Function:    SendString()
// Description: Function to send a zero terminated string to the PC.
// Parameter:   char *szString pointer to the of the string
// Return:      none
//----------------------------------------------------------------------------
void SendString(uint8_t byUart, const char TAR_DATA16 *szString)
{
  while(*szString != '\0')
  { SendByte(byUart, *szString++);
  }
}

//----------------------------------------------------------------------------
// Function:    SendBufferAscii()
// Description: Function to send a number of bytes string to the PC.
// Parameter:   char *szString pointer to the of the string
// Return:      none
//----------------------------------------------------------------------------
void SendBufferAscii(uint8_t byUart, uint8_t TAR_DATA16* pbyBuf, uint16_t wLength)
{
  while(wLength-- != 0)
  { SendAscii(byUart, *pbyBuf++);
  }
}
//----------------------------------------------------------------------------
// Function:    SendBuffer()
// Description: Function to send a number of bytes string to the PC.
// Parameter:   char *szString pointer to the of the string
// Return:      none
//----------------------------------------------------------------------------
void SendBuffer(uint8_t byUart, uint8_t * pbyBuf, uint16_t wLength)
{
  while(wLength-- != 0)
  {
    if(Uart[byUart].bBinaryMode != 0)
    { if(*pbyBuf == DLE)
      { SendByte(byUart, DLE);
      }
    }
    SendByte(byUart, *pbyBuf++);
  }
}

void SendCmd(uint8_t byUart, uint8_t byData)
{
  if(Uart[byUart].bBinaryMode != 0)
  { SendByte(byUart, DLE);
  }
  SendByte(byUart, STX);
  SendByte(byUart, byData);
}
static void SendByte(uint8_t byUart, uint8_t byData)
{
  uint16_t wTemp;

#ifndef _PC_TEST
  Uart[byUart].abyTxBuffer[Uart[byUart].wTxHead] = byData;
  wTemp = (Uart[byUart].wTxHead+1) % TX_BUF_SIZE;

  if(wTemp == Uart[byUart].wTxTail)
  {
    uint16_t wCount = 0;
    do
    {
      ServiceTxQueue();
      if(wCount++ > 0xF000)
      {
        Uart[byUart].byLastError = OVERRUN_ERROR;
        FlushTxQueue(byUart);
        return;
      }
      if(wTemp != Uart[byUart].wTxTail)
        break;
    }while(1);
  };
  __disable_interrupt();
  Uart[byUart].wTxHead = wTemp; //(++Uart[byUart].wTxHead) % TX_BUF_SIZE;
  #ifdef DEBUG
    if(Uart[byUart].wTxHead == Uart[byUart].wTxTail)
    { Uart[byUart].byLastError = OVERRUN_ERROR;
    }
  #endif
  __enable_interrupt();
  ServiceTxQueue();
#endif
  return;
}

void ServiceTxQueue(void)
{
#ifndef _PC_TEST
  uint8_t i;

  for (i=0;i<MAX_NO_OF_UART;i++)
  {
    if(i==0)
    {
      if(Uart[0].bFlowCtrlOn == (!0))
      {
        if(Uart[0].bRxDisabled == (!0))
        {
          uint16_t wBufferSize;

          __disable_interrupt();
          wBufferSize = (Uart[0].wRxHead - Uart[0].wRxTail) % RX_BUF_SIZE;
          __enable_interrupt();
          if(wBufferSize < (RX_BUF_SIZE/4))
          { RTS_CLK = 0;
            Uart[0].bRxDisabled = 0;
          }
	      }
      }
    }
    if(!TX_QUEUE_EMPTY(i))
    {
      if(Uart[i].bTxActive == 0)
      {
        // start transmit..
        if(i==0)
        { if(Uart[0].bFlowCtrlOn != 0)
          { if(CTS_ACK == 1) // CTS monitoring !!!!!!!!
            { return;
            }
          }
          while ((U0C1 & 0x02) != 0x02);  // wait until previous data transmitted
          __disable_interrupt();
          Uart[0].bTxActive = (!0);
          U0TB = Uart[0].abyTxBuffer[Uart[0].wTxTail];   // transmit data
          Uart[0].wTxTail = (++Uart[0].wTxTail)%TX_BUF_SIZE;
          __enable_interrupt();
        }
        #ifdef DEBUG
          else
          {
            while ((U1C1 & 0x02) != 0x02);  // wait until previous data transmitted
            __disable_interrupt();
            Uart[1].bTxActive = (!0);
            U1TB = Uart[1].abyTxBuffer[Uart[1].wTxTail];   // transmit data
            Uart[1].wTxTail = (++Uart[1].wTxTail)%TX_BUF_SIZE;
            __enable_interrupt();
          }
        #endif
      }
    }
  }
#endif
}

//----------------------------------------------------------------------------
// Function:    SetBaudRate()
// Description: set/change baud rate of RS232
// Parameter:   none
// Return:      none
//----------------------------------------------------------------------------
void SetBaudRate(uint8_t byUart, uint8_t byBaud)
{
#ifndef _PC_TEST
  uint16_t wTemp;

  if(Uart[byUart].bModemActive == 0)
  {
    switch (byBaud)
    {
      case BAUD_19200:
        //DEBUG_OUT("\n\rBAUD 19200");
        wTemp = (CPUCLK / 19200 / 8 + 1) / 2 - 1;      // rounded baud = f1/(16*(n+1))
        Uart[byUart].byBaudrate = BAUD_19200;
        break;
      case BAUD_57600:
        //DEBUG_OUT("\n\rBAUD 57600");
        wTemp = (CPUCLK / 57600 / 8 + 1) / 2 - 1;      // rounded baud = f1/(16*(n+1))
        Uart[byUart].byBaudrate = BAUD_57600;
        break;
      case BAUD_125000:
        //DEBUG_OUT("\n\rBAUD 125000");
        wTemp = (CPUCLK / 125000 / 8 + 1) / 2 - 1;      // rounded baud = f1/(16*(n+1))
        Uart[byUart].byBaudrate = BAUD_125000;
        break;
      default:
        break;
    }
    __disable_interrupt();
    if(byUart == 0)
    { U0BRG = wTemp;
    }else
    { U1BRG = wTemp;
    }
    __enable_interrupt();
  }
#endif
}

//----------------------------------------------------------------------------
// Function:    GetBaudRate()
// Description: get baud rate of RS232
// Parameter:   Uart number
// Return:      baudrate
//----------------------------------------------------------------------------
uint8_t GetBaudRate(uint8_t byUart)
{
  return(Uart[byUart].byBaudrate);
}

/*******************************************************************
    Copyright Scanmar AS (C) 2005-06
    All Rights Reserved


    This file contain various smart battery routines


    0.1     12-jan-05    oaf    Initial version

*******************************************************************/


/* 1st include bean specific files */
#include "COM0.h"
#include "Byte1.h"

/* 2nd include library files */
#include <ctype.h>
#include <stdio.h>


/* 3rd include project specific files */
#include "main.h"



/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
 #########################################################################
*    Allocate strings in table in FLASH (char *far)
*************************************************************************/
#if defined(__HCS12X__)
    #pragma STRING_SEG  __GPAGE_SEG     .text
    #pragma CONST_SEG   __GPAGE_SEG     .text
#else
    #pragma STRING_SEG  __PPAGE_SEG     .text
    #pragma CONST_SEG   __PPAGE_SEG     .text
#endif




void myMain(void)
{
    myWork();
}

/********************************************************************
*   Private methods from here
********************************************************************/

static void myWork(void)
{
    int i = 0;

    for(;;)
    {
        printf("%d: Hello X-world...\n", i++);

        Cpu_Delay100US(10000);
        Byte1_PutVal(i & 0x0f);
    }
}


#ifndef _EINTS_H_
#define _EINTS_H_

void eintsInit (void);

#endif

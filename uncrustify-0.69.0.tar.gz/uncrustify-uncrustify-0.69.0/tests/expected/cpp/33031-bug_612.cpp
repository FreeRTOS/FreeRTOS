void foo(void)
{
	int a = 0, b = 0;
	char chvar = 0, var = 0;

	a     = 0;
	b     = 0;
	chvar = 0;
	var   = 0;
}

void bar(void)
{
	int a      = 0;
	int b      = 0;
	char chvar = 0;
	char var   = 0;

	a     = 0;
	b     = 0;
	chvar = 0;
	var   = 0;
}

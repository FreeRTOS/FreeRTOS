void f()
{
}
void f()
{
}

void f()const {
}
void f()const {
}

void f()noexcept(){
}
void f()noexcept(){
}

void f()/**/
{
}
void f()/**/
{
}
void f()//
{
}
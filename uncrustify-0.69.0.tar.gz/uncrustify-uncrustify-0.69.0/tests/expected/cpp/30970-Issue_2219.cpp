void foo()
{
	for(int i = 0; i < 1; i++) return (false);
	float g = 0.13;
}

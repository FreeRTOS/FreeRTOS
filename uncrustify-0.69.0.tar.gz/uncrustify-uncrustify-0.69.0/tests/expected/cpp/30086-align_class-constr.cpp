class foo : public my_Class
{
    void bar_c(int tttt, int uu, int abc, int defxx)
        : tttt   (4444)
        , uu     (22)
        , abc    (333)
        , defxx  (55555)
    {
    }
}

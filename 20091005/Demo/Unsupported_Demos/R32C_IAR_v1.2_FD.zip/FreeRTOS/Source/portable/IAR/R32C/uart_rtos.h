/******************************************************************************
 *
 * UART for R32C/111     FreeRTOS
 *
 * author                f.daners@swissworld.com
 *                       Felix Daners Engineering
 *                       Speerstrasse 32
 *                       8200 Schaffhausen
 *                       Switzerland
 *
 *****************************************************************************
 *
 * !!! THIS FILE IS LICENSED SEPARATELY FROM FREERTOS !!!
 *
 * Copyright (c) 2009, Felix Daners Engineering, Switzerland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * - Neither the name of the Felix Daners Engineering nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************
 * Usage:
 * Code that uses API calls to uart functions, include this file.
 *
 * To instantiate uart functions, a .c file needs to define some symbols
 * prior to inclusion of this header:
 * Example: create an instance of uart functions for UART 0

   #define UART 0
   #define fx_brg_24000000
   #define uXbrg_val uXbrg_9600
   #define tx_fifo_size_val 16
   #define rx_fifo_size_val 32
   #define s1ric_val 0x3
   #define s1tic_val 0x2
   #define enable_RTS()  do { p1_1=0; } while(0)
   #define diasble_RTS() do { p1_1=1; } while(0)
   #include <uart_rtos.h>
   #undef UART
 *
 * to define other UART initialisation values, also define
 * uXmr_val, uXc1_val, uXc0_val as shown above
 *
 * API functions, for X use the uart number 0..6:
 *
 * // initialize UART, set handler for BREAK condition. If NULL, no BREAK
 * // handler is set
 * void init_uart_X(uart_break_cb cb);
 * // break condition is detected from framing error with all databits
 * // received as zero
 *
 * // transmit char without going through queue. Blocks until char is completely
 * // sent over the wire
 * // when CTS flow control is on, this function might block until the
 * // cts line allows for tx
* void outchar_uart_X(char ch);
 *
 * // try transmit char ch using tx queue, return when added to queue or
 * // after timeout. Returns -1 if not added to queue
 * signed short putchar_uart_X(char ch,portTickType ticks_to_wait);
 *
 * // Read from queue
 * typedef __packed union uart_rtos_rx_message_t
 * {
 *   signed short R;
 *   __packed struct uart_rtos_bits_t
 *   {
 *     unsigned char data_bits_0_7;             // the bit 0 to seven of the received character
 *     unsigned char data_bit_8            : 1; // the eight databit if uart in this mode
 *     unsigned char rx_queue_overrun      : 1; // the rx queue did overrun
 *     unsigned char user_abort            : 1; // abort_rx_uart_X() was called
 *     unsigned char rx_timeout            : 1; // nothing received within the timeout
 *     unsigned char err_overrun           : 1; // set when uart receive buffer overrun occurs
 *     unsigned char err_framing           : 1; // set when framing error
 *     unsigned char err_parity            : 1; // set when parity error detected
 *     unsigned char err_sum               : 1; // set when any of the errors set
 *   } B;
 * } uart_rtos_rx_message_t;
 * // returns a message from RX queue
 * signed short getmessage_uart_X(portTickType ticks_to_wait);
 * Example:
    uart_rtos_rx_message_t m;
    m.R = getmessage_uart_X(1000/portTICK_RATE_MS);
    if (m.B.err_sum)
    {
       ... // something went wrong, check error bits
    }
    else
    {
       dispatch(m.B.data_bits_0_7); // process received char
    }
 *
 * // empty the RX queue
 * void rx_flush_uart_X(void);
 *
 * // wait until tx register empty (use with care, usually interrupt handles this)
 * // when CTS flow control is on, this function might block until the
 * // cts line allows for tx
 * int busywait_txept_uart_X(void);
 *
 * // set a new baudrate. Returns -1 if fail
 * int setbaud_uart_X(unsigned long baud);
 * Example:
     setbaud_uart_X(19200);
 *
 * // get current baudrate, return -1 if fail
 * long int getbaud_uart_X(void);
 *
 * // enable/disable the receiver
 * void enable_rx_uart_X(void);
 * void disable_rx_uart_X(void);
 *
 * // set a new break handler. (caution, the handler is called from
 * // interrupt context)
 * uart_break_cb set_break_handler_cb_uart_X(uart_break_cb new_cb);
 * // break condition is detected from framing error with all databits
 * // received as zero
 *
 *
 *****************************************************************************/
#include <ior32c111.h>
#include <intrinsics.h>

#ifdef __cplusplus
  extern "C" {
#endif

#ifndef UART_RTOS_H
#define UART_RTOS_H



// uXmr
    // b2:b0            SMD2:0          SELECTS UART MODE, 8 BIT DATA TRANSFER
    // b3               CKDIR           INTERNAL CLOCK SELECTED
    // b4               STPS            ONE STOP BIT
    // b5               PRY             ODD PARITY (parity is disabled using b6)
    // b6               PRYE            DISABLE PARITY
    // b7               IOPOL           TRANSMITTER RECEIVER OUTPUT NOT INVERSED
#define uXmr_sm_uart_7bit      (0x04)
#define uXmr_sm_uart_8bit      (0x05)
#define uXmr_sm_uart_9bit      (0x06)
#define uXmr_ckdir_internal    (0x00)
#define uXmr_ckdir_external    (0x08)
#define uXmr_stps_one          (0x00)
#define uXmr_stps_two          (0x10)
#define uXmr_pry_odd           (0x00)
#define uXmr_pry_teven         (0x20)
#define uXmr_prye_enabled      (0x40)
#define uXmr_prye_disabled     (0x00)
#define uXmr_iopol_inverted    (0x80)
#define uXmr_iopol_noninverted (0x00)



// uXc0
    // b1:b0            CLK1:0          COUNT SOURCE f1=32MHz
    // b2               CRS             CTS RTS ENABLED WHEN CRD=0
    // b3               TXEPT           TRANSMIT REGISTER EMPTY FLAG
    // b4               CRD             CTS/RTS FUNCTION DISABLED
    // b5               NCH             DATA OUTPUT SELECT BIT
    // b6               CKPOL           CLOCK POLARITY SELECTED,TX FALLING EDGE,RX RISING EDGE
    // b7               UFORM           MSB FIRST
#define uXc0_clk_f1           0
#define uXc0_clk_f8           1
#define uXc0_clk_f2n          2
#define uXc0_txept_true       8
#define uXc0_txept_false      0
#define uXc0_crd_cts_enabled  0x0
#define uXc0_crd_cts_disabled 0x10
#define uXc0_nch_push_pull    0x00
#define uXc0_nch_open_drain   0x40
#define uXc0_uform_lsb_first  0x00
#define uXc0_uform_msb_first  0x80



// uXc1
    // b0           TE                      Transmit Enable Bit
    // b1           TI                      Transmit buffer empty flag,
    // b2           RE                      Receive enable bit,
    // b3   RI                      Receive complete flag,
    // b5:b4                                Reserved, set to 0
    // b6           U1LCH           Data logic select bit,
    // b7           U1ERE           Error signal output enable bit
#define uXc1_te_enabled               0x1
#define uXc1_ti_empty                 0x2
#define uXc1_re_enabled               0x4
#define uXc1_ri_data_held             0x8
#define uXc1_irs_ti                   0x0
#define uXc1_irs_txept                0x10
#define uXc1_rrm_continuos_enabled    0x20
#define uXc1_rrm_continuos_diasabled  0x0
#define uXc1_lch_non_inverted         0x0
#define uXc1_lch_inverted             0x40


// UART Error Flags
#define uart_databit_0_7              0x00FF
#define uart_databit_8                0x0100
#define uart_error_rx_queue_overrun   0x0200
#define uart_error_user_abort         0x0400
#define uart_error_rx_timeout         0x0800
#define uart_error_overrun            0x1000
#define uart_error_framing            0x2000
#define uart_error_parity             0x4000
#define uart_error_sum                0x8000

typedef __packed union uart_rtos_rx_message_t
{
  signed short R;
  __packed struct uart_rtos_bits_t
  {
    unsigned char data_bits_0_7;             // the bit 0 to seven of the received character
    unsigned char data_bit_8            : 1; // the eight databit if uart in this mode
    unsigned char rx_queue_overrun      : 1; // the rx queue did overrun
    unsigned char user_abort            : 1; // abort_rx_uart_X() was called
    unsigned char rx_timeout            : 1; // nothing received within the timeout
    unsigned char err_overrun           : 1; // set when uart receive buffer overrun occurs
    unsigned char err_framing           : 1; // set when framing error
    unsigned char err_parity            : 1; // set when parity error detected
    unsigned char err_sum               : 1; // set when any of the errors set
  } B;
} uart_rtos_rx_message_t;

typedef void (*uart_break_cb)(portBASE_TYPE *pxHigherPriorityTaskWoken);


#define __concat(a,b,c) a##b##c

#define uXc0(UART) __concat(u,UART,c0)
#define uXc1(UART) __concat(u,UART,c1)
#define uXc1(UART) __concat(u,UART,c1)
#define uXmr(UART) __concat(u,UART,mr)
#define uXsmr2(UART) __concat(u,UART,smr2)
#define uXsmr3(UART) __concat(u,UART,smr3)
#define uXsmr4(UART) __concat(u,UART,smr4)
#define uXbrg(UART) __concat(u,UART,brg)
#define uXtb(UART)  __concat(u,UART,tb)
#define uXrb(UART)  __concat(u,UART,rb)
#define sXric(UART)  __concat(s,UART,ric)
#define sXtic(UART)  __concat(s,UART,tic)

#define init_uart_X(UART) __concat(init_uart,_,UART)
#define uninit_uart_X(UART) __concat(uninit_uart,_,UART)
#define putchar_uart_X(UART) __concat(putchar_uart,_,UART)
#define outchar_uart_X(UART) __concat(outchar_uart,_,UART)
#define getmessage_uart_X(UART) __concat(getmessage_uart,_,UART)
#define rx_flush_uart_X(UART) __concat(rx_flush_uart,_,UART)
#define cancel_rx_uart_X(UART) __concat(cancel_rx_uart,_,UART)
#define cancel_tx_uart_X(UART) __concat(cancel_tx_uart,_,UART)
#define setbaud_uart_X(UART) __concat(setbaud_uart,_,UART)
#define getbaud_uart_X(UART) __concat(getbaud_uart,_,UART)
#define busywait_txept_uart_X(UART) __concat(busywait_txept_uart,_,UART)
#define enable_rx_uart_X(UART) __concat(enable_rx_uart,_,UART)
#define disable_rx_uart_X(UART) __concat(disable_rx_uart,_,UART)
#define set_break_handler_cb_uart_X(UART) __concat(set_break_handler_cb_uart,_,UART)
#define uart_X_context(UART) __concat(uart_,UART,_context)
#define tx_fifo_buf_X(UART) __concat(tx_fifo_buf,_,UART)
#define rx_fifo_buf_X(UART) __concat(rx_fifo_buf,_,UART)
#define clear_error_uart_X(UART) __concat(clear_error_uart,_,UART)


#endif

// sXric
    // b2:b0            ILV:0           interrupt request level select
    // b3               IR              interrupt fequest
#ifndef sXric_val
  #define  sXric_val 0x3
#endif

// sXtic
    // b2:b0            ILV:0           interrupt request level select
    // b3               IR              interrupt fequest
#ifndef sXtic_val
  #define  sXtic_val 0x3
#endif

#ifndef tx_fifo_size_val
  #define tx_fifo_size_val 128
#endif

#ifndef rx_fifo_size_val
  #define rx_fifo_size_val 128
#endif

#ifndef enable_RTS
  #define enable_RTS()
#endif
#ifndef disable_RTS
  #define disable_RTS()
#endif


#ifndef uXmr_val
  #define uXmr_val   uXmr_sm_uart_8bit \
                   | uXmr_ckdir_internal \
                   | uXmr_stps_one \
                   | uXmr_prye_disabled \
                   | uXmr_iopol_noninverted
#endif

#ifndef uXc1_val
  #define uXc1_val   uXc1_te_enabled \
                   | uXc1_re_enabled \
                   | uXc1_irs_ti \
                   | uXc1_rrm_continuos_diasabled \
                   | uXc1_lch_non_inverted
#endif


#ifndef uXc0_val
  #define uXc0_val   uXc0_clk_f1 \
                   | uXc0_crd_cts_enabled \
                   | uXc0_nch_push_pull \
                   | uXc0_uform_lsb_first
#endif


#ifndef uXbrg_val
  #define uXbrg_val uXbrg_9600
#endif



#ifndef UART

#define DECLARE_PROTOTYPES() \
  void init_uart_X(UART)(uart_break_cb cb); \
  void uninit_uart_X(UART)(void); \
  void outchar_uart_X(UART)(char ch); \
  signed short putchar_uart_X(UART)(char ch,portTickType ticks_to_wait); \
  signed short getmessage_uart_X(UART)(portTickType ticks_to_wait); \
  void rx_flush_uart_X(UART)(void); \
  int busywait_txept_uart_X(UART)(void); \
  int setbaud_uart_X(UART)(unsigned long baud); \
  long int getbaud_uart_X(UART)(void); \
  void enable_rx_uart_X(UART)(void); \
  void disable_rx_uart_X(UART)(void); \
  uart_break_cb set_break_handler_cb_uart_X(UART)(uart_break_cb cb);

  #define UART 0
  DECLARE_PROTOTYPES();
  #undef UART

  #define UART 1
  DECLARE_PROTOTYPES();
  #undef UART

  #define UART 2
  DECLARE_PROTOTYPES();
  #undef UART

  #define UART 3
  DECLARE_PROTOTYPES();
  #undef UART

  #define UART 4
  DECLARE_PROTOTYPES();
  #undef UART

  #define UART 5
  DECLARE_PROTOTYPES();
  #undef UART

  #define UART 6
  DECLARE_PROTOTYPES();
  #undef UART

#endif


#ifdef UART

#include <FreeRTOS.h>
#include <queue.h>

#ifndef uXbrg_9600
//***  fx = 12000000 (BRG clock source)        *************//
#if defined(fx_brg_12000000)    //     Baud |    m(BRG) | Actual Baud | Error
  #define   uXbrg_9600 (0x4D)   //     9600 | 0x4D( 77) |        9615 | 0.16 %
  #define  uXbrg_19200 (0x26)   //    19200 | 0x26( 38) |       19231 | 0.16 %
  #define  uXbrg_38400 (0x13)   //    38400 | 0x13( 19) |       37500 | -2.4 %
  #define  uXbrg_57600 (0x0C)   //    57600 | 0x0C( 12) |       57692 | 0.16 %
  #define uXbrg_115200 (0x06)   //   115200 | 0x06(  6) |      107143 | -7.52 %
  #define uXbrg_125000 (0x05)   //   125000 | 0x05(  5) |      125000 | 0 %
  #define uXbrg_250000 (0x02)   //   250000 | 0x02(  2) |      250000 | 0 %
//***  fx = 24000000 (BRG clock source)        *************//
#elif defined(fx_brg_24000000)  //     Baud |    m(BRG) | Actual Baud | Error
  #define   uXbrg_9600 (0x9B)   //     9600 | 0x9B(155) |        9615 | 0.16 %
  #define  uXbrg_19200 (0x4D)   //    19200 | 0x4D( 77) |       19231 | 0.16 %
  #define  uXbrg_38400 (0x26)   //    38400 | 0x26( 38) |       38462 | 0.16 %
  #define  uXbrg_57600 (0x19)   //    57600 | 0x19( 25) |       57692 | 0.16 %
  #define uXbrg_115200 (0x0C)   //   115200 | 0x0C( 12) |      115385 | 0.16 %
  #define uXbrg_125000 (0x0B)   //   125000 | 0x0B( 11) |      125000 | 0 %
  #define uXbrg_250000 (0x05)   //   250000 | 0x05(  5) |      250000 | 0 %
#else
  #error "Please define UART Baudrate generator clock"
#endif
#endif

#pragma pack(push,4)
static __data16 struct
{
    unsigned char tx_active;
    unsigned char brg; // baud rate generator is write only register
    unsigned char rts_flow;
    unsigned char last_error;
    xQueueHandle rx_queue;
    xQueueHandle tx_queue;
    uart_break_cb break_cb;
} uart_X_context(UART)
= { 0, 0,0,0, NULL, NULL,NULL};
#pragma pack(pop)




void init_uart_X(UART)(uart_break_cb cb)
{
    volatile short int waste;

    disable_RTS();

    uXc1(UART) = 0; // clears any pending errors
    uXmr(UART) = 0;

    uart_X_context(UART).tx_queue = xQueueCreate(tx_fifo_size_val,sizeof(unsigned char));
    uart_X_context(UART).rx_queue = xQueueCreate(rx_fifo_size_val,sizeof(signed short));


    /* set UART bit rate generator */
    uXbrg(UART) = uart_X_context(UART).brg = uXbrg_val;

    uXmr(UART) = uXmr_val;

    uXc0(UART) = uXc0_val;

    // clear UART receive buffer by reading then clear UART transmit buffer
    //uXtb(UART)
    waste = uXrb(UART);


    // disable irqs before setting interrupt registers
    // then set priority level which also enables interrupt
    // reset the TX active flag
    {
        istate_t state = __get_interrupt_state();
        __disable_interrupt();
        uart_X_context(UART).break_cb = cb;
        uart_X_context(UART).tx_active = 0;
        sXtic(UART) = sXtic_val;
        sXric(UART) = sXric_val;
        __set_interrupt_state(state);
    }

    uXc1(UART) = uXc1_val;

    //setup the pin function
#if   (UART)==0
    pd6_3 = 1;
    pd6_2 = 0;
    p6_3s = 0x3;
#elif (UART)==1
    pd6_7 = 1;
    pd6_6 = 0;
    p6_7s = 0x3;
#elif (UART)==2
    pd7_0 = 1;
    pd7_1 = 0;
    p7_0s = 0x3;
#elif (UART)==3
    pd4_3 = 1;
    pd4_2 = 0;
    p4_3s = 0x3;
#elif (UART)==4
    prc2=1;
    pd9_6 = 1;
    pd9_7 = 0;
    p9_6s = 0x3;
    prc2=0;
#elif (UART)==5
    pd7_6 = 1;
    pd8_0 = 0;
    p7_6s = 0x3;
#elif (UART)==6
    pd4_7 = 1;
    pd4_6 = 0;
    p4_7s = 0x3;
#else
#error "UART 7 and 8 not supported"
#endif
    enable_RTS();
}


void uninit_uart_X(UART)(void)
{
    volatile short int waste;
    istate_t state = __get_interrupt_state();
    __disable_interrupt();

    disable_RTS();

    uart_X_context(UART).break_cb = NULL;
    uart_X_context(UART).tx_active = 0;
    sXtic(UART) = 0;
    sXric(UART) = 0;

    uXc1(UART) = 0;
    uXmr(UART) = 0;
    uXc0(UART) = 0;
    // clear UART receive buffer by reading
    waste = uXrb(UART);

    vQueueDelete( uart_X_context(UART).tx_queue);
    uart_X_context(UART).tx_queue = NULL;
    vQueueDelete( uart_X_context(UART).rx_queue);
    uart_X_context(UART).rx_queue = NULL;

    //setup the pin function
#if   (UART)==0
    pd6_3 = 0;
    pd6_2 = 0;
    p6_3s = 0;
#elif (UART)==1
    pd6_7 = 0;
    pd6_6 = 0;
    p6_7s = 0;
#elif (UART)==2
    pd7_0 = 0;
    pd7_1 = 0;
    p7_0s = 0;
#elif (UART)==3
    pd4_3 = 0;
    pd4_2 = 0;
    p4_3s = 0;
#elif (UART)==4
    prc2=1;
    pd9_6 = 0;
    pd9_7 = 0;
    p9_6s = 0;
    prc2=0;
#elif (UART)==5
    pd7_6 = 0;
    pd8_0 = 0;
    p7_6s = 0;
#elif (UART)==6
    pd4_7 = 0;
    pd4_6 = 0;
    p4_7s = 0;
#else
#error "UART 7 and 8 not supported"
#endif
}

uart_break_cb set_break_handler_cb_uart_X(UART)(uart_break_cb cb)
{
    uart_break_cb old_cb;
    sXric(UART) &= ~0x7; // avoid interrupt requests, make sure
    __no_operation();    //
    __no_operation();    //
    old_cb = uart_X_context(UART).break_cb;
    uart_X_context(UART).break_cb = cb;
    sXric(UART) |= sXric_val; // go
    return old_cb;
}


void enable_rx_uart_X(UART)(void)
{
    uXc1(UART) |= uXc1_re_enabled;
}

void disable_rx_uart_X(UART)(void)
{
    uXc1(UART) &= ~uXc1_re_enabled;
}

int setbaud_uart_X(UART)(unsigned long baud)
{
    switch (baud)
    {
        case 9600:
            uXbrg(UART) = uart_X_context(UART).brg = uXbrg_9600;
        break;

        case 19200:
            uXbrg(UART) = uart_X_context(UART).brg = uXbrg_19200;
        break;

        case 38400:
            uXbrg(UART) = uart_X_context(UART).brg = uXbrg_38400;
        break;

        case 57600:
            uXbrg(UART) = uart_X_context(UART).brg = uXbrg_57600;
        break;

        case 115200:
            uXbrg(UART) =  uart_X_context(UART).brg = uXbrg_115200;
        break;

        case 125000:
            uXbrg(UART) = uart_X_context(UART).brg = uXbrg_125000;
        break;

        case 250000:
            uXbrg(UART) = uart_X_context(UART).brg = uXbrg_250000;
        break;

        default:
            return -1;
    }
    return 0;
}

long int getbaud_uart_X(UART)(void)
{
    switch (uart_X_context(UART).brg)
    {
        case uXbrg_9600: return 9600;
        case uXbrg_19200: return 19200;
        case uXbrg_38400: return 38400;
        case uXbrg_57600: return 57600;
        case uXbrg_115200: return 115200;
        case uXbrg_125000: return 125000;
        case uXbrg_250000: return 250000;

        default:
            return -1;
    }
}



int busywait_txept_uart_X(UART)(void)
{
    if (! uart_X_context(UART).tx_active)
    {
        while (0==(uXc0(UART) & uXc0_txept_true));
        return 1;
    }
    else
    {
        return -1;
    }
}

void cancel_rx_uart_X(UART)(void)
{
    uart_rtos_rx_message_t ch;
    ch.R = uart_error_user_abort | uart_error_sum;
    xQueueSendToBack(uart_X_context(UART).rx_queue,(void*)&(ch.R),0);
}

void cancel_tx_uart_X(UART)(void)
{
    unsigned char ch;
    sXtic(UART) &= ~0x7; // avoid interrupt requests, make sure
    __no_operation();    // the tx_active flag must not be modified now
    __no_operation();    //
    // empty the queue
    while(xQueueReceive(uart_X_context(UART).tx_queue,&ch,0));
    // do not wait for the character currently in the output
    // buffer. It could be blocked from the cts line
    sXtic(UART) |= sXtic_val; // go
}

void clear_error_uart_X(UART)(void)
{
    volatile char waste;
    sXric(UART) &= ~0x7; // avoid interrupt requests
    sXtic(UART) &= ~0x7; //
    __no_operation();    //
    __no_operation();    //

    uXc1(UART) = 0; // clears any pending errors
    uXmr(UART) = 0;
    uXmr(UART) = uXmr_val;
    uXc1(UART) = uXc1_val;

    waste = uXrb(UART);

    sXtic(UART) |= sXtic_val; // go
    sXric(UART) |= sXric_val; // go
}

void outchar_uart_X(UART)(char ch)
{
    sXtic(UART) &= ~0x7; // avoid interrupt requests
    __no_operation();    //
    __no_operation();    //
    while (0==(uXc1(UART) & uXc1_ti_empty)); // careful, CTS might block
    uXtb(UART) = ch;
    while (0==(uXc1(UART) & uXc1_ti_empty)); // careful, CTS might block
    while (0==(uXc0(UART) & uXc0_txept_true)); // careful, CTS might block
    sXtic(UART) |= sXtic_val; // go
}

// return 0 if success, -1 if fail (timeout)
signed short putchar_uart_X(UART)(char ch, portTickType ticks_to_wait)
{
    signed short ret = 0;
    sXtic(UART) &= ~0x7; // avoid interrupt requests, make sure
    __no_operation();    // the tx_active flag must not be modified now
    __no_operation();    //
    if (!uart_X_context(UART).tx_active)
    {
        uart_X_context(UART).tx_active = 1;
        uXtb(UART) = ch;
    }
    else
    {
        if (!xQueueSendToBack(uart_X_context(UART).tx_queue,&ch,0))
        {
            sXtic(UART) |= sXtic_val; // unlock interrupt so there will be more space
            if (!xQueueSendToBack(uart_X_context(UART).tx_queue,&ch,ticks_to_wait))
            {
                ret = -1;
            }
        }
    }
    sXtic(UART) |= sXtic_val; // go
    return ret;
}

signed short getmessage_uart_X(UART)(portTickType ticks_to_wait)
{
    uart_rtos_rx_message_t ch;
    if (!xQueueReceive(uart_X_context(UART).rx_queue,(void*)&(ch.R),ticks_to_wait))
    {
        enable_RTS();
        ch.R = uart_error_rx_timeout | uart_error_sum;
        return ch.R;
    }
    else
    {
        #define rx_fifo_empty_limit 8
        #if rx_fifo_size_val < rx_fifo_empty_limit
        #error "check rx_fifo_empty_limit"
        #else
        if (uxQueueMessagesWaiting(uart_X_context(UART).rx_queue) < rx_fifo_empty_limit)
        {
            enable_RTS();
        }
        #endif
    }
    return ch.R;
}

void rx_flush_uart_X(UART)(void)
{
    uart_rtos_rx_message_t ch;
    while (xQueueReceive(uart_X_context(UART).rx_queue,(void*)&(ch.R),0));
}



#define uart_X_tx_isr(UART) __concat(uart_,UART,_tx_isr)

// add the isr to FreeRTOS.h
portINTERRUPT_HANDLER(uart_X_tx_isr(UART))
{
    portBASE_TYPE xHigherPriorityTaskWoken = 0;

    if (!xQueueIsQueueEmptyFromISR(uart_X_context(UART).tx_queue))
    {
        unsigned char ch;
        xQueueReceiveFromISR(uart_X_context(UART).tx_queue,&ch,&xHigherPriorityTaskWoken);
        uXtb(UART) = ch;
    }
    else
    {
        uart_X_context(UART).tx_active = 0;
    }
    portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);
}

#define uart_X_rx_isr(UART) __concat(uart_,UART,_rx_isr)

portINTERRUPT_HANDLER(uart_X_rx_isr(UART))
{
    signed short ech = uXrb(UART);
    portBASE_TYPE xHigherPriorityTaskWoken = 0;
    unsigned portBASE_TYPE free_space = rx_fifo_size_val
                        - uxQueueMessagesWaitingFromISR(uart_X_context(UART).rx_queue);
    #if rx_fifo_size_val < 20
      #error "check rx_fifo_min_free_space_limit"
    #else
      #define rx_fifo_min_free_space_limit (8)
    #endif

    // break detected
    if ((ech & uart_error_framing) && ((ech&0xFF) == 0) && uart_X_context(UART).break_cb)
    {
        uart_X_context(UART).break_cb(&xHigherPriorityTaskWoken);
    }

    switch (free_space)
    {
        case 0:
            break;
        case 1:
            ech = uart_error_rx_queue_overrun | uart_error_sum;
            xQueueSendToBackFromISR(uart_X_context(UART).rx_queue,
                    &ech,
                    &xHigherPriorityTaskWoken);
            break;
        case rx_fifo_min_free_space_limit:
            disable_RTS();
            // no break, fall through
        default:
            if (ech<0)
            {
                clear_error_uart_X(UART)();
            }
            xQueueSendToBackFromISR(uart_X_context(UART).rx_queue,&ech,&xHigherPriorityTaskWoken);

    }
    #undef rx_fifo_min_free_space_limit
    portEND_SWITCHING_ISR(xHigherPriorityTaskWoken);
}
#endif

#ifdef __cplusplus
  }
#endif

#undef sXtic_val
#undef sXric_val
#undef tx_fifo_size_val
#undef rx_fifo_size_val
#undef uXmr_val
#undef uXc1_val
#undef uXc0_val
#undef uXbrg_val


int foo()
{
	if (false) return 1;
	if (true) return 2;
	float a = 0;
}
